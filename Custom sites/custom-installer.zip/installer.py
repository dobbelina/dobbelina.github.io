'''
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from kodi_six import xbmc, xbmcgui, xbmcvfs
import os
import requests
import re
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib import favorites
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

#site = AdultSite('custom-installer', '[COLOR red]Custom Site Installer[/COLOR]', '', '', 'custom-installer')
site = CustomSite('ErosVece', 'custom-installer')

tempfolder = utils.TRANSLATEPATH('special://temp/')
masterurl = 'https://dobbelina.github.io/custom.html'


@site.register(default_mode=True)
def Main():
    site.add_download_link('[COLOR hotpink]Read About Site (contextmenu from main menu)[/COLOR]', '', '', '')
    site.add_download_link('[COLOR hotpink]----[/COLOR]', '', '', '')
    site.add_dir('[COLOR hotpink]Install custom sites from Github[/COLOR]', '', 'ListFiles', '')
    site.add_download_link('[COLOR hotpink]----[/COLOR]', '', '', '')
    site.add_dir('[COLOR hotpink]Enable custom sites[/COLOR]', '', 'favorites.enable_custom_site', '')
    site.add_dir('[COLOR hotpink]Disable custom sites[/COLOR]', '', 'favorites.disable_custom_site', '')
    site.add_dir('[COLOR hotpink]List custom sites[/COLOR]', '', 'favorites.list_custom_sites', '')
    site.add_dir('[COLOR hotpink]Uninstall custom sites[/COLOR]', '', 'favorites.uninstall_custom_site', '')

    utils.eod()

@site.register()
def Download(url):
    destination = get_zip_destination(url)
    success = download_zip(url, destination)
    if success:
        success2 = favorites.process_custom_site_zip(destination)
        if success2:
            Remove(destination)
        show_install_result_dialog(success2)


@site.register()
def ListFiles():
    listhtml = utils.getHtml(masterurl)
    matches = re.compile(r'<tr>\s*<td>([^<]+)</td>\s*<td><a href="([^"]+).*?<td>([^<]+)<', re.IGNORECASE | re.DOTALL).findall(listhtml)
    for name, link, author in matches:
        zipname = urllib_parse.urlparse(link).path.split("/")[-1]
        name = '[COLOR hotpink]{}[/COLOR] - {} - {}'.format(name, zipname, author)
        site.add_download_link(name, link, 'Download', '')

    utils.eod()


@site.register()
def Remove(dest):
    success = xbmcvfs.delete(dest)


def get_zip_destination(url):
    zip_name = urllib_parse.urlparse(url).path.split("/")[-1]
    return os.path.join(tempfolder, zip_name)

def download_zip(url, dest):
    response = requests.get(url, stream=True)
    total_length = int(response.headers.get('content-length', 0))
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create("Downloading zip file", "Please wait...")

    with open(dest, "wb") as f:
        if total_length == 0:
            f.write(response.content)
        else:
            downloaded = 0
            for chunk in response.iter_content(chunk_size=1024):
                if not chunk:
                    continue
                downloaded += len(chunk)
                f.write(chunk)
                percent = int(downloaded * 100 / total_length)
                progress_dialog.update(percent)
                if progress_dialog.iscanceled():
                    progress_dialog.close()
                    return False
    progress_dialog.close()
    return True

def show_download_result_dialog(success):
    if success:
        xbmcgui.Dialog().ok("Download completed", "The zip file has been downloaded to the temp folder.")
    else:
        xbmcgui.Dialog().ok("Download failed", "The zip file could not be downloaded.")


def show_install_result_dialog(success):
    if success:
        xbmcgui.Dialog().ok("Installation completed", "The zip file has been installed. You can now enable it.")
    else:
        xbmcgui.Dialog().ok("Installation failed", "The zip file could not be installed.")