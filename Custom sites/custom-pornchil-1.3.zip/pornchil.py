'''
    Pornchil v1.3
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from kodi_six import xbmc
from json import loads, dumps
from six.moves import urllib_parse
from resources.lib import utils
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

#site = AdultSite('pornchil', '[COLOR hotpink]PornChil[/COLOR] [COLOR red][Debrid only][/COLOR]', 'https://pornchil.com/', 'https://pornchil.com/wp-content/uploads/2022/02/cropped-FAVICON-1-270x270.png', 'pornchil')
site = CustomSite('A fan', 'pornchil')


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url, 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Tags[/COLOR]', site.url, 'Tags', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + '?s=', 'Search', site.img_search)
    List(site.url)
    utils.eod()


@site.register()
def List(url):
    listhtml = utils.getHtml(url, '')
    articles = re.compile('<article[^>]+>(.*?)</article>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not articles:
        return
    for article in articles:
        match = re.search(r'itemprop="headline"><a\s*href="([^"]+)"[^>]+>([^<]+)<', article, re.DOTALL | re.IGNORECASE)
        if match:
            videopage, name = match.groups()
        else:
            name_match = re.search(r'itemprop="text">\s+<h\d.*?>(\w+[^<]+)</', article, re.DOTALL | re.IGNORECASE)
            if name_match:
                name = name_match.group(1)
            else:
                name = 'No title found, it\'s a surprise!'
            video_match = re.search('read-more" href="([^"]+)"', article, re.DOTALL | re.IGNORECASE)
            if video_match:
                videopage = video_match.group(1)
            else:
                continue
        name = utils.cleantext(name)
        if '?s=' not in url:
            img = re.search('<img.*?decoding.*?src="(htt[^"]+)"', article, re.IGNORECASE | re.DOTALL).group(1)
        else:
            img = ''
        description = name + '\n' + re.search('datePublished">([^<]+)<', article, re.IGNORECASE | re.DOTALL).group(1)

        contexturl = (utils.addon_sys
                      + "?mode={}.Lookupinfo".format(site.module_name)
                      + "&url=" + urllib_parse.quote_plus(videopage))
        contextmenu = [('[COLOR deeppink]Lookup info[/COLOR]', 'RunPlugin(' + contexturl + ')')]
        site.add_download_link(name, videopage, 'PlayOrList', img, description, contextm=contextmenu)

    np = re.compile('next page-numbers" href="([^"]+)"', re.DOTALL | re.IGNORECASE).search(listhtml)
    if np:
        page_number = np.group(1).split('/')[-2]
        site.add_dir('Next Page (' + page_number + ')', np.group(1), 'List', site.img_next)
    utils.eod()


@site.register()
def PlayOrList(url, name, download=None):
    sitehtml = utils.getHtml(url, site.url)
    downloadsection = re.compile('id="Download.*?>Download(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(sitehtml)[0]
    videolinks = re.compile('href="([^"]+)"[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(downloadsection)

    if len(videolinks) <= 1:
        Playvid(videolinks[0][0], videolinks[0][1], download)
    else:
        contexturl = (utils.addon_sys
                      + "?mode={}.VideosList".format(site.module_name)
                      + "&name=" + name
                      + "&url=" + urllib_parse.quote_plus(dumps(videolinks)))
        xbmc.executebuiltin('Container.Update(' + contexturl + ')')


@site.register()
def VideosList(url, name):
    vp = utils.VideoPlayer(name)
    vp.progress.update(25, "[CR]Checking videolinks[CR]")
    videolinks = loads(url)

    for link, filename in videolinks:
        if CheckUrl(link, vp):
            filename = utils.cleantext(filename)
            img = xbmc.getInfoImage("ListItem.Thumb")
            contexturl = (utils.addon_sys
                          + "?mode={}.Lookupinfo".format(site.module_name)
                          + "&url=" + urllib_parse.quote_plus(link))
            contextmenu = [('[COLOR deeppink]Lookup info[/COLOR]', 'RunPlugin(' + contexturl + ')')]
            site.add_download_link(filename, link, 'Playvid', img, contextm=contextmenu)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    vp.play_from_link_to_resolve(url)


def CheckUrl(url, vp):
    if vp.bypass_hosters_single(url):
        return False
    if vp.resolveurl.HostedMediaFile(url).valid_url():
        return True


@site.register()
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        site.search_dir(searchUrl, 'Search')
    else:
        title = keyword.replace(' ', '+')
        searchUrl = searchUrl + title
        List(searchUrl)


@site.register()
def Categories(url):
    listhtml = utils.getHtml(url)
    match = re.compile(r'<option class="level-\d+" value="([^"]+)"[^>]*>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catid, name, in match:
        name = utils.cleantext(name.strip())
        catpage = "{}?cat={}".format(site.url, catid)
        site.add_dir(name, catpage, 'List', '')
    utils.eod()


@site.register()
def Tags(url):
    listhtml = utils.getHtml(url)
    match = re.compile('/(tag/[^"]+)" class=".*?aria-label="([^"]+)"[^>]+>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for tagpage, name, in match:
        name = utils.cleantext(name.strip())
        site.add_dir(name, site.url + tagpage, 'List', '')
    utils.eod()


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Cat", '/(category/[^"]+)" rel="category tag[^>]+>([^<]+)<', ''),
        ("Tag", '/(tag[^"]+)" rel="tag[^>]+>([^<]+)<', '')
    ]

    lookupinfo = utils.LookupInfo(site.url, url, '{}.List'.format(site.module_name), lookup_list)
    lookupinfo.getinfo()
