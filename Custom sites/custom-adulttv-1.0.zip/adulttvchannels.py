"""
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from resources.lib import utils
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

#site = AdultSite('adulttv', '[COLOR hotpink]Adult TV Channels[/COLOR]', 'https://adult-tv-channels.com/', 'https://adult-tv-channels.com/wp-content/uploads/2021/11/cropped-adult-tv-channels.png', 'adulttv')
site = CustomSite('A fan', 'adulttv')


@site.register(default_mode=True)
def main(url):
    List(url + 'page/1/')


@site.register()
def List(url):
    html = utils.getHtml(url, '')
    match = re.compile('<article.*?href="([^"]+)".*?src="([^"]+)".*?entry-title(?:[^>]+>){2}([^<]+)<.*?excerpt">[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(html)
    for videourl, img, name, description in match:
        name = utils.cleantext(name)
        description = utils.cleantext(description)
        site.add_download_link(name, videourl, 'Playvid', img, description, noDownload=True)
    nextp = re.compile('rel="next" href="([^"]+)"', re.DOTALL | re.IGNORECASE).search(html)
    if nextp:
        nextp = nextp.group(1)
        np = re.findall(r'\d+', nextp)[-1]
        site.add_dir('Next Page ({})'.format(np), nextp, 'List', site.img_next)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    videosrc = utils.getHtml(url, site.url)
    phpurl = re.search('<iframe.*?src="/([^"]+)"', videosrc, re.IGNORECASE | re.DOTALL)
    if phpurl:
        phpurl = phpurl.group(1)
        phpurl = site.url + phpurl
        phphtml = utils.getHtml(phpurl, url)
        match = re.compile('file:"([^"]+)"', re.DOTALL | re.IGNORECASE).search(phphtml)
        if match:
            streamurl = match.group(1)
            vp = utils.VideoPlayer(name, download)
            vp.play_from_direct_link(streamurl)
