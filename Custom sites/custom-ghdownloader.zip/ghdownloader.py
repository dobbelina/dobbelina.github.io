'''
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from kodi_six import xbmc, xbmcgui, xbmcvfs
import os
import requests
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.basics import rootDir
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

#site = AdultSite('ghdownloader', '[COLOR red]Github Master Downloader[/COLOR]', '', '', 'ghdownloader')
site = CustomSite('Cumination', 'ghdownloader')

tempfolder = utils.TRANSLATEPATH('special://temp/')
masterurl = 'https://github.com/dobbelina/repository.dobbelina/archive/refs/heads/master.zip'


@site.register(default_mode=True)
def Main():
    site.add_download_link('[COLOR hotpink]Read About Site (contextmenu from main menu)[/COLOR]', '', '', '')
    site.add_download_link('[COLOR hotpink]----[/COLOR]', '', '', '')
    site.add_download_link('[COLOR hotpink]Download latest Cumination Master[/COLOR]', '', 'Download', '')
    if exists_zip_destination():
        site.add_download_link('[COLOR hotpink]Remove downloaded master.zip[/COLOR]', '', 'Remove', '')
    site.add_download_link('[COLOR hotpink]----[/COLOR]', '', '', '')
    site.add_download_link('[COLOR hotpink]Open Filemanager[/COLOR]', '', 'OpenFM', '')
    site.add_download_link('[COLOR hotpink]This is the location where you can find Cumination:[/COLOR]', '', '', '')
    site.add_download_link(rootDir, '', '', '')
    utils.eod()

@site.register()
def Download():
    destination = get_zip_destination(masterurl)
    success = download_zip(masterurl, destination)
    show_download_result_dialog(success)
    xbmc.executebuiltin('Container.Refresh')


@site.register()
def OpenFM():
    xbmc.executebuiltin(f'ActivateWindow(FileManager, {tempfolder}, return)')


def exists_zip_destination():
    dest = get_zip_destination(masterurl)
    return xbmcvfs.exists(dest)


@site.register()
def Remove():
    dest = get_zip_destination(masterurl)
    success = xbmcvfs.delete(dest)
    xbmc.executebuiltin('Container.Refresh')


def get_zip_destination(url):
    zip_name = urllib_parse.urlparse(url).path.split("/")[-1]
    return os.path.join(tempfolder, zip_name)

def download_zip(url, dest):
    response = requests.get(url, stream=True)
    total_length = int(response.headers.get('content-length', 0))
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create("Downloading zip file", "Please wait...")

    with open(dest, "wb") as f:
        if total_length == 0:
            f.write(response.content)
        else:
            downloaded = 0
            for chunk in response.iter_content(chunk_size=1024):
                if not chunk:
                    continue
                downloaded += len(chunk)
                f.write(chunk)
                percent = int(downloaded * 100 / total_length)
                progress_dialog.update(percent)
                if progress_dialog.iscanceled():
                    progress_dialog.close()
                    return False
    progress_dialog.close()
    return True

def show_download_result_dialog(success):
    if success:
        xbmcgui.Dialog().ok("Download completed", "The zip file has been downloaded to the temp folder.")
    else:
        xbmcgui.Dialog().ok("Download failed", "The zip file could not be downloaded.")
