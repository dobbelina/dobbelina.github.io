# -*- coding: utf-8 -*-
"""XFreeHD custom site for Cumination / Kodi 21. Author: EvelK.

Copyright (C) 2026 EvelK
SPDX-License-Identifier: GPL-3.0-or-later
"""

import gzip
import hashlib
import json
import os
import re
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from html import unescape
from html.parser import HTMLParser
from urllib.parse import parse_qsl, parse_qs, quote, urlencode, urljoin, urlsplit, urlunsplit
from urllib.error import HTTPError
from urllib.request import Request, build_opener, HTTPRedirectHandler

from kodi_six import xbmc, xbmcgui, xbmcvfs
from resources.lib import utils
from resources.lib.customsite import CustomSite

site = CustomSite('EvelK', 'xfreehd')
BASE_URL = 'https://beta.xfreehd.com/'
VERSION = '1.0.6'
SEARCH_ORDERS = (
    ('Being Watched', 'bw'), ('Longest', 'lg'), ('Most Commented', 'md'),
    ('Most Recent', 'mr'), ('Most Viewed', 'mv'), ('Relevance', ''),
    ('Top Favorited', 'tf'), ('Top Rated', 'tr'),
)
PERIODS = (('Today', ''), ('This Week', 'w'), ('This Month', 'm'), ('All', 'a'))
SEARCH_CATEGORIES = (('Amateur', 'amateur'), ('Anal', 'anal'), ('Asian', 'asian'), ('Big Ass', 'big-ass'), ('Big Dick', 'big-dick'), ('Big Tits', 'big-tits'), ('Blonde', 'blonde'), ('Blowjob', 'blowjob'), ('Bondage', 'bondage'), ('Brunette', 'brunette'), ('Casting', 'casting'), ('Celebrity', 'celebrity'), ('College', 'college'), ('Creampie', 'creampie'), ('Cumshots', 'cumshots'), ('Double Penetration', 'double-penetration'), ('Ebony', 'ebony'), ('Facial', 'facial'), ('Fetish', 'fetish'), ('French', 'french'), ('Gangbang', 'gangbang'), ('German', 'german'), ('Group Sex', 'group-sex'), ('Handjobs', 'handjobs'), ('Hardcore', 'hardcore'), ('Hentai', 'hentai'), ('Indian', 'indian'), ('Interracial', 'interracial'), ('Japanese', 'japanese'), ('Latin', 'latin'), ('Lesbian', 'lesbian'), ('Masturbation', 'masturbation'), ('Matures', 'matures'), ('Milf', 'milf'), ('Old & Young', 'old-young'), ('Outdoor', 'outdoor'), ('Pornstars', 'pornstars'), ('POV', 'pov'), ('Red Head', 'red-head'), ('Russian', 'russian'), ('Small Tits', 'small-tits'), ('Solo', 'solo'), ('Striptease', 'striptease'), ('Teen', 'teen'), ('Threesome', 'threesome'), ('Toys', 'toys'), ('Turkish', 'turkish'), ('Vintage', 'vintage'))
_VOID_TAGS = frozenset(('area', 'base', 'br', 'col', 'embed', 'hr', 'img',
                        'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'))
_IMAGE_EXTENSIONS = ('.jpg', '.png', '.webp', '.gif', '.avif')
_MAX_IMAGE = 4 * 1024 * 1024
_MAX_IMPORT = 16 * 1024 * 1024
_PRIVATE_ACCESS_TTL = 60 * 60
_PRIVATE_ACCESS_CACHE_LIMIT = 2000
COUNTRIES = (('Worldwide', ''), ('Albania', 'al'), ('Argentina', 'ar'), ('Australia', 'au'), ('Austria', 'at'), ('Bangladesh', 'bd'), ('Belgium', 'be'), ('Bolivia', 'bo'), ('Brazil', 'br'), ('Canada', 'ca'), ('Chile', 'cl'), ('Colombia', 'co'), ('Costa Rica', 'cr'), ('Czech Republic', 'cz'), ('Ecuador', 'ec'), ('Egypt', 'eg'), ('Finland', 'fi'), ('France', 'fr'), ('Germany', 'de'), ('Greece', 'gr'), ('Hong Kong', 'hk'), ('Hungary', 'hu'), ('India', 'in'), ('Indonesia', 'id'), ('Ireland', 'ie'), ('Israel', 'il'), ('Italy', 'it'), ('Japan', 'jp'), ('Luxembourg', 'lu'), ('Malaysia', 'my'), ('Mexico', 'mx'), ('Morocco', 'ma'), ('Myanmar', 'mm'), ('Netherlands', 'nl'), ('Norway', 'no'), ('Pakistan', 'pk'), ('Panama', 'pa'), ('Peru', 'pe'), ('Philippines', 'ph'), ('Portugal', 'pt'), ('Romania', 'ro'), ('Russia', 'ru'), ('Serbia', 'rs'), ('Singapore', 'sg'), ('Slovakia', 'sk'), ('South Africa', 'za'), ('South Korea', 'kr'), ('Spain', 'es'), ('Sweden', 'se'), ('Switzerland', 'ch'), ('Taiwan', 'tw'), ('Thailand', 'th'), ('Turkey', 'tr'), ('Ukraine', 'ua'), ('United Kingdom', 'gb'), ('United States', 'us'), ('Vietnam', 'vn'))


class _Node:
    def __init__(self, tag='', attrs=(), parent=None):
        self.tag, self.attrs, self.parent = tag, dict(attrs), parent
        self.children = []

    def has_class(self, name):
        return name in (self.attrs.get('class') or '').split()

    def nodes(self, tag=None, cls=None, attr=None):
        for child in self.children:
            if not isinstance(child, _Node):
                continue
            if ((tag is None or child.tag == tag)
                    and (cls is None or child.has_class(cls))
                    and (attr is None or child.attrs.get(attr[0]) == attr[1])):
                yield child
            yield from child.nodes(tag, cls, attr)

    def first(self, tag=None, cls=None, attr=None):
        return next(self.nodes(tag, cls, attr), None)

    def text(self):
        return ' '.join(' '.join(c.text() if isinstance(c, _Node) else c
                                 for c in self.children).split())


class _Document(HTMLParser):
    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.root = _Node()
        self.stack = [self.root]
        self.feed(html or '')
        self.close()

    def handle_starttag(self, tag, attrs):
        node = _Node(tag, attrs, self.stack[-1])
        self.stack[-1].children.append(node)
        if tag not in _VOID_TAGS:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in _VOID_TAGS:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if self.stack[-1].tag not in ('script', 'style'):
            self.stack[-1].children.append(data)


def _white(text):
    return '[COLOR white]{}[/COLOR]'.format(text)


def _absolute(url, base=BASE_URL):
    url = unescape(url or '').strip().replace('\\/', '/')
    if not url or url.startswith(('data:', 'javascript:', '#')):
        return ''
    resolved = urljoin(base, url)
    if urlsplit(resolved).scheme not in ('http', 'https'):
        return ''
    return quote(resolved, safe=":/%?&=+#@!$'()*;,~-_")


def _plugin_url(mode, url):
    return utils.addon_sys + '?' + urlencode({'mode': site.get_full_mode(mode), 'url': url})


def _update(mode, url):
    xbmc.executebuiltin('Container.Update({})'.format(_plugin_url(mode, url)))


def _profile_path(*parts):
    translate = getattr(xbmcvfs, 'translatePath', getattr(utils, 'TRANSLATEPATH', None))
    root = translate(utils.profileDir) if translate else utils.profileDir
    path = os.path.join(root, 'custom_xfreehd', *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


class _FetchError(Exception):
    """A user-readable request failure; never contains request credentials."""

    def __init__(self, message, status=None, reason='request'):
        self.status, self.reason = status, reason
        super().__init__(message)


def _browser_session():
    try:
        with open(_profile_path('browser_session.json'), encoding='utf-8') as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_browser_session(data):
    # Rotate the cache namespace even when the same browser identity is reimported.
    data = dict(data, private_access_epoch=time.time_ns())
    path = _profile_path('browser_session.json')
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(path),
                                         suffix='.tmp', delete=False) as stream:
            temporary = stream.name
            json.dump(data, stream)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
        _clear_private_access_cache()
    finally:
        if temporary and os.path.exists(temporary):
            os.remove(temporary)


class _ImportError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def _decode_import(data):
    if isinstance(data, (bytes, bytearray)):
        data = bytes(data)
        encoding = 'utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
        try:
            return data.decode(encoding)
        except UnicodeError:
            raise _ImportError('ENCODING', 'Save the export as UTF-8 or UTF-16 text.') from None
    if not isinstance(data, str):
        raise _ImportError('FILE_READ', 'Kodi could not read text from the selected file.')
    return data.lstrip('\ufeff')


def _json_cookie_records(data, domain='', name='', depth=0):
    """Accept arrays, wrapped exports, and domain/path/name nested exports."""
    if depth > 16:
        return
    if isinstance(data, list):
        for item in data:
            yield from _json_cookie_records(item, domain, '', depth + 1)
        return
    if not isinstance(data, dict):
        return
    domain = data.get('domain') or data.get('host') or data.get('hostname') or domain
    if not domain and isinstance(data.get('url'), str):
        domain = urlsplit(data['url']).hostname or ''
    if 'value' in data and ('name' in data or name not in ('', 'cookies', 'data', 'result', 'solution')):
        item = dict(data)
        item['name'] = data.get('name') or name
        item['domain'] = domain
        yield item
        return
    if (name == 'cookies' or 'cf_clearance' in data) and all(not isinstance(v, (dict, list)) for v in data.values()):
        for key, value in data.items():
            if isinstance(value, str):
                yield {'name': key, 'value': value, 'domain': domain}
        return
    for key, value in data.items():
        if not isinstance(value, (dict, list)):
            continue
        hint = str(key).lstrip('.').lower()
        child_domain = hint if re.fullmatch(r'(?:[a-z0-9-]+\.)+[a-z0-9-]+', hint) else domain
        yield from _json_cookie_records(value, child_domain, str(key), depth + 1)


def _cookie_expired(cookie):
    if cookie.get('session') is True:
        return False
    value = next((cookie[k] for k in ('expirationDate', 'expires', 'expiry', 'expiration')
                  if k in cookie and cookie[k] not in (None, '')), 0)
    try:
        expiry = float(value)
    except (ValueError, TypeError):
        try:
            date = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            expiry = date.replace(tzinfo=date.tzinfo or timezone.utc).timestamp()
        except (ValueError, TypeError, OverflowError):
            return True
    if expiry > 100000000000:
        expiry /= 1000
    return expiry > 0 and expiry < time.time()


def _cookie_header(text):
    text = _decode_import(text).strip()
    if not text:
        raise _ImportError('EMPTY_FILE', 'The selected cookie file is empty.')
    records = None
    header = re.search(r'^\s*Cookie\s*:\s*(.+)$', text, re.I | re.M)
    if text.startswith(('{', '[', '"')):
        try:
            data = json.loads(text)
        except ValueError:
            raise _ImportError('JSON_SYNTAX', 'The JSON file is incomplete or is not a valid cookie export.') from None
        if isinstance(data, str):
            return _cookie_header(data)
        if isinstance(data, dict):
            raw = data.get('cookie') or data.get('Cookie') or data.get('cookies')
            if not raw and isinstance(data.get('headers'), dict):
                raw = data['headers'].get('Cookie') or data['headers'].get('cookie')
            if isinstance(raw, str):
                return _cookie_header(raw)
        records = list(_json_cookie_records(data))
        if not records:
            raise _ImportError('JSON_LAYOUT', 'No cookie records were found. Use a Netscape TXT export or cookie JSON containing names and values.')
    elif not header and ('\t' in text or '# Netscape' in text):
        records = []
        for line in text.splitlines():
            line = line.lstrip()
            if line.startswith('#HttpOnly_'):
                line = line[len('#HttpOnly_'):]
            elif not line or line.startswith('#'):
                continue
            fields = line.split('\t', 6) if '\t' in line else re.split(r'\s+', line, maxsplit=6)
            if len(fields) == 7:
                records.append({'domain': fields[0], 'expires': fields[4],
                                'name': fields[5], 'value': fields[6]})
    pairs = {}
    if records is None:
        text = header.group(1).strip() if header else text
        if '=' not in text:
            raise _ImportError('COOKIE_HEADER', 'Paste the complete Cookie header with cookie names and values.')
        for part in text.split(';'):
            if not part.strip():
                continue
            name, equal, value = part.strip().partition('=')
            if not equal or not re.fullmatch(r"[!#$%&'*+\-.^_`|~0-9A-Za-z]+", name):
                raise _ImportError('COOKIE_HEADER', 'Use a Cookie request header, Netscape TXT, or JSON cookie export.')
            if any(ord(c) < 32 or ord(c) > 126 for c in value):
                raise _ImportError('COOKIE_HEADER', 'The Cookie header contains invalid control characters.')
            pairs[name] = value
    else:
        for cookie in records:
            domain = str(cookie.get('domain') or '').lstrip('.').rstrip('.').lower()
            if domain and domain != 'xfreehd.com' and not domain.endswith('.xfreehd.com'):
                continue
            if _cookie_expired(cookie):
                continue
            name, value = cookie.get('name'), cookie.get('value')
            if not isinstance(name, str) or not re.fullmatch(r"[!#$%&'*+\-.^_`|~0-9A-Za-z]+", name):
                continue
            # Empty values are valid cookies and must not invalidate an export.
            if not isinstance(value, str) or any(ord(c) < 32 or ord(c) > 126 or c == ';' for c in value):
                continue
            pairs[name] = value
    if not pairs:
        raise _ImportError('NO_SITE_COOKIES', 'No current XFreeHD cookies were found. Export cookies while XFreeHD is open in Firefox.')
    return '; '.join('{}={}'.format(name, value) for name, value in pairs.items())


def _user_agent(text):
    text = _decode_import(text).strip()
    if text.startswith('{'):
        data = json.loads(text)
        text = data.get('user_agent') or data.get('userAgent') or data.get('User-Agent') or (data.get('headers') or {}).get('User-Agent') or ''
    if not isinstance(text, str):
        raise ValueError('Use the exact one-line User-Agent request header from your browser.')
    header = re.search(r'^[ \t]*User-Agent[ \t]*:[ \t]*([^\r\n]+)\r?$', text, re.I | re.M)
    if header:
        text = header.group(1)
    text = re.sub(r'^User-Agent\s*:\s*', '', text, flags=re.I).strip()
    if not text or any(ord(c) < 32 or ord(c) > 126 for c in text):
        raise ValueError('Use the exact one-line User-Agent request header from your browser.')
    return text


def _session_bundle(text):
    """Validate both values before changing the saved browser session."""
    text = _decode_import(text).strip()
    if text.startswith('{'):
        try:
            cookie = _cookie_header(text)
            user_agent = _user_agent(text)
        except _ImportError:
            raise
        except (ValueError, TypeError, AttributeError):
            raise _ImportError('SESSION_FORMAT', 'The session JSON must contain cookies and the matching User-Agent.') from None
    else:
        cookie_line = re.search(r'^[ \t]*Cookie[ \t]*:[ \t]*([^\r\n]+)\r?$', text, re.I | re.M)
        if not cookie_line:
            raise _ImportError('MISSING_COOKIE', 'Add a line beginning Cookie: followed by the complete signed-in Cookie header.')
        if not re.search(r'^[ \t]*User-Agent[ \t]*:[ \t]*[^\r\n]+\r?$', text, re.I | re.M):
            raise _ImportError('MISSING_USER_AGENT', 'Add a line beginning User-Agent: followed by the matching browser User-Agent.')
        cookie = _cookie_header(cookie_line.group(1).strip())
        try:
            user_agent = _user_agent(text)
        except ValueError:
            raise _ImportError('USER_AGENT_FORMAT', 'Use the exact one-line browser User-Agent after User-Agent:.') from None
    return {'cookie': cookie, 'user_agent': user_agent}


def _response_html(response):
    data = response.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        raise _FetchError('The page response was too large.')
    if (response.headers.get('Content-Encoding') or '').lower() == 'gzip':
        data = gzip.decompress(data)
    if len(data) > 8 * 1024 * 1024:
        raise _FetchError('The page response was too large.')
    return data.decode('utf-8', 'replace')


def _report_fetch_error(exc):
    utils.kodilog('XFreeHD {} REQUEST_FAILED {}'.format(VERSION, str(exc)))
    utils.notify('XFreeHD', str(exc), duration=7000)


def _image_type(data):
    if data[:3] == b'\xff\xd8\xff':
        return '.jpg'
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        return '.png'
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return '.webp'
    if data[:6] in (b'GIF87a', b'GIF89a'):
        return '.gif'
    if data[4:8] == b'ftyp' and (b'avif' in data[8:40] or b'avis' in data[8:40]):
        return '.avif'
    return ''


def _remote_image(url):
    headers = _request_headers(target=url)
    headers['Accept'] = 'image/jpeg,image/png,image/webp;q=0.5,*/*;q=0.1'
    return url + '|' + urlencode(headers) if url else site.image


def _cached_image(candidates, deadline):
    for url in candidates:
        key = hashlib.sha256(url.encode('utf-8')).hexdigest()
        stem = _profile_path('thumbnails', key)
        for ext in _IMAGE_EXTENSIONS:
            path = stem + ext
            if os.path.isfile(path) and os.path.getsize(path) > 0:
                return path
    for url in candidates:
        remaining = deadline - time.monotonic()
        if remaining < 0.2:
            break
        headers = _request_headers(target=url)
        headers['Accept'] = 'image/jpeg,image/png,image/webp;q=0.5,*/*;q=0.1'
        try:
            request = Request(url, headers=headers)
            opener = build_opener(_BrowserRedirect()) if headers.get('Cookie') else utils.opener
            with opener.open(request, timeout=min(3, remaining)) as response:
                data = response.read(_MAX_IMAGE + 1)
            ext = _image_type(data)
            if not ext or len(data) > _MAX_IMAGE:
                continue
            if ext == '.avif':
                # Retry a JPEG spelling if content negotiation returned AVIF.
                jpeg = re.sub(r'\.(avif|webp)(?=\?|$)', '.jpg', url, flags=re.I)
                if jpeg != url and jpeg not in candidates:
                    return _cached_image([jpeg], deadline)
                continue
            path = _profile_path('thumbnails', hashlib.sha256(url.encode('utf-8')).hexdigest()) + ext
            temporary = None
            try:
                with tempfile.NamedTemporaryFile(dir=os.path.dirname(path), suffix='.tmp', delete=False) as stream:
                    temporary = stream.name
                    stream.write(data)
                os.replace(temporary, path)
            finally:
                if temporary and os.path.exists(temporary):
                    os.remove(temporary)
            return path
        except Exception:
            continue
    # Do not give Kodi a local filename until a complete image exists.
    return _remote_image(candidates[0]) if candidates else site.image


def _clean_thumbnails():
    try:
        directory = os.path.dirname(_profile_path('thumbnails', 'cache'))
        marker = os.path.join(directory, '.cleaned')
        now = time.time()
        if os.path.exists(marker) and now - os.path.getmtime(marker) < 86400:
            return
        for entry in os.scandir(directory):
            if entry.is_file() and now - entry.stat().st_mtime > 7 * 86400:
                os.remove(entry.path)
        with open(marker, 'w'):
            pass
    except OSError:
        pass


def _artwork(rows):
    if not rows:
        return
    _clean_thumbnails()
    unique = list(dict.fromkeys(tuple(row['images']) for row in rows))
    deadline = time.monotonic() + 6
    with ThreadPoolExecutor(max_workers=8) as pool:
        images = list(pool.map(lambda urls: _cached_image(urls, deadline), unique))
    result = dict(zip(unique, images))
    for row in rows:
        row['image'] = result[tuple(row['images'])]


def _add_videos(rows):
    rows = _filter_private_access(rows)
    _artwork(rows)
    for row in rows:
        menus = [
            (_white('Lookup Info'), 'RunPlugin({})'.format(_plugin_url('LookupInfo', row['url']))),
            (_white('Related Porn Videos'), 'RunPlugin({})'.format(_plugin_url('Related', row['url']))),
        ]
        site.add_download_link(_white(row['name']), row['url'], 'Playvid', row['image'],
                               row['name'], duration=row['duration'], quality=row['quality'],
                               contextm=menus)
    return len(rows)


def _video_access(doc, url):
    """Only an explicit signed-in relationship gate proves a video is blocked."""
    player = doc.first('video', attr=('id', 'hdPlayer'))
    container = doc.first(cls='video-container')
    if ((player is not None and _sources(doc, url))
            or (container is not None and _sources(container, url))):
        return 'allowed'
    private = doc.first(cls='video-private-container')
    if private is None:
        return 'unknown'
    footer = private.first(cls='vpfooter')
    message = (footer or private).text().casefold()
    restricted = bool(re.search(
        r'\byou\s+(?:must|have\s+to|need\s+to)\s+be\s+'
        r'(?:(?:subscribers?|subscribed)\s+or\s+)?friends?\s+with\b', message))
    if restricted:
        return 'friends-required' if _auth_user(doc) else 'login-required'
    return 'unknown'


def _probe_private_access(row):
    try:
        doc = _Document(_fetch(row['url'], timeout=8)).root
        return _video_access(doc, row['url'])
    except Exception:
        # A timeout or an expired session is not proof of a friendship restriction.
        return 'unknown'


def _private_access_identity(session):
    if not (session.get('cookie') and session.get('user_agent')):
        return ''
    identity = [session['cookie'], session['user_agent'], session.get('private_access_epoch')]
    return hashlib.sha256(json.dumps(identity).encode('utf-8')).hexdigest()


def _clear_private_access_cache():
    try:
        os.remove(_profile_path('private_access.json'))
    except FileNotFoundError:
        pass
    except OSError:
        # The rotated session namespace also invalidates an undeletable old file.
        utils.kodilog('XFreeHD {} PRIVATE_ACCESS cache_clear_failed'.format(VERSION))


def _load_private_access_cache(identity, now):
    try:
        with open(_profile_path('private_access.json'), encoding='utf-8') as stream:
            data = json.load(stream)
        if not isinstance(data, dict) or data.get('version') != 1 or data.get('identity') != identity:
            return {}
        entries = data.get('entries')
        if not isinstance(entries, dict):
            return {}
        valid = {}
        for key, entry in entries.items():
            if (not key.isdigit() or not isinstance(entry, dict)
                    or entry.get('state') not in ('allowed', 'friends-required')):
                continue
            checked = entry.get('checked_at')
            if (type(checked) in (int, float) and 0 <= now - checked < _PRIVATE_ACCESS_TTL):
                valid[key] = entry
        return valid
    except (OSError, ValueError, TypeError):
        return {}


def _save_private_access_cache(identity, entries):
    if _private_access_identity(_browser_session()) != identity:
        return
    # Bound the file and keep the newest decisions; cache neither HTML nor stream URLs.
    entries = dict(sorted(entries.items(), key=lambda item: item[1]['checked_at'],
                          reverse=True)[:_PRIVATE_ACCESS_CACHE_LIMIT])
    temporary = None
    try:
        path = _profile_path('private_access.json')
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(path),
                                         suffix='.tmp', delete=False) as stream:
            temporary = stream.name
            json.dump({'version': 1, 'identity': identity, 'entries': entries}, stream)
        os.replace(temporary, path)
    except OSError:
        utils.kodilog('XFreeHD {} PRIVATE_ACCESS cache_write_failed'.format(VERSION))
    finally:
        if temporary and os.path.exists(temporary):
            os.remove(temporary)


def _filter_private_access(rows):
    candidates = [row for row in rows if row.get('private')]
    if not candidates:
        return rows
    session = _browser_session()
    identity = _private_access_identity(session)
    if not identity:
        utils.notify('XFreeHD', 'Import signed-in cookies and User-Agent to filter friends-only videos.', duration=7000)
        return rows
    entries = _load_private_access_cache(identity, time.time())
    states, unchecked = {}, {}
    for row in candidates:
        key = _video_id(row['url'])
        if key in entries:
            states[row['url']] = entries[key]['state']
        else:
            unchecked.setdefault(key or row['url'], row)
    candidates = list(unchecked.values())
    cached = len(states)
    progress = None
    if candidates:
        try:
            progress = xbmcgui.DialogProgress()
            progress.create('XFreeHD', 'Checking private video access...')
        except Exception:
            progress = None
    cancelled = False
    checked = 0
    try:
        if candidates:
            with ThreadPoolExecutor(max_workers=min(4, len(candidates))) as pool:
                pending = {pool.submit(_probe_private_access, row): row['url'] for row in candidates}
                for future in as_completed(pending):
                    url = pending[future]
                    state = states[url] = future.result()
                    checked += 1
                    key = _video_id(url)
                    if key and state in ('allowed', 'friends-required'):
                        entries[key] = {'state': state, 'checked_at': time.time()}
                    if progress:
                        progress.update(int(100 * checked / len(candidates)),
                                        'Checking private videos: {} / {}'.format(checked, len(candidates)))
                        if progress.iscanceled():
                            cancelled = True
                            for task in pending:
                                task.cancel()
                            break
    finally:
        if progress:
            progress.close()
    if _private_access_identity(_browser_session()) != identity:
        utils.notify('XFreeHD', 'The browser session changed. Reload the list to check private access.', duration=7000)
        return rows
    if checked:
        _save_private_access_cache(identity, entries)
    blocked = {_video_id(url) or url for url, state in states.items() if state == 'friends-required'}
    uncertain = sum(state in ('unknown', 'login-required') for state in states.values())
    utils.kodilog('XFreeHD {} PRIVATE_ACCESS checked={} cached={} hidden={} unverified={} cancelled={}'.format(
        VERSION, checked, cached, len(blocked), uncertain, cancelled))
    if cancelled:
        utils.notify('XFreeHD', 'Access check cancelled. Unchecked private videos remain visible.', duration=7000)
    elif uncertain:
        utils.notify('XFreeHD', '{} private video access check(s) were inconclusive; those videos remain visible.'.format(uncertain), duration=7000)
    return [row for row in rows if not (row.get('private') and (_video_id(row['url']) or row['url']) in blocked)]


def _read_import_file(path):
    native = path
    read_succeeded = False
    try:
        if path.startswith('special://'):
            translate = getattr(xbmcvfs, 'translatePath', getattr(utils, 'TRANSLATEPATH', None))
            native = translate(path) if translate else path
        if os.path.isfile(native):
            if os.path.getsize(native) > _MAX_IMPORT:
                raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
            with open(native, 'rb') as stream:
                data = stream.read(_MAX_IMPORT + 1)
            if len(data) > _MAX_IMPORT:
                raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
            text = _decode_import(data)
            read_succeeded = True
            if text.strip():
                utils.kodilog('XFreeHD {} FILE_READ_OK method=local characters={}'.format(VERSION, len(text)))
                return text
    except _ImportError:
        raise
    except OSError:
        pass
    # Reopen before each method; platform builds differ in readBytes behavior.
    for method in ('read', 'readBytes'):
        try:
            stream = xbmcvfs.File(path)
            try:
                if callable(getattr(stream, 'size', None)) and stream.size() > _MAX_IMPORT:
                    raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
                reader = getattr(stream, method, None)
                if not reader:
                    continue
                data = reader() if method == 'read' else reader(_MAX_IMPORT + 1)
            finally:
                stream.close()
            if len(data) > _MAX_IMPORT:
                raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
            text = _decode_import(data)
            read_succeeded = True
            if text.strip():
                utils.kodilog('XFreeHD {} FILE_READ_OK method=vfs-{} characters={}'.format(VERSION, method, len(text)))
                return text
        except _ImportError as exc:
            if exc.code == 'FILE_SIZE':
                raise
        except Exception:
            pass
    if read_succeeded:
        raise _ImportError('EMPTY_FILE', 'The selected file is empty or Kodi returned no text.')
    raise _ImportError('FILE_READ', 'Kodi could not read the file. Try a local Downloads folder or check the network share.')


def _import_text(label):
    path = xbmcgui.Dialog().browseSingle(1, label, 'files', '.txt|.json|.cookies')
    return _read_import_file(path) if path else ''


def _settings():
    try:
        with open(_profile_path('settings.json'), encoding='utf-8') as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_setting(key, value):
    data = _settings()
    data[key] = value
    path = _profile_path('settings.json')
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                     dir=os.path.dirname(path), delete=False) as stream:
        temporary = stream.name
        json.dump(data, stream)
    try:
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def _site_host(url):
    parts = urlsplit(url)
    return parts.scheme == 'https' and (parts.hostname or '').lower() in (
        'xfreehd.com', 'www.xfreehd.com', 'beta.xfreehd.com')


def _page_url(url):
    resolved = _absolute(url)
    if not _site_host(resolved):
        raise _FetchError('This link is not an XFreeHD website page.')
    parts = urlsplit(resolved)
    return urlunsplit(('https', 'beta.xfreehd.com', parts.path or '/', parts.query, ''))


def _query(url, **changes):
    parts = urlsplit(url)
    values = dict(parse_qsl(parts.query, keep_blank_values=True))
    for key, value in changes.items():
        if value is None or value == '':
            values.pop(key, None)
        else:
            values[key] = str(value)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(values), ''))


def _request_headers(referer=BASE_URL, target=None):
    session = _browser_session()
    ua = session.get('user_agent') or getattr(utils, 'USER_AGENT', 'Mozilla/5.0')
    if not session.get('user_agent'):
        try:
            ua = utils._cf_get_identity('beta.xfreehd.com').get('user_agent') or ua
        except (AttributeError, TypeError):
            pass
    headers = {'User-Agent': ua, 'Referer': referer}
    if _site_host(target or referer):
        cookie = session.get('cookie', '')
        pairs = dict(part.strip().split('=', 1) for part in cookie.split(';') if '=' in part)
        pairs['enterModal'] = '1'
        headers['Cookie'] = '; '.join('{}={}'.format(k, v) for k, v in pairs.items())
    return headers


class _BrowserRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        if redirected:
            redirected.remove_header('Cookie')
            cookie = _request_headers(target=newurl).get('Cookie')
            if cookie:
                redirected.add_unredirected_header('Cookie', cookie)
        return redirected


def _challenge(html):
    lower = html.lower()
    title = re.search(r'<title\b[^>]*>\s*(.*?)</title>', lower, re.S)
    if title and any(title.group(1).startswith(value) for value in (
            'just a moment', 'attention required', 'checking your browser')):
        return True
    # Login/share Turnstile widgets and background scripts occur on usable pages.
    usable = bool(re.search(r'(?:class=["\'][^"\']*video-link|id=["\']hdplayer)', lower))
    return not usable and bool(re.search(
        r'(?:id=["\']challenge-(?:running|form)|checking your browser|cf-chl-managed)', lower))


def _request_route(url):
    path = urlsplit(url).path
    if path.startswith('/trends'):
        return 'trends'
    if path.startswith('/search'):
        return 'search'
    if path.startswith('/video/'):
        return 'video'
    if path.startswith('/ajax/'):
        return 'related-page'
    if path in ('/user', '/user/'):
        return 'account'
    return 'listing'


def _fetch(url, timeout=20, data=None, referer=BASE_URL):
    url = _page_url(url)
    session = _browser_session()
    manual = bool(session.get('cookie') or session.get('user_agent'))
    if manual and not (session.get('cookie') and session.get('user_agent')):
        raise _FetchError('Import both cookies and the matching User-Agent in Login / Browser Session.')
    headers = _request_headers(referer, url)
    if data is not None:
        headers['X-Requested-With'] = 'XMLHttpRequest'
    if not manual:
        # Preserve automatically established site cookies alongside the age cookie.
        try:
            req = Request(url)
            utils.cj.add_cookie_header(req)
            pairs = dict(part.strip().split('=', 1) for part in (req.get_header('Cookie') or '').split(';') if '=' in part)
            pairs['enterModal'] = '1'
            headers['Cookie'] = '; '.join('{}={}'.format(k, v) for k, v in pairs.items())
        except AttributeError:
            pass
    try:
        if manual:
            cookie = headers.pop('Cookie', '')
            headers.update({'Accept': 'text/html,application/json,*/*;q=0.8',
                            'Accept-Encoding': 'identity'})
            payload = urlencode(data).encode('utf-8') if data is not None else None
            if payload is not None:
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
            req = Request(url, data=payload, headers=headers)
            if cookie:
                req.add_unredirected_header('Cookie', cookie)
            with build_opener(_BrowserRedirect()).open(req, timeout=timeout) as response:
                result = _response_html(response)
        elif data is not None:
            result = utils._postHtml(url, form_data=data, headers=headers)
        else:
            result = utils.getHtml(url, BASE_URL, headers=headers)
    except HTTPError as exc:
        status = exc.code
        exc.close()
        raise _FetchError('This page returned HTTP {}. Refresh your browser session if needed.'.format(status),
                          status=status, reason='http') from None
    except _FetchError:
        raise
    except Exception:
        raise _FetchError('The page request failed. Check your connection or import a browser session.') from None
    if isinstance(result, bytes):
        result = result.decode('utf-8', 'replace')
    result = result or ''
    if _challenge(result):
        raise _FetchError('Cloudflare returned a challenge. Complete it in your browser and import the session.',
                          reason='challenge')
    if not result or re.search(r'<title>\s*Site Unavailable\s*</title>', result, re.I):
        raise _FetchError('XFreeHD did not return this page. Other pages may still be accessible.')
    utils.kodilog('XFreeHD {} PAGE_OK route={} browser_session={}'.format(
        VERSION, _request_route(url), manual))
    return result


def _images(card, base):
    result = []
    for img in card.nodes('img'):
        for key in ('data-src', 'data-original', 'src'):
            value = img.attrs.get(key, '')
            # Browser page saves rewrite src; data-src retains the live URL.
            if '_files/' in value or '_files%2f' in value.lower():
                continue
            url = _absolute(value, base)
            if url and url not in result:
                result.append(url)
    return result


def _video_id(url):
    match = re.search(r'/video/(\d+)(?:/|$)', urlsplit(url).path)
    return match.group(1) if match else ''


def _listing(doc, base):
    rows, seen = [], set()
    for anchor in doc.nodes('a', cls='video-link'):
        url = _absolute(anchor.attrs.get('href'), base)
        vid = _video_id(url)
        if not vid or vid in seen or not _site_host(url):
            continue
        seen.add(vid)
        title = anchor.first(cls='video-title-new')
        image = anchor.first('img')
        name = title.text() if title else ''
        if not name and image:
            name = image.attrs.get('title') or image.attrs.get('alt') or ''
        name = name.strip() or 'Video ' + vid
        duration = anchor.first(cls='duration-new')
        hd = anchor.first(cls='hd-text-icon')
        private = any(n.text().strip().upper() == 'PRIVATE' for n in anchor.nodes())
        rows.append({'url': _page_url(url), 'name': ('[Private] ' if private else '') + name,
                     'images': _images(anchor, base), 'duration': duration.text() if duration else '',
                     'quality': 'HD' if hd and hd.text().strip() == 'HD' else '', 'private': private})
    return rows


def _categories(doc, base):
    rows, seen = [], set()
    for anchor in doc.nodes('a'):
        url = _absolute(anchor.attrs.get('href'), base)
        if not _site_host(url) or not re.fullmatch(r'/videos/[^/]+/?', urlsplit(url).path):
            continue
        title = anchor.first(cls='title-truncate')
        image = anchor.first('img')
        if not image or url in seen:
            continue
        seen.add(url)
        name = title.text() if title else image.attrs.get('title') or image.attrs.get('alt') or anchor.text()
        count = anchor.first(cls='badge')
        rows.append({'name': name, 'url': _page_url(url), 'count': count.text() if count else '',
                     'images': _images(anchor, base)})
    return rows


def _page_number(url):
    parts = urlsplit(url)
    try:
        return int(dict(parse_qsl(parts.query)).get('page', '1'))
    except ValueError:
        return 1


def _next_page(doc, url):
    for anchor in doc.nodes('a'):
        if not (anchor.has_class('prevnext') or 'next' in anchor.attrs.get('rel', '').split()):
            continue
        text = anchor.text().casefold().strip()
        if not (text in ('»', '›', '>', 'next', 'next page') or 'next' in anchor.attrs.get('rel', '').split()):
            continue
        target = _absolute(anchor.attrs.get('href'), url)
        if not target or not _site_host(target) or target == url:
            continue
        old, new = urlsplit(url), urlsplit(target)
        values = dict(parse_qsl(old.query, keep_blank_values=True))
        values.update(dict(parse_qsl(new.query, keep_blank_values=True)))
        path = new.path
        if ((old.path.startswith('/trends/') and new.path.rstrip('/') == '/trends')
                or (old.path.startswith('/search/') and new.path.rstrip('/') == '/search')):
            path = old.path
        target = urlunsplit((new.scheme, new.netloc, path, urlencode(values), ''))
        if target != url:
            return _page_url(target)
    return ''


def _add_next(doc, url, mode='List'):
    target = _next_page(doc, url)
    if target:
        site.add_dir(_white('Next Page...'), target, mode, site.img_next)


def _search_order():
    value = _settings().get('search_order', '')
    return value if value in dict(SEARCH_ORDERS).values() else ''


def _order_name(value):
    return next((name for name, code in SEARCH_ORDERS if code == value), 'Relevance')


def _is_search_url(url):
    return bool(_site_host(url) and re.fullmatch(r'/search(?:/[^/]+)?/?', urlsplit(url).path))


def _search_category(url):
    match = re.fullmatch(r'/search(?:/([^/]+))?/?', urlsplit(url).path)
    return match.group(1) or '' if match else ''


def _search_category_choices(doc=None, current_url=''):
    entries = {}
    if doc is not None:
        for anchor in doc.nodes('a'):
            target = _absolute(anchor.attrs.get('href'))
            if not _is_search_url(target):
                continue
            slug = _search_category(target)
            name = anchor.text().strip()
            if slug and name and re.fullmatch(r'[A-Za-z0-9_-]+', slug):
                entries[slug] = name
        if entries:
            # The selected sidebar category may be plain text rather than a link.
            current = _search_category(current_url)
            if current and current not in entries:
                entries[current] = next((name for name, slug in SEARCH_CATEGORIES if slug == current),
                                        current.replace('-', ' ').title())
            rows = sorted(((name, slug) for slug, name in entries.items()), key=lambda pair: pair[0].casefold())
            # Persist the sidebar once it changes; opening the selector needs no new page request.
            if _settings().get('search_categories') != [list(row) for row in rows]:
                try:
                    _save_setting('search_categories', rows)
                except OSError:
                    pass
    if not entries:
        saved = _settings().get('search_categories', [])
        if isinstance(saved, list):
            for item in saved:
                if (isinstance(item, (list, tuple)) and len(item) == 2
                        and all(isinstance(value, str) for value in item)
                        and item[0] and re.fullmatch(r'[A-Za-z0-9_-]+', item[1])):
                    entries[item[1]] = item[0]
        if not entries:
            entries = {slug: name for name, slug in SEARCH_CATEGORIES}
    return [('All Categories', '')] + sorted(((name, slug) for slug, name in entries.items()),
                                             key=lambda pair: pair[0].casefold())


def _search_category_url(url, category):
    parts = urlsplit(_page_url(url))
    path = '/search' + ('/' + category if category else '')
    return _query(urlunsplit((parts.scheme, parts.netloc, path, parts.query, '')), page=None)


def _show_listing(url, search_filter=True):
    try:
        url = _page_url(url)
        is_search = search_filter and _is_search_url(url)
        if is_search:
            order = dict(parse_qsl(urlsplit(url).query)).get('o', '')
            site.add_dir(_white('Search Order: ' + _order_name(order)), url, 'SearchOrder', site.img_cat, Folder=False)
            category = _search_category(url)
            category_name = next((name for name, slug in _search_category_choices() if slug == category),
                                 category.replace('-', ' ').title()) if category else 'All'
            site.add_dir(_white('Category: ' + category_name), url, 'SearchCategory', site.img_cat, Folder=False)
        doc = _Document(_fetch(url)).root
        if is_search:
            _search_category_choices(doc, url)
        rows = _listing(doc, url)
        visible = _add_videos(rows)
        _add_next(doc, url)
        if not rows:
            utils.notify('XFreeHD', 'No videos found on this page.')
        elif not visible:
            utils.notify('XFreeHD', 'No accessible videos remain on this page. Try the next page if available.')
    except _FetchError as exc:
        _report_fetch_error(exc)


@site.register(default_mode=True)
def Main(url=None):
    order = _order_name(_search_order())
    context = [(_white('Search Order'), 'RunPlugin({})'.format(_plugin_url('SearchOrder', BASE_URL + 'search')))]
    site.add_dir(_white('Trends'), '', 'Trends', site.img_cat)
    site.add_dir(_white('Categories'), BASE_URL + 'categories', 'Categories', site.img_cat)
    site.add_dir(_white('Search [' + order + ']'), BASE_URL + 'search', 'Search', site.img_search, contextm=context)
    site.add_dir(_white('Login / Browser Session'), '', 'BrowserAccess', site.image)
    _show_listing(BASE_URL)
    utils.eod(cache=False)


def _trend_values(url=''):
    settings = _settings()
    country = settings.get('country', 'ca')
    period = settings.get('period', '')
    if url:
        parts = urlsplit(url)
        match = re.fullmatch(r'/trends(?:/([a-z]{2}))?/?', parts.path)
        if match:
            country = match.group(1) or ''
            period = dict(parse_qsl(parts.query)).get('t', '')
    country = country if country in dict(COUNTRIES).values() else 'ca'
    period = period if period in dict(PERIODS).values() else ''
    return country, period


def _trend_url(country, period):
    return _query(BASE_URL + 'trends' + ('/' + country if country else ''), t=period)


@site.register()
def Trends(url=None):
    country, period = _trend_values(url)
    current = _page_url(url) if url else _trend_url(country, period)
    country_name = next(name for name, code in COUNTRIES if code == country)
    period_name = next(name for name, code in PERIODS if code == period)
    site.add_dir(_white('Time: ' + period_name), current, 'TrendPeriod', site.img_cat, Folder=False)
    site.add_dir(_white('Country: ' + country_name), current, 'TrendCountry', site.img_cat, Folder=False)
    _show_listing(current, search_filter=False)
    utils.eod(cache=False)


def _select(title, options, current):
    codes = [code for _, code in options]
    index = xbmcgui.Dialog().select(title, [name for name, _ in options], preselect=codes.index(current) if current in codes else 0)
    return codes[index] if index >= 0 else None


@site.register()
def TrendPeriod(url):
    country, period = _trend_values(url)
    value = _select('Select time period', PERIODS, period)
    if value is not None:
        _save_setting('period', value)
        _update('Trends', _trend_url(country, value))


@site.register()
def TrendCountry(url):
    country, period = _trend_values(url)
    value = _select('Select country', COUNTRIES, country)
    if value is not None:
        _save_setting('country', value)
        _update('Trends', _trend_url(value, period))


@site.register()
def Categories(url=BASE_URL + 'categories'):
    try:
        url = _page_url(url)
        doc = _Document(_fetch(url)).root
        rows = _categories(doc, url)
        _artwork(rows)
        for row in rows:
            name = row['name'] + (' [' + row['count'] + ' videos]' if row['count'] else '')
            site.add_dir(_white(name), row['url'], 'List', row['image'])
        _add_next(doc, url, 'Categories')
        if not rows:
            utils.notify('XFreeHD', 'No categories found on this page.')
    except _FetchError as exc:
        _report_fetch_error(exc)
    utils.eod()


@site.register()
def List(url):
    _show_listing(url)
    utils.eod(cache=False)


@site.register()
def Search(url=BASE_URL + 'search', keyword=None):
    if not keyword:
        site.add_dir(_white('Search Order: ' + _order_name(_search_order())), BASE_URL + 'search', 'SearchOrder', site.img_cat, Folder=False)
        site.search_dir(BASE_URL + 'search', 'Search')
    else:
        target = _query(BASE_URL + 'search', search_query=keyword, search_type='videos', o=_search_order())
        List(target)


@site.register()
def SearchOrder(url):
    current = dict(parse_qsl(urlsplit(url).query)).get('o', _search_order())
    value = _select('Select sort order', SEARCH_ORDERS, current)
    if value is not None:
        _save_setting('search_order', value)
        if 'search_query' in dict(parse_qsl(urlsplit(url).query)):
            _update('List', _query(url, o=value, page=None))
        else:
            xbmc.executebuiltin('Container.Refresh')


@site.register()
def SearchCategory(url):
    if not _is_search_url(url):
        return
    value = _select('Filter search by category', _search_category_choices(), _search_category(url))
    if value is not None:
        _update('List', _search_category_url(url, value))


def _metadata(doc):
    result = {'Categories': [], 'Tags': []}
    for anchor in doc.nodes('a'):
        link = _absolute(anchor.attrs.get('href'))
        if not _site_host(link):
            continue
        path = urlsplit(link).path
        kind = ('Categories' if anchor.has_class('standard-link') and path.startswith('/videos/')
                else 'Tags' if anchor.has_class('tag') and path.startswith('/tag/') else '')
        item = (anchor.text(), _page_url(link))
        if kind and item[0] and item not in result[kind]:
            result[kind].append(item)
    return result


@site.register()
def LookupInfo(url):
    try:
        data = _metadata(_Document(_fetch(url)).root)
        entries = [
            ('{} - {}'.format(label, name), link)
            for kind, label in (('Categories', 'Category'), ('Tags', 'Tag'))
            for name, link in data[kind]
        ]
        if not entries:
            utils.notify('XFreeHD', 'No categories or tags were found.')
            return
        choice = xbmcgui.Dialog().select('Lookup Info', [name for name, _ in entries])
        if 0 <= choice < len(entries):
            _update('List', entries[choice][1])
    except _FetchError as exc:
        _report_fetch_error(exc)


@site.register()
def Related(url):
    _update('RelatedList', url)


@site.register()
def RelatedList(url):
    try:
        parts = urlsplit(url)
        page = max(1, int(dict(parse_qsl(parts.fragment)).get('xfrelated', '1')))
        original = _page_url(url)
        vid = _video_id(original)
        if not vid:
            raise _FetchError('The related-video link does not contain a video ID.')
        if page == 1:
            doc = _Document(_fetch(original)).root
            scope = doc.first(attr=('id', 'related_videos'))
            if scope is None:
                raise _FetchError('No related videos were found.')
        else:
            response = json.loads(_fetch(BASE_URL + 'ajax/related_videos',
                                         data={'video_id': vid, 'page': str(page)}, referer=original))
            if str(response.get('status')) != '1':
                raise _FetchError('XFreeHD did not return the next related-video page.')
            scope = _Document(response.get('videos', '') + response.get('pagination', '')).root
        rows = _listing(scope, original)
        visible = _add_videos(rows)
        for anchor in scope.nodes('a', cls='prevnext'):
            match = re.search(r'(?:#|&)rpage=(\d+)', anchor.attrs.get('href', ''))
            if match and int(match.group(1)) > page:
                target = original + '#xfrelated=' + match.group(1)
                site.add_dir(_white('Next Page...'), target, 'RelatedList', site.img_next)
                break
        if not rows:
            utils.notify('XFreeHD', 'No related videos were found on this page.')
        elif not visible:
            utils.notify('XFreeHD', 'No accessible related videos remain on this page.')
    except (ValueError, TypeError):
        utils.notify('XFreeHD', 'The related-video response was not valid. Please retry.')
    except _FetchError as exc:
        _report_fetch_error(exc)
    utils.eod(cache=False)


def _sources(doc, base):
    scope = doc.first('video', attr=('id', 'hdPlayer'))
    scopes = [scope] if scope else list(doc.nodes('video'))
    result, seen = [], set()
    for video in scopes:
        for node in [video] + list(video.nodes('source')):
            value = node.attrs.get('data-src') or node.attrs.get('src') or ''
            if '_files/' in value:
                continue
            url = _absolute(value, base)
            if not url or url in seen or not re.search(r'\.(mp4|m3u8|mpd|webm)(?:[?#]|$)', url, re.I):
                continue
            seen.add(url)
            label = node.attrs.get('title') or node.attrs.get('label') or ('HD' if 'hd' in urlsplit(url).path.lower() else 'SD')
            result.append((label, url))
    return result


def _stream_headers(url, referer):
    headers = _request_headers(referer, url)
    headers['Accept-Encoding'] = 'identity'
    return url + '|' + urlencode(headers)


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download=download)
    try:
        url = _page_url(url)
        doc = _Document(_fetch(url)).root
        sources = _sources(doc, url)
        if not sources:
            access = _video_access(doc, url)
            if access == 'friends-required':
                message = 'Your account must be subscribed to or friends with this uploader to view this video.'
            elif access == 'login-required':
                message = 'Your account login was not detected. Refresh the signed-in browser session.'
            else:
                message = ('This private video requires a signed-in browser session and permission from its owner.'
                           if 'private video' in doc.text().lower() else 'No playable source was found. Refresh the browser session if login is required.')
            utils.notify('XFreeHD', message, duration=8000)
            return
        labels, links = [], {}
        for label, link in sorted(sources, key=lambda pair: (pair[0] != 'HD', pair[0])):
            title = label
            while title in links:
                title += ' (alternate)'
            labels.append(title)
            links[title] = link
        stream = utils.selector('Select quality', links, setting_valid='qualityask', sort_by=lambda value: labels.index(value))
        if stream:
            vp.play_from_direct_link(_stream_headers(stream, url))
    except _FetchError as exc:
        _report_fetch_error(exc)
    finally:
        progress = getattr(vp, 'progress', None)
        if progress:
            progress.close()


def _auth_user(doc):
    for anchor in doc.nodes('a'):
        link = _absolute(anchor.attrs.get('href'))
        if not _site_host(link):
            continue
        path = urlsplit(link).path.rstrip('/')
        if path == '/logout' or (path == '/user' and 'profile' in anchor.text().lower()):
            return True
    return False


def _test_browser_access():
    html = _fetch(BASE_URL, timeout=12)
    doc = _Document(html).root
    if not _listing(doc, BASE_URL):
        raise _FetchError('The front page did not return a video listing. The imported session has been kept.')
    if _auth_user(doc):
        utils.notify('XFreeHD', 'Videos loaded. Your account is signed in.', duration=8000)
        return
    session = _browser_session()
    if session.get('cookie') and session.get('user_agent'):
        xbmcgui.Dialog().ok('XFreeHD browser session',
            'Videos loaded, but an account login was not detected. Export cookies AFTER logging in to '
            'XFreeHD and import them again. Browsing remains available; your imported session has been kept.')
    else:
        utils.notify('XFreeHD', 'Public videos loaded. Import a signed-in browser session to use your account.')


@site.register()
def BrowserAccess(url=None):
    session = _browser_session()
    for title, action in (
        ('Import Cookie + User-Agent TXT', 'session_file'),
        ('Import Cookie TXT / JSON', 'cookie_file'),
        ('Import User-Agent TXT / JSON', 'ua_file'),
        ('Paste Cookie header [' + ('saved' if session.get('cookie') else 'not set') + ']', 'cookie_paste'),
        ('Paste User-Agent [' + ('saved' if session.get('user_agent') else 'not set') + ']', 'ua_paste'),
        ('Test Browsing / Account Login', 'test'),
        ('Clear Private Access Cache', 'clear_private_cache'),
        ('Clear Browser Session', 'clear'),
        ('Help: Browser Login', 'help')):
        site.add_dir(_white(title), action, 'BrowserAction', site.img_cat, Folder=False)
    site.add_dir(_white('Open XFreeHD'), BASE_URL, 'Main', site.image)
    utils.eod(cache=False)


@site.register()
def BrowserAction(url):
    action = url
    session = _browser_session()
    try:
        if action == 'help':
            xbmcgui.Dialog().textviewer('XFreeHD Browser Login',
                '1. Open https://beta.xfreehd.com/ in Firefox or Chrome. Log in and complete Cloudflare verification.\n\n'
                '2. Export this site\'s cookies AFTER logging in. Netscape TXT and cookie JSON exports are accepted. '
                'Import the file here, or paste the complete Cookie request header. Include the account session '
                'cookie (the existing addon uses FX), not just cf_clearance.\n\n'
                '3. In Firefox open about:support, then copy User Agent under Application Basics. '
                'Paste the value here, or save it as a TXT file and import that file on Fire TV. '
                'In Chrome use Developer Tools > Network > Request Headers > User-Agent.\n\n'
                'TV file import: use Import Cookie TXT / JSON and Import User-Agent TXT / JSON for '
                'two separate files. Alternatively, choose Import Cookie + User-Agent TXT for one file '
                'containing these two lines, filled with your actual values:\n'
                'Cookie: complete cookie header\nUser-Agent: exact browser user agent\n\n'
                '4. Choose Test Browsing / Account Login. A working public listing does not prove you are signed in.\n\n'
                'Keep the browser and Kodi on the same internet connection, including matching VPN/proxy use. '
                'Refresh the cookies and User-Agent when the session expires. The addon reuses your completed '
                'browser login; it does not solve Turnstile inside Kodi.\n\n'
                'Confirmed private-video access is cached for one hour. If friendship or subscriber '
                'access changes, choose Clear Private Access Cache and reopen the video list. '
                'Importing or clearing the browser session also invalidates the cache.\n\n'
                'Imported credentials stay in the Kodi profile and are not written to the diagnostic log.')
            return
        if action == 'clear_private_cache':
            _save_browser_session(session)
            utils.notify('XFreeHD', 'Private access cache cleared. Private videos will be checked on the next list load.', duration=7000)
            return
        if action == 'clear':
            path = _profile_path('browser_session.json')
            if os.path.exists(path):
                os.remove(path)
            _clear_private_access_cache()
            utils.notify('XFreeHD', 'Imported browser session cleared.')
            xbmc.executebuiltin('Container.Refresh')
            return
        if action == 'test':
            _test_browser_access()
            return
        if action == 'session_file':
            text = _import_text('Import Cookie + User-Agent TXT')
            if not text:
                return
            session.update(_session_bundle(text))
            _save_browser_session(session)
            utils.kodilog('XFreeHD {} IMPORT_OK action=session_file'.format(VERSION))
            utils.notify('XFreeHD', 'Cookies and User-Agent imported. Choose Test Browsing / Account Login.', duration=8000)
            xbmc.executebuiltin('Container.Refresh')
            return
        if action not in ('cookie_paste', 'cookie_file', 'ua_paste', 'ua_file'):
            return
        is_cookie = action.startswith('cookie_')
        label = 'Cookie header' if is_cookie else 'User-Agent'
        text = _import_text('Import ' + label) if action.endswith('_file') else xbmcgui.Dialog().input('Paste ' + label)
        if not text:
            return
        value = _cookie_header(text) if is_cookie else _user_agent(text)
        session['cookie' if is_cookie else 'user_agent'] = value
        _save_browser_session(session)
        utils.kodilog('XFreeHD {} IMPORT_OK action={}'.format(VERSION, action))
        utils.notify('XFreeHD', label + ' saved. ' + ('Choose Test Browsing / Account Login.'
                     if session.get('cookie') and session.get('user_agent') else 'Import the other value next.'), duration=8000)
        xbmc.executebuiltin('Container.Refresh')
    except _FetchError as exc:
        _report_fetch_error(exc)
    except _ImportError as exc:
        utils.kodilog('XFreeHD {} IMPORT_FAILED action={} code={}'.format(VERSION, action, exc.code))
        xbmcgui.Dialog().ok('XFreeHD import failed ({})'.format(exc.code), str(exc))
    except Exception as exc:
        code = 'USER_AGENT_FORMAT' if action.startswith('ua_') and isinstance(exc, (ValueError, TypeError)) else 'IMPORT_ERROR'
        utils.kodilog('XFreeHD {} IMPORT_FAILED action={} code={} type={}'.format(VERSION, action, code, type(exc).__name__))
        xbmcgui.Dialog().ok('XFreeHD import failed ({})'.format(code), 'Check the selected file or pasted text and retry.')
