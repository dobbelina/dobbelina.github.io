'''
    Cumination
    Copyright (C) 2019 Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from resources.lib import utils
from resources.lib.customsite import CustomSite

site = CustomSite('G3nX3nnIaL', 'mylust')
BASE_URL = 'https://mylust.com/'


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', BASE_URL + 'categories/', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Best Videos[/COLOR]', BASE_URL + 'best/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]New Videos[/COLOR]', BASE_URL + 'latest-updates/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Most Viewed[/COLOR]', BASE_URL + 'most-popular/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Top Rated[/COLOR]', BASE_URL + 'top-rated/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', BASE_URL + 'search/', 'Search', site.img_search)
    List(BASE_URL + 'videos/')
    utils.eod()


@site.register()
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    
    # Split HTML into individual video items to prevent cross-item matching
    items = re.split(r'(?=<div[^>]*class="item[^"]*"[^>]*data-video-id)', listhtml)
    items = [x for x in items if 'data-video-id' in x]
    
    for item in items:
        # Extract each field from its own isolated item block
        videopage = re.compile(r'<a[^>]+href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(item)
        name = re.compile(r'alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(item)
        img = re.compile(r'data-jpg="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(item)
        duration = re.compile(r'class="duration">([^<]+)</div>', re.DOTALL | re.IGNORECASE).findall(item)
        
        if videopage and name and img and duration:
            name = utils.cleantext(name[0].strip())
            videopage = videopage[0] if videopage[0].startswith('http') else BASE_URL[:-1] + videopage[0]
            site.add_download_link(name, videopage, 'Playvid', img[0], duration=duration[0].strip())
    
    # Pagination - <li class="next"><a href="URL">Next</a></li>
    next_page = re.compile(r'class="next"><a[^>]+href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not next_page:
        next_page = re.compile(r'<link[^>]+rel="next"[^>]+href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    
    if next_page:
        np = next_page[0]
        site.add_dir('Next Page', np if np.startswith('http') else BASE_URL[:-1] + np, 'List', site.img_next)
    
    utils.eod()


@site.register()
def Categories(url):
    try:
        cathtml = utils.getHtml(url, '')
    except:
        return None
    
    # Match category items - MyLust structure
    # <div class="item"> <a data-id="..." title="NAME" href="URL"> <img src="IMG"> <span class="video_count">COUNT videos</span>
    match = re.compile(r'<div[^>]*class="item"[^>]*>.*?<a[^>]*title="([^"]+)"[^>]*href="([^"]+)"[^>]*>.*?<img[^>]+src="([^"]+)"[^>]*>.*?<span[^>]*class="video_count">([^<]+)</span>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    
    for name, catpage, img, count in match:
        name = "{} [COLOR hotpink]({})[/COLOR]".format(utils.cleantext(name.strip()), count.strip())
        catpage = catpage if catpage.startswith('http') else BASE_URL[:-1] + catpage
        site.add_dir(name, catpage, 'List', img)
    
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    
    try:
        videopage = utils.getHtml(url, '')
    except:
        vp.progress.close()
        return
    
    videolink = None
    
    # Pattern 1: <source> tag with MP4 (prefer 1080p/720p)
    match = re.compile(r'<source[^>]+src="([^"]+)"[^>]*title="1080p"', re.DOTALL | re.IGNORECASE).findall(videopage)
    if match:
        videolink = match[0]
    else:
        match = re.compile(r'<source[^>]+src="([^"]+)"[^>]*title="720p"', re.DOTALL | re.IGNORECASE).findall(videopage)
        if match:
            videolink = match[0]
    
    # Pattern 2: Any <source> tag with MP4
    if not videolink:
        match = re.compile(r'<source[^>]+src="([^"]+\.mp4[^"]*)"', re.DOTALL | re.IGNORECASE).findall(videopage)
        if match:
            videolink = match[0]
    
    # Pattern 3: JSON-LD contentUrl
    if not videolink:
        match = re.compile(r'"contentUrl"\s*:\s*"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
        if match:
            videolink = match[0]
    
    # Pattern 4: get_file URL
    if not videolink:
        match = re.compile(r'(https://mylust\.com/get_file/[^"\']+)', re.DOTALL | re.IGNORECASE).findall(videopage)
        if match:
            videolink = match[0]
    
    if videolink:
        videolink = videolink.replace('&amp;', '&')
        vp.play_from_direct_link(videolink + '|verifypeer=false')
    else:
        utils.notify('Video not found', 'Could not extract video source')
    
    vp.progress.close()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        title = keyword.replace(' ', '+')
        searchUrl = BASE_URL + 'search/?q=' + title
        List(searchUrl)