'''CuMination custom-site provider for XVideos Red.

Target: CuMination 1.1.200+ on Kodi 19+ / Python 3.
Authentication uses a browser session cookie supplied by the user. The cookie
is stored only in the local CuMination profile and is never written to logs.
'''

import html
import json
import os
import re
import gzip
import zlib
import ast
import base64
import hashlib
import time
from datetime import date
from html.parser import HTMLParser
from http.cookiejar import Cookie, CookieJar

from kodi_six import xbmc, xbmcvfs
from six.moves import urllib_parse, urllib_request

from resources.lib import utils
from resources.lib.customsite import CustomSite


AUTHOR = 'EvelK'
SITE_NAME = 'xvideos_red'
BASE_URL = 'https://www.xvideos.red/'
BEST_URL = urllib_parse.urljoin(BASE_URL, 'best-of-red')
SESSION_FILE = os.path.join(utils.profileDir, 'xvideos_red_session.txt')
FILTERS_FILE = os.path.join(utils.profileDir, 'xvideos_red_filters.json')
HOME_CACHE_FILE = os.path.join(utils.profileDir, 'xvideos_red_home_cache.json')
HOME_CACHE_SECONDS = 300
VERSION = '1.1.7'
_REQUEST_PREFERENCES = None
_PAGE_MEMO = []
_CONFIG_MEMO = []

DEFAULT_FILTERS = {
    'orientation': 'straight',
    'country': 'CA',
    'country_name': 'Canada',
    'best_month': '2026-09',
    'channels_url': BASE_URL + 'channels-index/premium',
    'pornstars_url': BASE_URL + 'pornstars-index',
    'pornstars_orientation': 'straight',
}
ORIENTATIONS = [('Straight', 'straight'), ('Gay', 'gay'), ('Trans', 'shemale')]
COUNTRIES = {'AD': 'Andorra', 'AE': 'United Arab Emirates', 'AF': 'Afghanistan', 'AG': 'Antigua And Barbuda', 'AL': 'Albania', 'AM': 'Armenia', 'AN': 'Netherlands Antilles', 'AO': 'Angola', 'AQ': 'Antarctica', 'AR': 'Argentina', 'AS': 'American Samoa', 'AT': 'Austria', 'AU': 'Australia', 'AW': 'Aruba', 'AX': 'Land Islands', 'AZ': 'Azerbaijan', 'BA': 'Bosnia And Herzegovina', 'BB': 'Barbados', 'BD': 'Bangladesh', 'BE': 'Belgium', 'BF': 'Burkina Faso', 'BG': 'Bulgaria', 'BI': 'Burundi', 'BJ': 'Benin', 'BN': 'Brunei Darussalam', 'BO': 'Bolivia', 'BQ': 'Caribbean Netherlands', 'BR': 'Brazil', 'BS': 'Bahamas', 'BW': 'Botswana', 'BY': 'Belarus', 'BZ': 'Belize', 'CA': 'Canada', 'CC': 'Cocos Keeling Islands', 'CD': 'Congo The Democratic Republic Of The', 'CF': 'Central African Republic', 'CG': 'Congo', 'CH': 'Switzerland', 'CI': 'Cote D Ivoire', 'CK': 'Cook Islands', 'CL': 'Chile', 'CM': 'Cameroon', 'CN': 'China', 'CO': 'Colombia', 'CR': 'Costa Rica', 'CU': 'Cuba', 'CV': 'Cape Verde', 'CW': 'Cura Ao', 'CY': 'Cyprus', 'CZ': 'Czech Republic', 'DE': 'Germany', 'DJ': 'Djibouti', 'DK': 'Denmark', 'DM': 'Dominica', 'DO': 'Dominican Republic', 'DZ': 'Algeria', 'EC': 'Ecuador', 'EE': 'Estonia', 'EG': 'Egypt', 'ES': 'Spain', 'ET': 'Ethiopia', 'FI': 'Finland', 'FJ': 'Fiji', 'FO': 'Faroe Islands', 'FR': 'France', 'GA': 'Gabon', 'GB': 'United Kingdom', 'GE': 'Georgia', 'GH': 'Ghana', 'GI': 'Gibraltar', 'GM': 'Gambia', 'GN': 'Guinea', 'GR': 'Greece', 'GT': 'Guatemala', 'HK': 'Hong Kong', 'HN': 'Honduras', 'HR': 'Croatia', 'HT': 'Haiti', 'HU': 'Hungary', 'ID': 'Indonesia', 'IE': 'Ireland', 'IL': 'Israel', 'IM': 'Isle Of Man', 'IN': 'India', 'IQ': 'Iraq', 'IR': 'Iran Islamic Republic Of', 'IS': 'Iceland', 'IT': 'Italy', 'JM': 'Jamaica', 'JO': 'Jordan', 'JP': 'Japan', 'KE': 'Kenya', 'KG': 'Kyrgyzstan', 'KH': 'Cambodia', 'KR': 'Korea', 'KW': 'Kuwait', 'KY': 'Cayman Islands', 'KZ': 'Kazakhstan', 'LA': 'Lao People S Democratic Republic', 'LB': 'Lebanon', 'LK': 'Sri Lanka', 'LR': 'Liberia', 'LS': 'Lesotho', 'LT': 'Lithuania', 'LU': 'Luxembourg', 'LV': 'Latvia', 'MA': 'Morocco', 'MC': 'Monaco', 'MD': 'Moldova Republic Of', 'ME': 'Montenegro', 'MH': 'Marshall Islands', 'MK': 'Macedonia', 'MM': 'Myanmar', 'MO': 'Macao', 'MR': 'Mauritania', 'MS': 'Montserrat', 'MT': 'Malta', 'MU': 'Mauritius', 'MV': 'Maldives', 'MW': 'Malawi', 'MX': 'Mexico', 'MZ': 'Mozambique', 'NA': 'Namibia', 'NC': 'New Caledonia', 'NE': 'Niger', 'NG': 'Nigeria', 'NI': 'Nicaragua', 'NL': 'Netherlands', 'NO': 'Norway', 'NP': 'Nepal', 'NZ': 'New Zealand', 'PA': 'Panama', 'PE': 'Peru', 'PF': 'French Polynesia', 'PH': 'Philippines', 'PK': 'Pakistan', 'PL': 'Poland', 'PR': 'Puerto Rico', 'PS': 'Palestinian Territory', 'PT': 'Portugal', 'PW': 'Palau', 'PY': 'Paraguay', 'QA': 'Qatar', 'RE': 'Reunion', 'RO': 'Romania', 'RS': 'Serbia', 'RU': 'Russia', 'RW': 'Rwanda', 'SA': 'Saudi Arabia', 'SC': 'Seychelles', 'SD': 'Sudan', 'SE': 'Sweden', 'SG': 'Singapore', 'SI': 'Slovenia', 'SK': 'Slovakia', 'SN': 'Senegal', 'SR': 'Suriname', 'SV': 'El Salvador', 'SY': 'Syrian Arab Republic', 'SZ': 'Swaziland', 'TC': 'Turks And Caicos Islands', 'TG': 'Togo', 'TH': 'Thailand', 'TJ': 'Tajikistan', 'TN': 'Tunisia', 'TR': 'Turkey', 'TT': 'Trinidad And Tobago', 'TW': 'Taiwan', 'TZ': 'Tanzania United Republic Of', 'UA': 'Ukraine', 'UG': 'Uganda', 'US': 'United States', 'UY': 'Uruguay', 'UZ': 'Uzbekistan', 'VC': 'Saint Vincent And The Grenadines', 'VE': 'Venezuela', 'VG': 'Virgin Islands British', 'VI': 'Virgin Islands U S', 'VN': 'Vietnam', 'WS': 'Samoa', 'YE': 'Yemen', 'ZA': 'South Africa', 'ZM': 'Zambia', 'ZW': 'Zimbabwe'}

site = CustomSite(AUTHOR, SITE_NAME)


class _Node:
    def __init__(self, tag='', attrs=None, parent=None):
        self.tag = tag
        self.attrs = dict(attrs or [])
        self.parent = parent
        self.children = []

    def get(self, key, default=''):
        return self.attrs.get(key, default)

    def has_class(self, name):
        return name in self.get('class').split()

    def find_all(self, predicate):
        result = []
        for child in self.children:
            if isinstance(child, _Node):
                if predicate(child):
                    result.append(child)
                result.extend(child.find_all(predicate))
        return result

    def text(self):
        if self.tag in ('script', 'style'):
            return ''
        return ''.join(child.text() if isinstance(child, _Node) else child
                       for child in self.children)

    def raw_text(self):
        return ''.join(child.raw_text() if isinstance(child, _Node) else child
                       for child in self.children)


class _PageParser(HTMLParser):
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
            'link', 'meta', 'param', 'source', 'track', 'wbr'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = _Node()
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        node = _Node(tag, [(k, v or '') for k, v in attrs], self.stack[-1])
        self.stack[-1].children.append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                del self.stack[index:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def _js_string(literal):
    '''Read a string literal, without evaluating any page code.'''
    try:
        return json.loads(literal) if literal.startswith('"') else ast.literal_eval(literal.replace('\\/', '/'))
    except Exception:
        return ''


def _script_markup(source):
    '''Recover the HTML written by the site's native thumbnail helpers.'''
    literal = r'''("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')'''
    calls = re.compile(
        r'\b(?:document\.write\s*\(\s*(?:xv\.thumbs\.replaceThumbUrl\s*\(\s*)?'
        r'|xv\.thumbs\.casting\.displayRandomThumb\s*\(\s*)' + literal + r'\s*(?=[,)])',
        re.DOTALL)
    def render(match):
        # Keep the original script so embedded configuration remains available.
        markup = []
        for call in calls.finditer(match.group(1)):
            value = _js_string(call.group(1))
            if isinstance(value, str) and re.search(r'<(?:div|a|picture|img|p)\b', value):
                markup.append(value.replace('\\/', '/'))
        return match.group(0) + ''.join(markup)
    return re.sub(r'<script\b[^>]*>([\s\S]*?)</script\s*>', render, source or '', flags=re.IGNORECASE)


def _memo_get(memo, source):
    for index, (previous, value) in enumerate(memo):
        if previous is source or previous == source:
            if index:
                memo.insert(0, memo.pop(index))
            return value
    return None


def _memo_put(memo, source, value):
    memo.insert(0, (source, value))
    del memo[2:]
    return value


def _page(source):
    source = source or ''
    cached = _memo_get(_PAGE_MEMO, source)
    if cached is not None:
        return cached
    parser = _PageParser()
    parser.feed(_script_markup(source))
    parser.close()
    return _memo_put(_PAGE_MEMO, source, parser.root)


def _read_filters():
    result = dict(DEFAULT_FILTERS)
    handle = None
    try:
        if xbmcvfs.exists(FILTERS_FILE):
            handle = xbmcvfs.File(FILTERS_FILE)
            saved = json.loads(handle.read())
            if isinstance(saved, dict):
                result.update(saved)
    except (ValueError, OSError, TypeError):
        pass
    finally:
        if handle:
            handle.close()
    if result['orientation'] not in ('straight', 'gay', 'shemale'):
        result['orientation'] = 'straight'
    if not re.match(r'^[A-Z]{2}$', str(result['country'])):
        result['country'], result['country_name'] = 'CA', 'Canada'
    if not re.match(r'^\d{4}-(?:0[1-9]|1[0-2])$', str(result['best_month'])):
        result['best_month'] = DEFAULT_FILTERS['best_month']
    return result


def _save_filters(filters):
    global _REQUEST_PREFERENCES
    changed_home = _home_preferences(_read_filters()) != _home_preferences(filters)
    handle = xbmcvfs.File(FILTERS_FILE, 'w')
    try:
        handle.write(json.dumps(filters, ensure_ascii=True))
    finally:
        handle.close()
    _REQUEST_PREFERENCES = None
    if changed_home:
        _invalidate_home_cache()


def _orientation_label():
    current = _read_filters()['orientation']
    return next(label for label, value in ORIENTATIONS if value == current)


def _page_config(source):
    source = source or ''
    cached = _memo_get(_CONFIG_MEMO, source)
    if cached is not None:
        return cached
    return _memo_put(_CONFIG_MEMO, source, _parse_page_config(source))


def _parse_page_config(source):
    # Current pages use the same segmented base64 format as the site's config
    # loader. Earlier pages still expose xv.conf as a plain JSON object.
    modern = re.search(r'\b(?:window\.)?wgConfig\s*=\s*("(?:\\.|[^"\\])*")', source or '')
    if modern:
        try:
            encoded = json.loads(modern.group(1))
            size = int(encoded[:2], 16)
            remaining = encoded[2:]
            if size:
                segments = []
                while len(remaining) > size * 2:
                    segments.append(remaining[:size])
                    remaining = remaining[size:]
                remaining = ''.join(reversed(segments)) + remaining
            result = json.loads(base64.b64decode(remaining, validate=True).decode('utf-8'))
            if isinstance(result, dict):
                return result
        except Exception:
            pass
    match = re.search(r'\bxv\.conf\s*=\s*', source or '')
    if not match:
        return {}
    try:
        result, _ = json.JSONDecoder().raw_decode(source[match.end():].lstrip())
        return result if isinstance(result, dict) else {}
    except Exception:
        return {}


def _is_site_url(url):
    parsed = urllib_parse.urlsplit(_absolute(url))
    host = (parsed.hostname or '').lower()
    return parsed.scheme == 'https' and (host == 'xvideos.red' or host.endswith('.xvideos.red'))


def _json_data(source):
    if not source or not source.strip():
        return {}
    try:
        data = json.loads((source or '').lstrip('\ufeff').strip())
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _remote_image(value):
    value = html.unescape(value or '').replace('\\/', '/').strip()
    if value.startswith('//'):
        value = 'https:' + value
    if not re.match(r'^https?://', value):
        return ''
    # The CDN provides a JPEG counterpart; Kodi/Fire TV need not decode AVIF.
    value = value.replace('THUMBNUM', '1')
    return re.sub(r'\.avif(?=[?#]|$)', '.jpg', value, flags=re.IGNORECASE)


def _browse_url(url):
    '''Give Kodi a distinct directory identity for every browsing preference.'''
    filters = _read_filters()
    url = urllib_parse.urldefrag(url)[0]
    return '{}#_xv_browse_{}_{}_{}'.format(url, filters['orientation'], filters['country'], VERSION)


def _plain_browse_url(url):
    parsed = urllib_parse.urlsplit(url)
    return urllib_parse.urldefrag(url)[0] if parsed.fragment.startswith('_xv_browse_') else url


def _video_target(value):
    target = _absolute(value)
    parsed = urllib_parse.urlsplit(target)
    host = (parsed.hostname or '').lower()
    if host == 'xvideos.com' or host.endswith('.xvideos.com'):
        parsed = parsed._replace(scheme='https', netloc='www.xvideos.red')
    path = re.sub(r'^(/video(?:[.-][a-zA-Z0-9]+|\d+))/(?:THUMBNUM|\d+)/', r'\1/', parsed.path)
    parsed = parsed._replace(path=path, fragment='')
    target = urllib_parse.urlunsplit(parsed)
    return target if _is_site_url(target) and re.match(r'^/video(?:[.-][a-zA-Z0-9]+|\d+)(?:/|$)', path) else ''


def _video_identity(url):
    match = re.search(r'/video(?:[.-]([a-zA-Z0-9]+)|(\d+))(?:/|$)', url)
    return (match.group(1) or match.group(2)) if match else url


def _payload_video_records(value):
    records = []
    def walk(item, depth=0):
        if depth > 24:
            return
        if isinstance(item, dict):
            target = next((_video_target(item.get(k)) for k in ('cu', 'u', 'url', 'video_url')
                           if isinstance(item.get(k), str) and _video_target(item[k])), '')
            title = item.get('tf') or item.get('t') or item.get('title') or item.get('name')
            encoded = item.get('eid') or item.get('encodedId') or item.get('encoded_id')
            if isinstance(title, str) and ((isinstance(target, str) and _video_target(target)) or encoded):
                records.append(item)
            for child in item.values():
                if isinstance(child, (dict, list)):
                    walk(child, depth + 1)
        elif isinstance(item, list):
            for child in item:
                walk(child, depth + 1)
    walk(value)
    return records


def _embedded_videos(source):
    records = _payload_video_records(_page_config(source))
    decoder = json.JSONDecoder()
    for script in _page(source).find_all(lambda x: x.tag == 'script' and not x.get('src')):
        text = script.raw_text()
        covered = 0
        for match in re.finditer(r'(?:^|[=(:,;])\s*(?=[\[{])', text):
            if match.start() < covered:
                continue
            offset = match.end()
            candidate = text[offset:]
            # A JavaScript object such as {ll:1} is not JSON. Kodi's JSON error
            # constructor can itself fail on this input, so skip it up front.
            if candidate.startswith('{') and not re.match(r'\{\s*(?:"|\})', candidate):
                continue
            try:
                value, end = decoder.raw_decode(candidate)
            except Exception:
                # Limit this guard to decoding untrusted inline data. A bad
                # script object must not discard otherwise usable video cards.
                continue
            covered = offset + end
            records.extend(_payload_video_records(value))
        for match in re.finditer(r'''JSON\.parse\(\s*((?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'))''', text):
            try:
                # Decode a quoted string literal only; never execute page JavaScript.
                value = json.loads(_js_string(match.group(1)))
                records.extend(_payload_video_records(value))
            except Exception:
                continue
    return _json_videos({'videos': records}, owned_only=False)


def _diagnostic(message):
    # Counts and route kinds only: no cookies, account data, queries, or media URLs.
    if hasattr(xbmc, 'log'):
        xbmc.log('XVideos Red: ' + message, getattr(xbmc, 'LOGINFO', 1))
    else:
        utils.kodilog('XVideos Red: ' + message)


def _home_preferences(filters):
    return {key: filters.get(key) for key in ('orientation', 'country', 'feed_options')}


def _home_cache_key():
    # Only the digest enters the cache; the session stays in its original file.
    payload = '\0'.join((VERSION, _read_session(), utils.USER_AGENT,
                         json.dumps(_home_preferences(_read_filters()), sort_keys=True)))
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()


def _invalidate_home_cache():
    try:
        if xbmcvfs.exists(HOME_CACHE_FILE):
            xbmcvfs.delete(HOME_CACHE_FILE)
    except Exception:
        pass


def _read_home_cache():
    handle = None
    try:
        if not _read_session() or not xbmcvfs.exists(HOME_CACHE_FILE):
            return None
        handle = xbmcvfs.File(HOME_CACHE_FILE)
        cached = json.loads(handle.read())
        if not isinstance(cached, dict) or cached.get('key') != _home_cache_key():
            return None
        age = time.time() - float(cached.get('created', 0))
        if not 0 <= age < HOME_CACHE_SECONDS:
            return None
        videos = cached.get('videos')
        if not isinstance(videos, list) or not videos:
            return None
        for video in videos:
            if not isinstance(video, dict) or not all(isinstance(video.get(k), str) for k in (
                    'label', 'title', 'url', 'thumb', 'duration', 'quality')):
                return None
            if not _video_target(video['url']):
                return None
        next_url = cached.get('next_url', '')
        if not isinstance(next_url, str) or (next_url and not _is_site_url(next_url)):
            return None
        categories = cached.get('categories', [])
        if not isinstance(categories, list) or any(
                not isinstance(item, list) or len(item) != 2
                or not all(isinstance(value, str) for value in item)
                or not _is_site_url(item[1]) for item in categories):
            return None
        return cached
    except Exception:
        return None
    finally:
        if handle:
            handle.close()


def _write_home_cache(videos, next_url, categories, created=None):
    if not videos or not _read_session():
        return
    handle = None
    try:
        cached = {'key': _home_cache_key(), 'created': time.time() if created is None else created,
                  'videos': videos, 'next_url': next_url, 'categories': categories}
        handle = xbmcvfs.File(HOME_CACHE_FILE, 'w')
        handle.write(json.dumps(cached, ensure_ascii=True))
    except Exception:
        # Cache availability must never prevent normal browsing.
        pass
    finally:
        if handle:
            handle.close()


def _response_ok(data):
    return data.get('result') in (True, 1, '1', 'true')


def _pornstars_orientation_url(url):
    filters = _read_filters()
    orientation = filters['orientation']
    target = _plain_browse_url(url or filters['pornstars_url'])
    if filters.get('pornstars_orientation') == orientation:
        return target
    root = BASE_URL if orientation == 'straight' else _absolute(orientation + '?fmc=1')
    source, _ = _browse_fetch(root)
    links = _page(source).find_all(lambda x: x.tag == 'a' and 'pornstar' in _clean(x.text()).lower())
    for link in links:
        href = _absolute(link.get('href'))
        if _is_site_url(href) and '-index' in urllib_parse.urlsplit(href).path:
            target = href
            break
    filters['pornstars_url'] = target
    filters['pornstars_orientation'] = orientation
    _save_filters(filters)
    _diagnostic('model directory refreshed for {}'.format(orientation))
    return target


def _thumbnail(node, metadata=None):
    metadata = metadata or {}
    images = node.find_all(lambda x: x.tag == 'img')
    def usable(value):
        value = _remote_image(value)
        path = urllib_parse.urlsplit(value).path.lower()
        return value if value and not any(part in path for part in (
            'no-img', 'profile_default', 'blank.gif', 'blank.png', 'placeholder', 'transparent.gif')) else ''
    for key in ('data-src', 'data-src-jpg', 'data-sfwthumb'):
        for image in images:
            value = usable(image.get(key))
            if value:
                return value
    # Current <picture> cards can put the real JPEG only on a lazy <source>.
    for source in node.find_all(lambda x: x.tag == 'source'):
        if source.get('type') not in ('', 'image/jpeg', 'image/png', 'image/webp'):
            continue
        for key in ('data-srcset', 'srcset'):
            for candidate in source.get(key).split(','):
                value = usable(candidate.strip().split(' ')[0])
                if value:
                    return value
    for key in ('sfwThumbUrl', 'thumb', 'thumbnail', 'i', 'img', 'image'):
        value = metadata.get(key)
        if isinstance(value, str) and usable(value):
            return usable(value)
    for image in images:
        value = usable(image.get('src'))
        if value:
            return value
    for image in images:
        # Browser "Save page" rewrites src to a local asset; the card still
        # carries its original CDN directory and thumbnail number.
        mosaic = _remote_image(image.get('data-mzl'))
        saved_thumb = re.search(r'\b(xv_\d+_t)', urllib_parse.unquote(image.get('src')))
        if mosaic and saved_thumb:
            return urllib_parse.urljoin(mosaic, saved_thumb.group(1) + '.jpg')
        error_thumb = re.search(r'(?:thumb_url=|profile_thumb:["\'])(https?[^\s"\']+)', image.get('onerror'))
        if error_thumb:
            return _remote_image(error_thumb.group(1))
        try:
            videos = json.loads(image.get('data-videos') or '[]')
            if videos and isinstance(videos[0], dict):
                value = _remote_image(videos[0].get('img', ''))
                if value:
                    return value
        except (ValueError, TypeError, KeyError):
            pass
    # Profile thumbnails can be emitted by document.write before JavaScript runs.
    for script in node.find_all(lambda x: x.tag == 'script'):
        match = re.search(r'<img\b[^>]*\bsrc=["\'](https?[^"\']+)', script.raw_text(), re.IGNORECASE)
        if match:
            return _remote_image(match.group(1))
    return ''


def _navigate(mode, url=''):
    if mode in ('Pornstars', 'Channels', 'BestVideos', 'Categories', 'Tags', 'TagsList', 'Related'):
        url = _browse_url(url)
    target = (utils.addon_sys + '?mode=' + site.get_full_mode(mode)
              + '&url=' + urllib_parse.quote_plus(url))
    xbmc.executebuiltin('Container.Update({})'.format(target))


def _action(label, mode, payload=''):
    site.add_dir(label, payload, mode, site.img_cat, Folder=False)


def _pick(title, pairs, selected=None):
    if not pairs:
        utils.notify('XVideos Red', 'No filter choices were found')
        return None
    labels = [label for label, value in pairs]
    preselect = next((i for i, item in enumerate(pairs) if item[1] == selected), -1)
    index = utils.dialog.select(title, labels, preselect=preselect)
    return pairs[index] if 0 <= index < len(pairs) else None


def _filter_links(source, menu_class):
    choices, seen = [], set()
    for menu in _page(source).find_all(lambda x: x.tag == 'ul' and x.has_class(menu_class)):
        for anchor in menu.find_all(lambda x: x.tag == 'a' and x.get('href')):
            target = _absolute(anchor.get('href'))
            label = _clean(anchor.text()).replace('▼', '').strip()
            if label and _is_site_url(target) and target not in seen:
                seen.add(target)
                choices.append((label, target))
    return choices


def _active_filter_label(source, menu_class, fallback):
    for menu in _page(source).find_all(lambda x: x.tag == 'ul' and x.has_class(menu_class)):
        for item in menu.find_all(lambda x: x.tag == 'li' and x.has_class('active')):
            label = _clean(item.text()).replace('▼', '').strip()
            if label:
                return label
    return fallback


def _channel_orientation(url):
    orientation = _read_filters()['orientation']
    prefix = {'straight': 'channels-index', 'gay': 'channels-gay',
              'shemale': 'channels-trans'}[orientation]
    parsed = urllib_parse.urlsplit(_absolute(url))
    path = re.sub(r'^/(?:channels-index|channels-gay|channels-trans)', '/' + prefix, parsed.path)
    return urllib_parse.urlunsplit((parsed.scheme, parsed.netloc, path, parsed.query, ''))


def _feed_options(config=None):
    data = (config or {}).get('data', {})
    if not data:
        data = _read_filters().get('feed_options', {})
    sources = (2 if data.get('displayModels', True) else 0) + (1 if data.get('displayChannels', True) else 0)
    result = {
        'sort': data.get('sort', 4), 'view_mode': data.get('view_mode', 0),
        'show_free': data.get('show_free', 2), 'sources': sources or 3,
        'quality': data.get('quality', '360P'),
        'premium_min_length': data.get('premium_min_length', 0),
        'free_min_length': data.get('free_min_length', 0),
    }
    # Empty jQuery arrays are omitted from the form body, as in the browser.
    for key in ('cats', 'excats', 'channels'):
        if isinstance(data.get(key), list) and data[key]:
            result[key + '[]'] = data[key]
    return result


def _remember_feed(config):
    data = config.get('data', {})
    filters = _read_filters()
    options = {k: data[k] for k in (
        'sort', 'view_mode', 'show_free', 'displayModels', 'displayChannels',
        'quality', 'premium_min_length', 'free_min_length') if k in data}
    if filters.get('feed_options') == options:
        return
    filters['feed_options'] = options
    _invalidate_home_cache()
    handle = xbmcvfs.File(FILTERS_FILE, 'w')
    try:
        handle.write(json.dumps(filters, ensure_ascii=True))
    finally:
        handle.close()


def _feed_listing(url, config=None):
    response, _ = _fetch(url, BASE_URL, data=_feed_options(config))
    data = _json_data(response)
    if not _response_ok(data):
        _invalidate_home_cache()
        _diagnostic('feed: response not accepted; JSON={}, bytes={}'.format(bool(data), len(response)))
        return [], '', False
    content = data.get('html') or ''
    videos = _merge_videos(_extract_videos(content),
                           _json_videos({'videos': _payload_video_records(data)}, owned_only=False))
    _diagnostic('feed: HTML bytes={}, videos={}'.format(len(content), len(videos)))
    return videos, _extract_next_url(content, url), True


def _merge_videos(*groups):
    result, seen = [], {}
    for group in groups:
        for video in group:
            key = _video_identity(video['url'])
            if key in seen:
                for field in ('thumb', 'duration', 'quality'):
                    if not seen[key].get(field) and video.get(field):
                        seen[key][field] = video[field]
                continue
            seen[key] = video
            result.append(video)
    return result


def _json_videos(data, owned_only=True):
    '''Normalize the compact video records returned by the site's profile tabs.'''
    videos, seen = [], set()
    records = data.get('videos') or []
    if isinstance(records, dict):
        records = list(records.values())
    if not records and isinstance(data.get('posts'), list):
        for post in data['posts']:
            if isinstance(post, dict):
                records.extend(post.get('videos') or post.get('vs') or [])
    for item in records:
        if not isinstance(item, dict):
            continue
        if owned_only and (item.get('isContentLocked') is True or item.get('unavailable') is True):
            continue
        title = _clean(item.get('tf') or item.get('t') or item.get('title') or item.get('name') or '')
        eid = item.get('eid') or item.get('encodedId') or item.get('encoded_id')
        target = next((_video_target(item.get(k)) for k in ('cu', 'u', 'url', 'video_url')
                       if isinstance(item.get(k), str) and _video_target(item[k])), '')
        if not target and eid and title:
            target = '/video.{}/{}'.format(eid, _slug(title))
        target = _video_target(target)
        if not title or not target or _video_identity(target) in seen:
            continue
        thumb = (item.get('i') or item.get('img') or item.get('thumb_url')
                 or item.get('thumb') or item.get('thumbnail') or item.get('sfwThumbUrl') or '')
        if isinstance(thumb, dict):
            thumb = thumb.get('url') or thumb.get('src') or ''
        duration = item.get('d') or item.get('duration') or ''
        if isinstance(duration, (int, float)):
            duration = '{}:{:02d}'.format(int(duration) // 60, int(duration) % 60)
        quality = item.get('quality') or item.get('highest_quality') or ('4K' if item.get('td') else '1080p' if item.get('hp') else '720p' if item.get('h') else '')
        seen.add(_video_identity(target))
        videos.append({'label': title, 'title': title, 'url': target,
                       'thumb': _remote_image(thumb), 'duration': _clean(str(duration)),
                       'quality': str(quality)})
    return videos


def _profile_listing(url, config=None):
    filters = _read_filters()
    profile = re.split(r'/videos(?:-premium)?/', url, maxsplit=1)[0]
    options = filters.get('profile_options', {})
    post_data = options.get(profile, {})
    data_config = (config or {}).get('data', {})
    main_cats = data_config.get('main_cats')
    if isinstance(main_cats, list) and len(main_cats) > 1 and isinstance(data_config.get('main_cat'), str):
        post_data = {'main_cats[]': main_cats}
        # Only the current profile's request options are needed for pagination.
        filters['profile_options'] = {profile: post_data}
        handle = xbmcvfs.File(FILTERS_FILE, 'w')
        try:
            handle.write(json.dumps(filters, ensure_ascii=True))
        finally:
            handle.close()
    response, _ = _fetch(url, BASE_URL, data=post_data)
    data = _json_data(response)
    if not _response_ok(data):
        return [], '', False
    videos = _extract_videos(data.get('html') or '') or _json_videos(data, owned_only='/videos-premium/' in url)
    next_url = _extract_next_url(data.get('html') or '', url)
    try:
        page = int(data.get('current_page', urllib_parse.urlsplit(url).path.rsplit('/', 1)[-1]))
        per_page = int(data.get('nb_per_page', len(videos) or 1))
        total = int(data.get('nb_videos', 0))
        if not next_url and (page + 1) * per_page < total:
            parsed = urllib_parse.urlsplit(url)
            path = re.sub(r'/\d+$', '/' + str(page + 1), parsed.path)
            next_url = urllib_parse.urlunsplit((parsed.scheme, parsed.netloc, path, parsed.query, ''))
    except (ValueError, TypeError):
        pass
    return videos, next_url, True


def _load_listing(url):
    url = _listing_orientation_url(_absolute(_plain_browse_url(url or BASE_URL)))
    path = urllib_parse.urlsplit(url).path
    if re.match(r'^/feed/\d+$', path):
        return _feed_listing(url)
    if '/videos-premium/' in path or re.search(r'/videos/(?:best|new|rating|comments)/', path):
        return _profile_listing(url)
    is_home = path == '/' and not urllib_parse.urlsplit(url).query
    if is_home:
        cached = _read_home_cache()
        if cached:
            _diagnostic('home: cached videos={}'.format(len(cached['videos'])))
            return cached['videos'], cached['next_url'], True
    source, final_url = _browse_fetch(urllib_parse.urldefrag(url)[0])
    kind = 'search' if urllib_parse.parse_qs(urllib_parse.urlsplit(url).query).get('k') else 'home' if path == '/' else 'category/tag/profile'
    if not source or not _is_authenticated(source):
        _invalidate_home_cache()
        _diagnostic('{}: session not accepted; HTML bytes={}'.format(kind, len(source)))
        return [], '', False
    config = _page_config(source)
    if not _same_listing(url, final_url):
        _diagnostic('{}: requested listing redirected away; no homepage fallback'.format(kind))
        return [], '', True
    if config.get('data', {}).get('action') == 'premium_feed' or 'id="feed-videos"' in source:
        _remember_feed(config)
        # Saved webpages contain the rendered cards. Live responses contain a shell.
        videos = _extract_videos(source)
        if videos:
            result = videos, _extract_next_url(source, final_url), True
        else:
            result = _feed_listing(_absolute('feed/0'), config)
        if is_home and result[2]:
            _write_home_cache(result[0], result[1], _extract_categories(source))
        return result
    videos = _extract_videos(source)
    _diagnostic('{}: HTML bytes={}, videos={}, thumbnails={}'.format(
        kind, len(source), len(videos), sum(bool(video.get('thumb')) for video in videos)))
    if not videos:
        tree = _page(source)
        cards = tree.find_all(lambda x: x.get('data-eid') or x.get('data-video')
                              or x.get('id').startswith(('video_', 'video-thumb-')))
        links = tree.find_all(lambda x: x.tag == 'a' and _video_target(x.get('href')))
        layout = 'modern' if 'page' in config else 'legacy' if 'dyn' in config else 'unknown'
        _diagnostic('listing structure: layout={}, cards={}, video links={}, script writers={}'.format(
            layout, len(cards), len(links), len(re.findall(r'\b(?:document\.write|xv\.thumbs\.casting\.displayRandomThumb)\s*\(', source))))
    fragment = urllib_parse.urlsplit(url).fragment
    if fragment.startswith(('_tabRed', '_tabVideos')) or (not videos and config.get('data', {}).get('user')):
        profile = config.get('data', {}).get('user', {}).get('url') or final_url
        profile = urllib_parse.urldefrag(_absolute(profile))[0].rstrip('/')
        filters = urllib_parse.urlsplit(url).fragment.split(',')
        content = 'premium-membership-ppv-unlocked'
        order = 'best'
        if len(filters) > 2 and filters[2] in ('best', 'new', 'add-date', 'rating'):
            order = filters[2]
        data_config = config.get('data', {})
        main_cats = data_config.get('main_cats')
        category = ''
        if isinstance(main_cats, list) and len(main_cats) > 1 and isinstance(data_config.get('main_cat'), str):
            category = _read_filters()['orientation'] + '/'
        if fragment.startswith('_tabVideos') or (len(filters) > 1 and filters[1] == 'free'):
            found, next_url, ok = _profile_listing(profile + '/videos/{}/{}0'.format(order, category), config)
            return (found, next_url, True) if ok else (videos, _extract_next_url(source, final_url), True)
        endpoint = profile + '/videos-premium/{}/{}{}/0'.format(order, category, content)
        found, next_url, ok = _profile_listing(endpoint, config)
        if ok:
            return found, next_url, True
        # Subscription-only profiles also expose the simpler native premium filter.
        found, next_url, ok = _profile_listing(profile + '/videos-premium/{}/{}premium/0'.format(order, category), config)
        if ok:
            return found, next_url, True
    next_url = _extract_next_url(source, final_url)
    if is_home:
        _write_home_cache(videos, next_url, _extract_categories(source))
    return videos, next_url, True


def _show_videos(videos, next_url, mode):
    for video in videos:
        _add_video(video)
    if not videos:
        utils.notify('XVideos Red', 'No videos found')
    if next_url:
        site.add_dir('Next Page...', _browse_url(next_url), mode, site.img_next)
    utils.eod(cache=False)


def _extract_profiles(source):
    result, seen = [], set()
    for block in _page(source).find_all(lambda x: x.tag == 'div' and (
            x.get('id').startswith('profile_') or x.has_class('thumb-block-profile'))):
        links = block.find_all(lambda x: x.tag == 'a' and x.get('href'))
        names = block.find_all(lambda x: x.has_class('profile-name'))
        if not links or not names:
            continue
        name_links = names[0].find_all(lambda x: x.tag == 'a')
        anchor = name_links[0] if name_links else links[0]
        name = _clean(anchor.text() if name_links else names[0].text())
        target = _absolute(anchor.get('href'))
        if name and target not in seen and _is_site_url(target):
            seen.add(target)
            result.append((name, target, _thumbnail(block)))
    return result


def _extract_tags(source):
    result, seen = [], set()
    for menu in _page(source).find_all(lambda x: x.tag == 'ul' and x.has_class('tags-list')):
        for anchor in menu.find_all(lambda x: x.tag == 'a' and x.get('href')):
            path = urllib_parse.urlsplit(_absolute(anchor.get('href'))).path
            if not path.startswith('/tags/'):
                continue
            name_nodes = anchor.find_all(lambda x: x.tag == 'b')
            name = _clean(name_nodes[0].text() if name_nodes else anchor.text())
            name = re.sub(r'\s+\d[\d,.]*\s*$', '', name).strip()
            target = _absolute(anchor.get('href'))
            if name and target not in seen:
                seen.add(target)
                result.append((name, target))
    return result


def _best_date_links(source, current_url=BEST_URL):
    links = {}
    for anchor in _page(source).find_all(lambda x: x.tag == 'a' and x.get('href')):
        target = _absolute(anchor.get('href'), current_url)
        path = urllib_parse.urlsplit(target).path
        match = re.search(r'/(\d{4}-(?:0[1-9]|1[0-2]))(?:/|$)', path)
        if 'best-of' in path and match and _is_site_url(target) and not _video_target(target):
            # A date picker always starts on the first page of that month.
            links.setdefault(match.group(1), _absolute(path[:match.end(1)]))
    return links


def _best_dates(source):
    return sorted(_best_date_links(source), reverse=True) or [_read_filters()['best_month']]


def _best_month_url(source, current_url, month):
    target = _best_date_links(source, current_url).get(month)
    if target:
        return target
    path = urllib_parse.urlsplit(current_url).path
    if 'best-of' not in path:
        for anchor in _page(source).find_all(lambda x: x.tag == 'a' and x.get('href')):
            href = _absolute(anchor.get('href'))
            if _is_site_url(href) and 'best-of' in urllib_parse.urlsplit(href).path:
                path = urllib_parse.urlsplit(href).path
                break
        else:
            path = urllib_parse.urlsplit(BEST_URL).path
    path = re.sub(r'/\d{4}-\d{2}(?:/.*)?$', '', path).rstrip('/')
    return _absolute(path + '/' + month)


def _month_name(month):
    return date(2000, int(month), 1).strftime('%B')


def _directory_links(source, current_url):
    result, seen = [], set()
    parsed_current = urllib_parse.urlsplit(current_url)
    base = parsed_current.path.split('/')[1]
    tree = _page(source)
    mains = tree.find_all(lambda x: x.get('id') in ('main', 'content')) or [tree]
    for main in mains:
        for anchor in main.find_all(lambda x: x.tag == 'a' and x.get('href')):
            target = _absolute(anchor.get('href'))
            path = urllib_parse.urlsplit(target).path
            label = _clean(anchor.text())
            if not label or target in seen or target == current_url or not _is_site_url(target):
                continue
            if re.match(r'^/(?:pornstars|models|amateurs|model-channels|pornstar-channels)/[^/]+$', path):
                result.append((label, target, 'List'))
            elif path.startswith('/' + base + '/') and not re.search(r'/\d+$', path):
                result.append((label, target, 'Pornstars'))
            else:
                continue
            seen.add(target)
    return result


def _listing_orientation_url(url):
    '''Preserve a search/tag listing while updating its native type filter.'''
    orientation = _read_filters()['orientation']
    parsed = urllib_parse.urlsplit(url)
    query = urllib_parse.parse_qsl(parsed.query, keep_blank_values=True)
    if any(key == 'k' for key, value in query):
        query = [(key, value) for key, value in query if key != 'typef']
        query.append(('typef', orientation))
        return urllib_parse.urlunsplit(parsed._replace(query=urllib_parse.urlencode(query)))
    if parsed.path.startswith('/tags/'):
        native_type = re.match(r'^/tags/t:(straight|gay|shemale|trans)/', parsed.path)
        if native_type:
            current_type = native_type.group(1)
            if current_type == orientation or (orientation == 'shemale' and current_type == 'trans'):
                # Keep the website's canonical Trans spelling when it has
                # already supplied a filtered URL for the selected orientation.
                return url
        path = re.sub(r'^/tags/t:(?:straight|gay|shemale|trans)(?=/)', '/tags', parsed.path)
        # /tags/d and /tags/09 are alphabet menus; type applies to video results.
        suffix = path[len('/tags/'):].strip('/')
        if suffix and not re.fullmatch(r'[a-z]|09', suffix):
            if orientation != 'straight':
                path = path.replace('/tags/', '/tags/t:' + orientation + '/', 1)
            return urllib_parse.urlunsplit(parsed._replace(path=path))
    return url


def _same_listing(requested, redirected):
    '''An orientation switch may redirect to a home page instead of a listing.'''
    before, after = urllib_parse.urlsplit(requested), urllib_parse.urlsplit(redirected)
    before_query, after_query = urllib_parse.parse_qs(before.query), urllib_parse.parse_qs(after.query)
    if before_query.get('k'):
        return before_query['k'] == after_query.get('k')
    if before.path.startswith('/c/'):
        return after.path.startswith('/c/')
    if re.fullmatch(r'/tags(?:/(?:[a-z]|09))?/?', before.path):
        # A tag index/letter menu is not the /tags/t:<type>/... video listing
        # that the site's preference switch can redirect to.
        return before.path.rstrip('/') == after.path.rstrip('/')
    if before.path.startswith('/tags/'):
        before_tag = re.sub(r'^/tags/t:(?:straight|gay|shemale|trans)(?=/)', '/tags', before.path).rstrip('/')
        after_tag = re.sub(r'^/tags/t:(?:straight|gay|shemale|trans)(?=/)', '/tags', after.path).rstrip('/')
        return before_tag == after_tag
    if 'best-of' in before.path:
        return 'best-of' in after.path
    homes = ('/', '/gay', '/gay/', '/trans', '/trans/', '/shemale', '/shemale/')
    if before.path in homes:
        return after.path in homes
    if after.path in homes:
        return False
    return before.path == after.path or before.path.split('/')[1] == after.path.split('/')[1]


def _same_orientation(first, second):
    return ('trans' if first == 'shemale' else first) == ('trans' if second == 'shemale' else second)


def _page_preferences_match(source, desired):
    config = _page_config(source)
    dyn, user, page = config.get('dyn', {}), config.get('user', {}), config.get('page', {})
    modern = 'page' in config and 'user' in config
    orientation = user.get('mainCat') if modern else dyn.get('user_main_cat') or dyn.get('userMainCat')
    page_orientation = page.get('mainCat') if modern else dyn.get('page_main_cat')
    country = user.get('forcedCountry') if modern else dyn.get('forcedcountry') or dyn.get('country')
    return (_same_orientation(orientation, desired[0])
            and (not page_orientation or dyn.get('no_main_cat') or _same_orientation(page_orientation, desired[0]))
            and str(country or '').upper() == desired[1])


def _browse_fetch(url):
    '''Apply the site's own orientation/country switches to the local session.'''
    global _REQUEST_PREFERENCES
    url = _plain_browse_url(url)
    requested_url = url
    source, final_url = _fetch(url, BASE_URL)
    if not source:
        return source, final_url
    restore_route = not _same_listing(requested_url, final_url)
    filters = _read_filters()
    desired = (filters['orientation'], filters['country'])
    config = _page_config(source)
    dyn = config.get('dyn', {})
    modern = 'page' in config and 'user' in config
    user = config.get('user', {})
    page = config.get('page', {})
    current_orientation = (user.get('mainCat') if modern else
                           dyn.get('user_main_cat') or dyn.get('userMainCat'))
    page_orientation = page.get('mainCat') if modern else dyn.get('page_main_cat')
    if dyn.get('no_main_cat'):
        page_orientation = None
    current_country = user.get('forcedCountry') if modern else dyn.get('forcedcountry') or dyn.get('country')
    if _REQUEST_PREFERENCES == desired and not config and not restore_route:
        return source, final_url
    native_desired = 'trans' if modern and desired[0] == 'shemale' else desired[0]
    needs_orientation = (not _same_orientation(current_orientation, native_desired)
                         or (page_orientation and not _same_orientation(page_orientation, native_desired)))
    switched = False
    if needs_orientation:
        choice = dyn.get('main_cats', {}).get(desired[0], {})
        switch_url = choice.get('url')
        if not switch_url:
            current = page_orientation or current_orientation
            switch_url = 'switch-sexual-orientation/' + native_desired
            if current in ('straight', 'gay', 'trans', 'shemale'):
                switch_url += '/' + current
        # Both native frontends navigate to this endpoint and follow its redirect.
        # The current page's referrer lets the server translate its listing route.
        changed, redirected = _fetch(_absolute(switch_url), final_url)
        if changed and _is_site_url(redirected) and '/switch-sexual-orientation/' not in redirected:
            if _same_listing(requested_url, redirected):
                source, final_url = changed, redirected
                restore_route = False
            else:
                # The preference cookie was applied, but a generic homepage
                # cannot replace the category, tag, search or profile requested.
                final_url = _listing_orientation_url(requested_url)
                restore_route = True
                _diagnostic('orientation switch: restoring requested listing')
        switched = True
    if str(current_country or '').upper() != desired[1]:
        changed, redirected = _fetch(_absolute('change-country/' + desired[1].lower()), final_url)
        if changed and _same_listing(requested_url, redirected) and _page_preferences_match(changed, desired):
            source, final_url = changed, redirected
            restore_route = False
        switched = True
    _REQUEST_PREFERENCES = desired
    if restore_route:
        return _fetch(_listing_orientation_url(requested_url), requested_url)
    if switched:
        # Preference switches often already return the fully redirected page.
        if _page_preferences_match(source, desired) and _is_authenticated(source):
            return source, final_url
        return _fetch(final_url, final_url)
    return source, final_url


def _absolute(value, base=BASE_URL):
    value = html.unescape(value or '').replace('\\/', '/').strip()
    if value.startswith('//'):
        value = 'https:' + value
    return urllib_parse.urljoin(base, value)


def _clean(value):
    value = re.sub(r'<[^>]+>', ' ', value or '')
    return re.sub(r'\s+', ' ', html.unescape(value)).strip()


def _read_session():
    if not xbmcvfs.exists(SESSION_FILE):
        return ''
    handle = None
    try:
        handle = xbmcvfs.File(SESSION_FILE)
        return (handle.read() or '').strip()
    except Exception as exc:
        utils.kodilog('XVideos Red: unable to read the saved session ({})'.format(exc))
        return ''
    finally:
        if handle:
            handle.close()


def _write_session(cookie, keep_home=False):
    # Same-site Set-Cookie updates can rotate values without changing accounts.
    # Keep a valid snapshot for those updates, preserving its original expiry.
    cached = _read_home_cache() if keep_home else None
    handle = xbmcvfs.File(SESSION_FILE, 'w')
    try:
        handle.write(cookie)
    finally:
        handle.close()
    _invalidate_home_cache()
    if cached:
        _write_home_cache(cached['videos'], cached['next_url'], cached.get('categories', []), cached['created'])


def _cookie_from_text(file_text):
    '''Accept a raw Cookie header, a Cookie: line, or Netscape cookies.txt.'''
    if isinstance(file_text, bytes):
        file_text = file_text.decode('utf-8', 'replace')
    source = (file_text or '').lstrip('\ufeff').strip()
    if not source:
        return ''

    # Browser-exported Netscape cookie files use seven tab-separated columns:
    # domain, include-subdomains, path, secure, expiry, name, value.
    cookies = []
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith('#HttpOnly_'):
            stripped = stripped[len('#HttpOnly_'):]
        if not stripped or stripped.startswith('#'):
            continue
        fields = stripped.split('\t')
        if len(fields) >= 7:
            domain = fields[0].lstrip('.').lower()
            if domain == 'xvideos.red' or domain.endswith('.xvideos.red'):
                name = fields[5].strip()
                value = fields[6].strip()
                if name:
                    cookies.append('{}={}'.format(name, value))
    if cookies:
        return '; '.join(cookies)

    for line in source.splitlines():
        stripped = line.strip()
        if re.match(r'^cookie\s*:', stripped, re.IGNORECASE):
            return re.sub(r'^cookie\s*:\s*', '', stripped, flags=re.IGNORECASE).strip()

    # The simple transfer-file format is one raw Cookie header value.
    non_comment_lines = [
        line.strip() for line in source.splitlines()
        if line.strip() and not line.lstrip().startswith('#')
    ]
    return non_comment_lines[0] if len(non_comment_lines) == 1 else ''


def _save_validated_session(cookie):
    cookie = (cookie or '').strip()
    if not cookie or '=' not in cookie or '\n' in cookie or '\r' in cookie:
        utils.notify('XVideos Red', 'The session cookie format is invalid')
        return False

    page_html, _ = _fetch(BASE_URL, cookie=cookie)
    if not _is_authenticated(page_html):
        utils.notify('XVideos Red', 'The browser session was not accepted')
        return False

    _write_session(cookie)
    utils.notify('XVideos Red', 'Browser session saved')
    utils.clear_cache()
    utils.refresh()
    return True


def _headers(referer=BASE_URL, cookie=None, accept=None):
    headers = {
        'User-Agent': utils.USER_AGENT,
        'Accept': accept or 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Referer': referer or BASE_URL,
    }
    session = _read_session() if cookie is None else cookie
    if session:
        headers['Cookie'] = session
    return headers


def _fetch(url, referer=BASE_URL, cookie=None, data=None):
    '''Fetch fresh; retain same-site Set-Cookie updates from preference switches.'''
    try:
        if not _is_site_url(url):
            return '', url
        session = _read_session() if cookie is None else cookie
        jar = CookieJar()
        for pair in (session or '').split(';'):
            if '=' not in pair:
                continue
            name, value = pair.strip().split('=', 1)
            if name:
                jar.set_cookie(Cookie(0, name, value, None, False, '.xvideos.red',
                                      True, True, '/', True, True, None, True,
                                      None, None, {}, False))
        headers = _headers(referer, cookie='')
        body = None
        if data is not None:
            body = urllib_parse.urlencode(data, doseq=True).encode('utf-8')
            headers.update({'Content-Type': 'application/x-www-form-urlencoded',
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json, text/javascript, */*; q=0.01'})
        opener = urllib_request.build_opener(urllib_request.HTTPCookieProcessor(jar))
        request = urllib_request.Request(url, data=body, headers=headers)
        with opener.open(request, timeout=30) as response:
            raw = response.read()
            encoding = response.headers.get('Content-Encoding', '').lower()
            if 'gzip' in encoding or raw.startswith(b'\x1f\x8b'):
                raw = gzip.decompress(raw)
            elif 'deflate' in encoding:
                try:
                    raw = zlib.decompress(raw)
                except zlib.error:
                    raw = zlib.decompress(raw, -zlib.MAX_WBITS)
            charset = response.headers.get_content_charset() or 'utf-8'
            final_url = response.geturl()
        if cookie is None and session:
            saved = {}
            for item in jar:
                domain = item.domain.lstrip('.').lower()
                if (domain == 'xvideos.red' or domain.endswith('.xvideos.red')) and not item.is_expired():
                    saved[item.name] = item.value
            updated = '; '.join('{}={}'.format(name, value) for name, value in saved.items())
            if updated and updated != session:
                _write_session(updated, keep_home=True)
        return raw.decode(charset, 'replace'), final_url
    except Exception as exc:
        status = getattr(exc, 'code', None)
        utils.kodilog('XVideos Red: request failed ({}{})'.format(
            type(exc).__name__, ', HTTP {}'.format(status) if status else ''))
        return '', url


def _is_authenticated(page_html):
    source = page_html or ''
    config = _page_config(source)
    info = config.get('dyn', {}).get('login_info', {})
    return bool(
        re.search(r'/account(?:\\/|/)signout', source, re.IGNORECASE)
        or re.search(r'data-is-purchased=["\']1["\']', source, re.IGNORECASE)
        or re.search(r'"isPurchased"\s*:\s*true', html.unescape(source), re.IGNORECASE)
        or info.get('is_logged') is True
        or config.get('user', {}).get('isLogged') is True
    )


def _session_required(page_html):
    if _is_authenticated(page_html):
        return False
    _invalidate_home_cache()
    utils.notify('XVideos Red', 'Your browser session is missing or expired')
    return True


def _slug(value):
    return re.sub(r'[^a-z0-9]+', '_', _clean(value).lower()).strip('_')


def _quality(block):
    match = re.search(
        r'class=["\'][^"\']*video-hd-mark[^"\']*["\'][^>]*>([^<]+)',
        block or '',
        re.IGNORECASE,
    )
    return _clean(match.group(1) if match else '')


def _extract_videos(page_html):
    videos, seen = [], set()
    tree = _page(page_html)
    blocks = tree.find_all(lambda x: x.tag in ('div', 'article', 'li', 'section') and (
        x.get('id').startswith(('video_', 'video-thumb-')) or x.get('data-video')
        or x.has_class('thumb-block') or x.has_class('video-block')))
    # Some raw responses lack the id/classes assigned by browser JavaScript.
    if not blocks:
        for anchor in tree.find_all(lambda x: x.tag == 'a' and _video_target(x.get('href'))):
            node = anchor.parent
            for _ in range(4):
                if node and node.find_all(lambda x: x.has_class('title')):
                    break
                node = node.parent if node else None
            if node and node not in blocks:
                blocks.append(node)
    for block in blocks:
        metadata = _json_data(block.get('data-video'))
        anchors = block.find_all(lambda x: x.tag == 'a' and _video_target(x.get('href')))
        title_nodes = block.find_all(lambda x: x.has_class('title') or x.has_class('video-title'))
        title_node = title_nodes[0] if title_nodes else None
        if not anchors:
            # Uninitialized cards may provide an encoded id before the link is
            # inserted. Use the card's own title and id to form its native URL.
            title = _clean(metadata.get('title') or block.get('data-title')
                           or (title_node.text() if title_node else ''))
            encoded = metadata.get('encodedId') or block.get('data-eid')
            if title and encoded:
                record = dict(metadata, title=title, encodedId=encoded)
                # The URL may await JavaScript while the real image already
                # exists in the card. Preserve it instead of using id/title only.
                record['thumb_url'] = _thumbnail(block, metadata)
                durations = block.find_all(lambda x: x.has_class('duration'))
                qualities = block.find_all(lambda x: x.has_class('video-hd-mark'))
                if durations:
                    record['duration'] = _clean(durations[0].text())
                if qualities:
                    record['quality'] = _clean(qualities[0].text())
                videos.extend(_json_videos({'videos': [record]}, owned_only=False))
            continue
        title_anchor = next((x for x in anchors if x.get('title')), anchors[0])
        title = _clean(title_anchor.get('title') or (title_node.get('title') if title_node else ''))
        if not title and title_node:
            title = _clean(title_node.text())
        if not title:
            images = block.find_all(lambda x: x.tag == 'img' and x.get('alt'))
            title = _clean(images[0].get('alt')) if images else ''
        if not title:
            title = _clean(title_anchor.text())
        video_url = _video_target(title_anchor.get('href'))
        identity = _video_identity(video_url)
        if not title or identity in seen or not video_url:
            continue
        durations = block.find_all(lambda x: x.has_class('duration'))
        qualities = block.find_all(lambda x: x.has_class('video-hd-mark'))
        duration = _clean(durations[0].text()) if durations else ''
        if duration and not title_anchor.get('title') and title.endswith(' ' + duration):
            title = title[:-len(duration)].strip()
        seen.add(identity)
        videos.append({'label': title, 'title': title, 'url': video_url,
                       'thumb': _thumbnail(block, metadata), 'duration': duration,
                       'quality': _clean(qualities[0].text()) if qualities else ''})
    videos = _merge_videos(videos, _embedded_videos(page_html))
    if any(not video['thumb'] for video in videos):
        related = {}
        for item in _extract_related(page_html):
            match = re.search(r'/video\.([^/]+)/', item['url'])
            if match:
                related[match.group(1)] = _remote_image(item['thumb'])
        for video in videos:
            match = re.search(r'/video\.([^/]+)/', video['url'])
            if not video['thumb'] and match:
                video['thumb'] = related.get(match.group(1), '')
    return videos


def _extract_next_url(page_html, current_url=BASE_URL):
    for anchor in _page(page_html).find_all(lambda x: x.tag == 'a'):
        label = _clean(anchor.text()).lower()
        if not (anchor.has_class('next-page') or anchor.has_class('next')
                or anchor.get('rel') == 'next' or label == 'next'):
            continue
        href = anchor.get('href')
        if re.match(r'^#\d+$', href):
            return _absolute('feed/' + href[1:])
        target = _absolute(href, current_url)
        if href and not href.startswith('#') and _is_site_url(target):
            return target
    return ''


def _extract_categories(page_html):
    categories = []
    seen = set()
    for anchor in _page(page_html).find_all(lambda x: x.tag == 'a' and x.get('href')):
        category_url = _absolute(anchor.get('href'))
        if not _is_site_url(category_url) or not re.match(r'^/c/p:1/[^/]+/?$', urllib_parse.urlsplit(category_url).path):
            continue
        name = _clean(anchor.text())
        if not name or category_url in seen:
            continue
        seen.add(category_url)
        categories.append((name, category_url))
    return sorted(categories, key=lambda item: item[0].lower())


def _video_context_menu(video_url):
    lookup_url = (
        utils.addon_sys + '?mode=' + site.get_full_mode('Lookupinfo')
        + '&url=' + urllib_parse.quote_plus(video_url)
    )
    related_url = (
        utils.addon_sys + '?mode=' + site.get_full_mode('ContextRelated')
        + '&url=' + urllib_parse.quote_plus(video_url)
    )
    return [
        ('[COLOR white]Lookup info[/COLOR]', 'RunPlugin({})'.format(lookup_url)),
        ('[COLOR white]Related videos[/COLOR]', 'RunPlugin({})'.format(related_url)),
    ]


def _image_url(value):
    if not value:
        return ''
    # Kodi fetches artwork separately from page requests. Give the image CDN
    # the browser's public headers; session cookies stay on xvideos.red.
    return value + '|' + urllib_parse.urlencode({
        'User-Agent': utils.USER_AGENT,
        'Referer': BASE_URL,
        'Accept': 'image/jpeg,image/png,image/webp,image/*;q=0.8',
    })


def _add_video(video):
    site.add_download_link(
        video['label'],
        video['url'],
        'Playvid',
        _image_url(video.get('thumb', '')),
        video.get('title', video['label']),
        contextm=_video_context_menu(video['url']),
        duration=video.get('duration', ''),
        quality=video.get('quality', ''),
    )


def _extract_stream(page_html):
    patterns = (
        r"html5player\.setVideoHLS\(['\"]([^'\"]+)",
        r"html5player\.setVideoUrlHigh\(['\"]([^'\"]+)",
        r"html5player\.setVideoUrlLow\(['\"]([^'\"]+)",
    )
    for pattern in patterns:
        match = re.search(pattern, page_html or '', re.IGNORECASE)
        if match:
            return _absolute(match.group(1))
    return ''


def _extract_related(page_html):
    match = re.search(r'\bvideo_related\s*=\s*(\[[\s\S]*?\]);', page_html or '', re.IGNORECASE)
    if not match:
        return []
    try:
        data = json.loads(match.group(1))
    except Exception as exc:
        utils.kodilog('XVideos Red: related-video JSON failed ({})'.format(exc))
        return []

    videos = []
    seen = set()
    for item in data:
        video_url = _absolute(item.get('u', ''))
        title = _clean(item.get('t') or item.get('tf') or '')
        if not video_url or not title or video_url in seen:
            continue
        seen.add(video_url)
        quality = '4K' if item.get('td') else ('1080p' if item.get('hp') else ('720p' if item.get('h') else ''))
        videos.append({
            'label': title,
            'title': _clean(item.get('tf') or title),
            'url': video_url,
            'thumb': _absolute(item.get('i', '')),
            'duration': _clean(str(item.get('d', ''))),
            'quality': quality,
        })
    return videos


def _extract_taxonomy(page_html):
    tree = _page(page_html)
    sections = tree.find_all(lambda x: x.get('id') == 'video-tags-list'
                             or x.has_class('video-tags-list'))
    if not sections:
        uploaders = tree.find_all(lambda x: x.tag == 'li' and x.has_class('main-uploader'))
        sections = [x.parent for x in uploaders if x.parent]
    choices, seen = {}, set()
    for section in sections:
        for anchor in section.find_all(lambda x: x.tag == 'a' and x.get('href')):
            target = _absolute(anchor.get('href'))
            path = urllib_parse.urlsplit(target).path
            if not _is_site_url(target) or target in seen:
                continue
            if anchor.has_class('uploader-tag') or (anchor.parent and anchor.parent.has_class('main-uploader')):
                kind = 'Studio'
            elif path.startswith(('/pornstars/', '/models/', '/amateurs/')) or anchor.has_class('profile'):
                kind = 'Performer'
            elif path.startswith('/tags/'):
                kind = 'Tag'
            elif path.startswith('/c/'):
                kind = 'Category'
            else:
                continue
            names = anchor.find_all(lambda x: x.has_class('name'))
            label = _clean(names[0].text() if names else anchor.text())
            if not names:
                label = re.sub(r'\s+\d[\d,.]*[km]?\s*$', '', label, flags=re.IGNORECASE).strip()
            if not label:
                continue
            seen.add(target)
            if kind in ('Studio', 'Performer'):
                target = urllib_parse.urldefrag(target)[0] + '#_tabRed'
            choices['{} - {}'.format(kind, label)] = target
    return choices


def _media_headers(referer):
    return urllib_parse.urlencode({
        'User-Agent': utils.USER_AGENT,
        'Referer': referer or BASE_URL,
        'Origin': BASE_URL.rstrip('/'),
    })


@site.register()
def ChooseOrientation(url=''):
    context = _json_data(url)
    filters = _read_filters()
    selected = _pick('Choose orientation', ORIENTATIONS, filters['orientation'])
    if not selected:
        return
    if selected[1] != filters['orientation']:
        filters['pornstars_orientation'] = ''
        filters['pornstars_url'] = BASE_URL + 'pornstars-index'
        filters['best_orientation'] = ''
        filters['best_url'] = ''
    filters['orientation'] = selected[1]
    _save_filters(filters)
    utils.clear_cache()
    if context.get('mode') == 'Channels':
        target = _channel_orientation(context.get('url') or filters['channels_url'])
        filters['channels_url'] = target
        _save_filters(filters)
        _navigate('Channels', target)
    elif context.get('mode') == 'BestVideos':
        _navigate('BestVideos', context.get('url') or _absolute('best-of-red/' + filters['best_month']))
    else:
        utils.refresh()


def _country_choices():
    names = dict(COUNTRIES)
    response, _ = _fetch(_absolute('account/getcountries/en'), BASE_URL)
    data = _json_data(response).get('countries', {})
    if isinstance(data, dict):
        for code, value in data.items():
            code = str(code).upper()
            name = value.get('name') if isinstance(value, dict) else value
            if re.match(r'^[A-Z]{2}$', code) and isinstance(name, str) and name:
                names[code] = _clean(name)
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                code = str(item.get('code') or item.get('flag') or '').upper()
                name = item.get('name')
                if re.match(r'^[A-Z]{2}$', code) and isinstance(name, str) and name:
                    names[code] = _clean(name)
    return sorted([(name, code) for code, name in names.items()], key=lambda x: x[0].lower())


@site.register()
def ChooseCountry(url=''):
    filters = _read_filters()
    selected = _pick('Choose country', _country_choices(), filters['country'])
    if not selected:
        return
    filters['country_name'], filters['country'] = selected
    _save_filters(filters)
    utils.clear_cache()
    utils.refresh()


@site.register()
def BestVideos(url):
    filters = _read_filters()
    saved_url = filters.get('best_url') if filters.get('best_orientation') == filters['orientation'] else ''
    source, final_url = _browse_fetch(url or saved_url or _absolute('best-of-red/' + filters['best_month']))
    if not source or _session_required(source):
        utils.eod()
        return
    if 'best-of' not in urllib_parse.urlsplit(final_url).path:
        source, final_url = _browse_fetch(_best_month_url(source, final_url, filters['best_month']))
        if not source or _session_required(source):
            utils.eod()
            return
    match = re.search(r'/(\d{4}-\d{2})(?:/|$)', urllib_parse.urlsplit(final_url).path)
    current = match.group(1) if match else _best_dates(source)[0]
    year, month = current.split('-')
    filters['best_month'] = current
    filters['best_url'] = _best_month_url(source, final_url, current)
    filters['best_orientation'] = filters['orientation']
    # Remember the translated native route without invalidating request state.
    handle = xbmcvfs.File(FILTERS_FILE, 'w')
    try:
        handle.write(json.dumps(filters, ensure_ascii=True))
    finally:
        handle.close()
    _action('Orientation: ' + _orientation_label(), 'ChooseOrientation', json.dumps({'mode': 'BestVideos', 'url': final_url}))
    _action('Year: ' + year, 'ChooseBestDate', json.dumps({'url': final_url, 'kind': 'year', 'current': current}))
    _action('Month: ' + _month_name(month), 'ChooseBestDate', json.dumps({'url': final_url, 'kind': 'month', 'current': current}))
    videos = _extract_videos(source)
    config = _page_config(source)
    actual = config.get('page', {}).get('mainCat') or config.get('dyn', {}).get('page_main_cat') or 'unknown'
    _diagnostic('best: selected={}, page={}, videos={}, thumbnails={}'.format(
        filters['orientation'], actual, len(videos), sum(bool(video.get('thumb')) for video in videos)))
    _show_videos(videos, _extract_next_url(source, final_url), 'BestVideos')


@site.register()
def ChooseBestDate(url):
    context = _json_data(url)
    source, final_url = _browse_fetch(context.get('url') or _absolute('best-of-red'))
    if not source:
        return
    dates = _best_dates(source)
    current = context.get('current') or dates[0]
    if context.get('kind') == 'year':
        years = sorted(set(value[:4] for value in dates), reverse=True)
        selected = _pick('Choose year', [(year, year) for year in years], current[:4])
        if not selected:
            return
        available = [value for value in dates if value.startswith(selected[1] + '-')]
        preferred = selected[1] + '-' + current[5:]
        chosen = preferred if preferred in available else available[0]
    else:
        available = [value for value in dates if value.startswith(current[:4] + '-')]
        selected = _pick('Choose month', [(_month_name(value[5:]), value) for value in available], current)
        if not selected:
            return
        chosen = selected[1]
    filters = _read_filters()
    filters['best_month'] = chosen
    target = _best_month_url(source, final_url, chosen)
    filters['best_url'] = target
    filters['best_orientation'] = filters['orientation']
    _save_filters(filters)
    _navigate('BestVideos', target)


@site.register()
def Tags(url):
    site.add_dir('All Tags', BASE_URL + 'tags', 'TagsList', site.img_cat)
    site.add_dir('# / 0–9', BASE_URL + 'tags/09', 'TagsList', site.img_cat)
    for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        site.add_dir(letter, BASE_URL + 'tags/' + letter.lower(), 'TagsList', site.img_cat)
    utils.eod()


@site.register()
def TagsList(url):
    source, final_url = _browse_fetch(url)
    if not source or _session_required(source):
        utils.eod()
        return
    tags = _extract_tags(source)
    config = _page_config(source)
    action = config.get('data', {}).get('action') or config.get('page', {}).get('action')
    page_kind = action if action in ('tags', 'tags_index', 'search', 'category', 'premium_feed') else 'other'
    _diagnostic('tag directory: orientation={}, kind={}, tags={}'.format(
        _read_filters()['orientation'], page_kind, len(tags)))
    for name, target in tags:
        site.add_dir(name, target, 'List', site.img_cat)
    if not tags:
        utils.notify('XVideos Red', 'No tags found')
    next_url = _extract_next_url(source, final_url)
    if next_url:
        site.add_dir('Next Page...', next_url, 'TagsList', site.img_next)
    utils.eod()


@site.register()
def Channels(url):
    target = _channel_orientation(url or _read_filters()['channels_url'])
    source, final_url = _browse_fetch(target)
    if not source or _session_required(source):
        utils.eod()
        return
    _action('Orientation: ' + _orientation_label(), 'ChooseOrientation', json.dumps({'mode': 'Channels', 'url': final_url}))
    _action('Content: ' + _active_filter_label(source, 'profile-links', 'RED'), 'ChooseSiteFilter',
            json.dumps({'mode': 'Channels', 'menu': 'profile-links', 'url': final_url, 'title': 'RED / Free'}))
    _action('Order: ' + _active_filter_label(source, 'time-links', 'Recommended'), 'ChooseSiteFilter',
            json.dumps({'mode': 'Channels', 'menu': 'time-links', 'url': final_url, 'title': 'Recommended / New'}))
    profiles = _extract_profiles(source)
    for name, target, thumb in profiles:
        # The free directory opens the free profile; RED opens its premium tab.
        if '/premium' in urllib_parse.urlsplit(final_url).path:
            target = urllib_parse.urldefrag(target)[0] + '#_tabRed'
        else:
            target = urllib_parse.urldefrag(target)[0] + '#_tabVideos'
        site.add_dir(name, target, 'List', thumb or site.img_cat)
    if not profiles:
        utils.notify('XVideos Red', 'No channels found')
    next_url = _extract_next_url(source, final_url)
    if next_url:
        site.add_dir('Next Page...', next_url, 'Channels', site.img_next)
    utils.eod()


@site.register()
def Pornstars(url):
    target = _pornstars_orientation_url(url)
    source, final_url = _browse_fetch(target)
    if not source or _session_required(source):
        utils.eod()
        return
    for label, menu, fallback in (
            ('Models by country', 'geo-links', 'Worldwide Models'),
            ('Model Types', 'profile-links', 'All model types'),
            ('Ranking', 'time-links', 'Subscribers (1 year)')):
        _action(label + ': ' + _active_filter_label(source, menu, fallback), 'ChooseSiteFilter',
                json.dumps({'mode': 'Pornstars', 'menu': menu, 'url': final_url, 'title': label}))
    profiles = _extract_profiles(source)
    for name, target, thumb in profiles:
        target = urllib_parse.urldefrag(target)[0] + '#_tabRed'
        site.add_dir(name, target, 'List', thumb or site.img_cat)
    if not profiles:
        links = _directory_links(source, final_url)
        for label, target, mode in links:
            if mode == 'List':
                target = urllib_parse.urldefrag(target)[0] + '#_tabRed'
            site.add_dir(label, _browse_url(target) if mode == 'Pornstars' else target, mode, site.img_cat)
        if not links:
            utils.notify('XVideos Red', 'No models found')
    next_url = _extract_next_url(source, final_url)
    if next_url:
        site.add_dir('Next Page...', _browse_url(next_url), 'Pornstars', site.img_next)
    _diagnostic('models: orientation={}, profiles={}'.format(_read_filters()['orientation'], len(profiles)))
    utils.eod(cache=False)


@site.register()
def ChooseSiteFilter(url):
    context = _json_data(url)
    mode, menu = context.get('mode'), context.get('menu')
    if mode not in ('Channels', 'Pornstars') or menu not in ('geo-links', 'profile-links', 'time-links'):
        return
    source, final_url = _browse_fetch(context.get('url') or BASE_URL)
    if not source or _session_required(source):
        return
    choices = _filter_links(source, menu)
    if mode == 'Pornstars' and menu == 'geo-links':
        dyn = _page_config(source).get('dyn', {})
        template = dyn.get('index_country_url')
        available = dyn.get('av_menu_countries', {})
        if template and isinstance(available, dict):
            seen = {value for label, value in choices}
            for code, token in sorted(available.items(), key=lambda x: COUNTRIES.get(x[0], x[1]).lower()):
                target = _absolute(template.replace('%country_token%', token))
                if target not in seen and _is_site_url(target):
                    choices.append((COUNTRIES.get(code, token.replace('_', ' ').title()) + ' Models', target))
                    seen.add(target)
    selected = _pick(context.get('title') or 'Choose filter', choices, final_url)
    if not selected:
        return
    filters = _read_filters()
    target = selected[1]
    filters['channels_url' if mode == 'Channels' else 'pornstars_url'] = target
    _save_filters(filters)
    _navigate(mode, _browse_url(target))


@site.register(default_mode=True)
def Main():
    if _read_session():
        site.add_dir('Replace browser session', '', 'SetSession', site.img_login, Folder=False)
        site.add_dir('Import/replace session from file', '', 'ImportSessionFile', site.img_login, Folder=False)
        site.add_dir('Clear browser session', '', 'ClearSession', site.img_logout, Folder=False)
    else:
        site.add_dir('Set browser session cookie', '', 'SetSession', site.img_login, Folder=False)
        site.add_dir('Import session from file', '', 'ImportSessionFile', site.img_login, Folder=False)
        utils.notify('XVideos Red', 'Set your browser session cookie before browsing')
        utils.eod()
        return
    filters = _read_filters()
    _action('Orientation: {}'.format(_orientation_label()), 'ChooseOrientation')
    _action('Country: {}'.format(filters['country_name']), 'ChooseCountry')
    _action('Refresh videos', 'RefreshHome')
    best_url = filters.get('best_url') if filters.get('best_orientation') == filters['orientation'] else ''
    site.add_dir('Best Videos', _browse_url(best_url or _absolute('best-of-red/' + filters['best_month'])), 'BestVideos', site.img_cat)
    site.add_dir('Categories', _browse_url(BASE_URL), 'Categories', site.img_cat)
    site.add_dir('Tags', _browse_url(BASE_URL + 'tags'), 'Tags', site.img_cat)
    site.add_dir('Channels', _browse_url(_channel_orientation(filters['channels_url'])), 'Channels', site.img_cat)
    site.add_dir('Pornstars', _browse_url(filters['pornstars_url']), 'Pornstars', site.img_cat)
    site.add_dir('Search', _browse_url(BASE_URL), 'Search', site.img_search)
    List(BASE_URL)


@site.register()
def RefreshHome(url=''):
    _invalidate_home_cache()
    utils.refresh()


@site.register()
def SetSession():
    cookie = (utils._get_keyboard('', 'Paste xvideos.red Cookie header', hidden=True) or '').strip()
    cookie = re.sub(r'^cookie\s*:\s*', '', cookie, flags=re.IGNORECASE).strip()
    if not cookie:
        return
    _save_validated_session(cookie)


@site.register()
def ImportSessionFile():
    path = utils.dialog.browseSingle(1, 'Select XVideos Red session file', 'files')
    if not path:
        return

    handle = None
    try:
        handle = xbmcvfs.File(path)
        source = handle.read() or ''
    except Exception as exc:
        utils.kodilog('XVideos Red: unable to read session file ({})'.format(exc))
        utils.notify('XVideos Red', 'Unable to read the selected file')
        return
    finally:
        if handle:
            handle.close()

    cookie = _cookie_from_text(source)
    if not cookie:
        utils.notify('XVideos Red', 'No supported cookie data was found in the file')
        return
    _save_validated_session(cookie)


@site.register()
def ClearSession():
    try:
        if xbmcvfs.exists(SESSION_FILE):
            xbmcvfs.delete(SESSION_FILE)
    except Exception as exc:
        utils.kodilog('XVideos Red: unable to remove the saved session ({})'.format(exc))
    _invalidate_home_cache()
    utils.notify('XVideos Red', 'Browser session cleared')
    utils.refresh()


@site.register()
def List(url):
    videos, next_url, authenticated = _load_listing(url)
    if not authenticated:
        utils.notify('XVideos Red', 'Your browser session is missing or expired')
        utils.eod()
        return
    _show_videos(videos, next_url, 'List')


@site.register()
def Categories(url):
    cached = _read_home_cache()
    categories = cached.get('categories') if cached else []
    if not categories:
        page_html, _ = _browse_fetch(url or BASE_URL)
        if not page_html or _session_required(page_html):
            utils.eod()
            return
        categories = _extract_categories(page_html)
    for name, category_url in categories:
        site.add_dir(name, _browse_url(category_url), 'List', site.img_cat)
    if not categories:
        utils.notify('XVideos Red', 'No categories found')
    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url or BASE_URL, 'Search')
        return
    search_url = '{}?{}'.format(BASE_URL, urllib_parse.urlencode({
        'k': keyword.strip(),
        'premium': '1',
        'typef': _read_filters()['orientation'],
    }))
    List(search_url)


@site.register()
def Lookupinfo(url):
    page_html, _ = _fetch(url, BASE_URL)
    if not page_html or _session_required(page_html):
        return
    choices = _extract_taxonomy(page_html)
    if not choices:
        utils.notify('XVideos Red', 'No studio, performers, tags or categories found')
        return
    selected_url = utils.selector('Lookup Info', choices, show_on_one=True)
    if selected_url:
        _navigate('List', selected_url)


@site.register()
def ContextRelated(url):
    # RunPlugin is an action invocation. Open the directory in the active Kodi
    # container, which supplies the directory handle needed to display results.
    _navigate('Related', url)


@site.register()
def Related(url):
    page_html, _ = _fetch(_plain_browse_url(url), BASE_URL)
    if not page_html or _session_required(page_html):
        _diagnostic('related: session/page not accepted; HTML bytes={}'.format(len(page_html)))
        utils.eod(cache=False)
        return
    videos = _extract_related(page_html)
    _diagnostic('related: HTML bytes={}, videos={}, thumbnails={}'.format(
        len(page_html), len(videos), sum(bool(video.get('thumb')) for video in videos)))
    for video in videos:
        _add_video(video)
    if not videos:
        utils.notify('XVideos Red', 'No related videos found')
    utils.eod(cache=False)


@site.register()
def Playvid(url, name, download=None):
    player = utils.VideoPlayer(name, download)
    player.progress.update(25, '[CR]Loading authenticated video page[CR]')
    page_html, final_url = _fetch(url, BASE_URL)
    if not page_html or _session_required(page_html):
        player.progress.close()
        return

    stream_url = _extract_stream(page_html)
    if not stream_url:
        utils.notify('XVideos Red', 'Unable to resolve the video stream')
        player.progress.close()
        return

    player.progress.update(90, '[CR]Playing video[CR]')
    player.play_from_direct_link('{}|{}'.format(stream_url, _media_headers(final_url)))
