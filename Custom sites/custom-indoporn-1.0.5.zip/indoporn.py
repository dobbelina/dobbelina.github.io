# -*- coding: utf-8 -*-
"""IndoPorn custom site for Cumination / Kodi 21. Author: EvelK.

Copyright (C) 2026 EvelK
SPDX-License-Identifier: GPL-3.0-or-later
"""

import base64
import gzip
import hashlib
import json
import os
import re
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from html import unescape
from html.parser import HTMLParser
from urllib.parse import parse_qsl, parse_qs, quote, urlencode, urljoin, urlsplit, urlunsplit
from urllib.error import HTTPError
from urllib.request import Request, build_opener, HTTPRedirectHandler

from kodi_six import xbmc, xbmcgui, xbmcvfs
from resources.lib import utils
from resources.lib.customsite import CustomSite


site = CustomSite('EvelK', 'indoporn')
BASE_URL = 'https://indoporn.mobi/'
VERSION = '1.0.5'
FILTERS = (
    ('Newest', 'latest'),
    ('Best', 'popular'),
    ('Most Viewed', 'most-viewed'),
    ('Longest', 'longest'),
    ('Random', 'random'),
)
_VOID_TAGS = frozenset(('area', 'base', 'br', 'col', 'embed', 'hr', 'img',
                        'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'))
_IMAGE_EXTENSIONS = ('.jpg', '.png', '.webp', '.gif', '.avif')
_MAX_IMAGE = 4 * 1024 * 1024
_MAX_IMPORT = 16 * 1024 * 1024


class _Node:
    def __init__(self, tag='', attrs=(), parent=None):
        self.tag, self.attrs, self.parent = tag, dict(attrs), parent
        self.children = []

    def has_class(self, name):
        return name in (self.attrs.get('class') or '').split()

    def nodes(self, tag=None, cls=None, attr=None):
        for child in self.children:
            if not isinstance(child, _Node):
                continue
            if ((tag is None or child.tag == tag)
                    and (cls is None or child.has_class(cls))
                    and (attr is None or child.attrs.get(attr[0]) == attr[1])):
                yield child
            yield from child.nodes(tag, cls, attr)

    def first(self, tag=None, cls=None, attr=None):
        return next(self.nodes(tag, cls, attr), None)

    def text(self):
        return ' '.join(' '.join(c.text() if isinstance(c, _Node) else c
                                 for c in self.children).split())


class _Document(HTMLParser):
    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.root = _Node()
        self.stack = [self.root]
        self.feed(html or '')
        self.close()

    def handle_starttag(self, tag, attrs):
        node = _Node(tag, attrs, self.stack[-1])
        self.stack[-1].children.append(node)
        if tag not in _VOID_TAGS:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in _VOID_TAGS:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if self.stack[-1].tag not in ('script', 'style'):
            self.stack[-1].children.append(data)


def _white(text):
    return '[COLOR white]{}[/COLOR]'.format(text)


def _absolute(url, base=BASE_URL):
    url = unescape(url or '').strip().replace('\\/', '/')
    if not url or url.startswith(('data:', 'javascript:', '#')):
        return ''
    resolved = urljoin(base, url)
    if urlsplit(resolved).scheme not in ('http', 'https'):
        return ''
    return quote(resolved, safe=":/%?&=+#@!$'()*;,~-_")


def _plugin_url(mode, url):
    return utils.addon_sys + '?' + urlencode({'mode': site.get_full_mode(mode), 'url': url})


def _update(mode, url):
    xbmc.executebuiltin('Container.Update({})'.format(_plugin_url(mode, url)))


def _profile_path(*parts):
    translate = getattr(xbmcvfs, 'translatePath', getattr(utils, 'TRANSLATEPATH', None))
    root = translate(utils.profileDir) if translate else utils.profileDir
    path = os.path.join(root, 'custom_indoporn', *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def _saved_filter():
    try:
        with open(_profile_path('settings.json'), encoding='utf-8') as stream:
            value = json.load(stream).get('filter', 'popular')
        return value if value in dict(FILTERS).values() else 'popular'
    except (OSError, ValueError, TypeError, AttributeError):
        return 'popular'


def _save_filter(value):
    try:
        path = _profile_path('settings.json')
        with open(path + '.tmp', 'w', encoding='utf-8') as stream:
            json.dump({'filter': value}, stream)
        os.replace(path + '.tmp', path)
    except OSError:
        pass


class _FetchError(Exception):
    """A user-readable request failure; never contains request credentials."""

    def __init__(self, message, status=None, reason='request'):
        self.status, self.reason = status, reason
        super().__init__(message)


def _site_host(url):
    parsed = urlsplit(url)
    host = (parsed.hostname or '').lower()
    return parsed.scheme == 'https' and (host == 'indoporn.mobi' or host.endswith('.indoporn.mobi'))


def _browser_session():
    try:
        with open(_profile_path('browser_session.json'), encoding='utf-8') as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_browser_session(data):
    path = _profile_path('browser_session.json')
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(path),
                                         suffix='.tmp', delete=False) as stream:
            temporary = stream.name
            json.dump(data, stream)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.remove(temporary)


class _ImportError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def _decode_import(data):
    if isinstance(data, (bytes, bytearray)):
        data = bytes(data)
        encoding = 'utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
        try:
            return data.decode(encoding)
        except UnicodeError:
            raise _ImportError('ENCODING', 'Save the export as UTF-8 or UTF-16 text.') from None
    if not isinstance(data, str):
        raise _ImportError('FILE_READ', 'Kodi could not read text from the selected file.')
    return data.lstrip('\ufeff')


def _json_cookie_records(data, domain='', name='', depth=0):
    """Accept arrays, wrapped exports, and domain/path/name nested exports."""
    if depth > 16:
        return
    if isinstance(data, list):
        for item in data:
            yield from _json_cookie_records(item, domain, '', depth + 1)
        return
    if not isinstance(data, dict):
        return
    domain = data.get('domain') or data.get('host') or data.get('hostname') or domain
    if not domain and isinstance(data.get('url'), str):
        domain = urlsplit(data['url']).hostname or ''
    if 'value' in data and ('name' in data or name not in ('', 'cookies', 'data', 'result', 'solution')):
        item = dict(data)
        item['name'] = data.get('name') or name
        item['domain'] = domain
        yield item
        return
    if (name == 'cookies' or 'cf_clearance' in data) and all(not isinstance(v, (dict, list)) for v in data.values()):
        for key, value in data.items():
            if isinstance(value, str):
                yield {'name': key, 'value': value, 'domain': domain}
        return
    for key, value in data.items():
        if not isinstance(value, (dict, list)):
            continue
        hint = str(key).lstrip('.').lower()
        child_domain = hint if re.fullmatch(r'(?:[a-z0-9-]+\.)+[a-z0-9-]+', hint) else domain
        yield from _json_cookie_records(value, child_domain, str(key), depth + 1)


def _cookie_expired(cookie):
    if cookie.get('session') is True:
        return False
    value = next((cookie[k] for k in ('expirationDate', 'expires', 'expiry', 'expiration')
                  if k in cookie and cookie[k] not in (None, '')), 0)
    try:
        expiry = float(value)
    except (ValueError, TypeError):
        try:
            date = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            expiry = date.replace(tzinfo=date.tzinfo or timezone.utc).timestamp()
        except (ValueError, TypeError, OverflowError):
            return True
    if expiry > 100000000000:
        expiry /= 1000
    return expiry > 0 and expiry < time.time()


def _cookie_header(text):
    text = _decode_import(text).strip()
    if not text:
        raise _ImportError('EMPTY_FILE', 'The selected cookie file is empty.')
    records = None
    header = re.search(r'^\s*Cookie\s*:\s*(.+)$', text, re.I | re.M)
    if text.startswith(('{', '[', '"')):
        try:
            data = json.loads(text)
        except ValueError:
            raise _ImportError('JSON_SYNTAX', 'The JSON file is incomplete or is not a valid cookie export.') from None
        if isinstance(data, str):
            return _cookie_header(data)
        if isinstance(data, dict):
            raw = data.get('cookie') or data.get('Cookie') or data.get('cookies')
            if not raw and isinstance(data.get('headers'), dict):
                raw = data['headers'].get('Cookie') or data['headers'].get('cookie')
            if isinstance(raw, str):
                return _cookie_header(raw)
        records = list(_json_cookie_records(data))
        if not records:
            raise _ImportError('JSON_LAYOUT', 'No cookie records were found. Use a Netscape TXT export or cookie JSON containing names and values.')
    elif not header and ('\t' in text or '# Netscape' in text):
        records = []
        for line in text.splitlines():
            line = line.lstrip()
            if line.startswith('#HttpOnly_'):
                line = line[len('#HttpOnly_'):]
            elif not line or line.startswith('#'):
                continue
            fields = line.split('\t', 6) if '\t' in line else re.split(r'\s+', line, maxsplit=6)
            if len(fields) == 7:
                records.append({'domain': fields[0], 'expires': fields[4],
                                'name': fields[5], 'value': fields[6]})
    pairs = {}
    if records is None:
        text = header.group(1).strip() if header else text
        if '=' not in text:
            text = 'cf_clearance=' + text
        for part in text.split(';'):
            if not part.strip():
                continue
            name, equal, value = part.strip().partition('=')
            if not equal or not re.fullmatch(r"[!#$%&'*+\-.^_`|~0-9A-Za-z]+", name):
                raise _ImportError('COOKIE_HEADER', 'Use a Cookie request header, Netscape TXT, or JSON cookie export.')
            if any(ord(c) < 32 or ord(c) > 126 for c in value):
                raise _ImportError('COOKIE_HEADER', 'The Cookie header contains invalid control characters.')
            pairs[name] = value
    else:
        for cookie in records:
            domain = str(cookie.get('domain') or '').lstrip('.').rstrip('.').lower()
            if domain and domain != 'indoporn.mobi' and not domain.endswith('.indoporn.mobi'):
                continue
            if _cookie_expired(cookie):
                continue
            name, value = cookie.get('name'), cookie.get('value')
            if not isinstance(name, str) or not re.fullmatch(r"[!#$%&'*+\-.^_`|~0-9A-Za-z]+", name):
                continue
            # Empty values are valid cookies and must not invalidate an export.
            if not isinstance(value, str) or any(ord(c) < 32 or ord(c) > 126 or c == ';' for c in value):
                continue
            pairs[name] = value
    if not pairs:
        raise _ImportError('NO_SITE_COOKIES', 'No current IndoPorn cookies were found. Export cookies while IndoPorn is open in Firefox.')
    return '; '.join('{}={}'.format(name, value) for name, value in pairs.items())


def _user_agent(text):
    text = _decode_import(text).strip()
    if text.startswith('{'):
        data = json.loads(text)
        text = data.get('user_agent') or data.get('userAgent') or data.get('User-Agent') or (data.get('headers') or {}).get('User-Agent') or ''
    if not isinstance(text, str):
        raise ValueError('Use the exact one-line User-Agent request header from your browser.')
    header = re.search(r'^[ \t]*User-Agent[ \t]*:[ \t]*([^\r\n]+)\r?$', text, re.I | re.M)
    if header:
        text = header.group(1)
    text = re.sub(r'^User-Agent\s*:\s*', '', text, flags=re.I).strip()
    if not text or any(ord(c) < 32 or ord(c) > 126 for c in text):
        raise ValueError('Use the exact one-line User-Agent request header from your browser.')
    return text


def _session_bundle(text):
    """Validate both values before changing the saved browser session."""
    text = _decode_import(text).strip()
    if text.startswith('{'):
        try:
            cookie = _cookie_header(text)
            user_agent = _user_agent(text)
        except _ImportError:
            raise
        except (ValueError, TypeError, AttributeError):
            raise _ImportError('SESSION_FORMAT', 'The session JSON must contain cookies and the matching User-Agent.') from None
    else:
        cookie_line = re.search(r'^[ \t]*Cookie[ \t]*:[ \t]*([^\r\n]+)\r?$', text, re.I | re.M)
        if not cookie_line:
            raise _ImportError('MISSING_COOKIE', 'Add a line beginning Cookie: followed by the complete Cookie header.')
        if not re.search(r'^[ \t]*User-Agent[ \t]*:[ \t]*[^\r\n]+\r?$', text, re.I | re.M):
            raise _ImportError('MISSING_USER_AGENT', 'Add a line beginning User-Agent: followed by the matching browser User-Agent.')
        cookie = _cookie_header(cookie_line.group(1).strip())
        try:
            user_agent = _user_agent(text)
        except ValueError:
            raise _ImportError('USER_AGENT_FORMAT', 'Use the exact one-line browser User-Agent after User-Agent:.') from None
    return {'cookie': cookie, 'user_agent': user_agent}


def _challenge(html):
    lower = html.lower()
    title = re.search(r'<title\b[^>]*>\s*(.*?)</title>', lower, re.S)
    if title and any(title.group(1).startswith(value) for value in
                     ('just a moment', 'attention required', 'checking your browser')):
        return True
    # Successful pages can include Cloudflare's background verification script.
    return ('<article' not in lower and any(marker in lower for marker in
            ('cf-chl-', '/cdn-cgi/challenge-platform/', 'checking your browser', 'verify you are human')))


class _BrowserRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        if redirected:
            redirected.remove_header('Cookie')
            cookie = _browser_session().get('cookie') if _site_host(newurl) else ''
            if cookie:
                redirected.add_unredirected_header('Cookie', cookie)
        return redirected


def _page_kind(html, url):
    doc = _Document(html).root
    if _listing(doc, url):
        return 'videos'
    if _cards(_main(doc), url, directory=True):
        return 'directory'
    if _sources(doc, url) or _player_iframes(doc, url):
        return 'video'
    return ''


def _response_html(response):
    data = response.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        raise _FetchError('The page response was too large.')
    if (response.headers.get('Content-Encoding') or '').lower() == 'gzip':
        data = gzip.decompress(data)
    if len(data) > 8 * 1024 * 1024:
        raise _FetchError('The page response was too large.')
    return data.decode('utf-8', 'replace')


def _request_route(url):
    parts = urlsplit(url)
    if parts.path == '/':
        return 'search' if 's' in dict(parse_qsl(parts.query)) else 'front-page'
    if parts.path.startswith('/categories/'):
        return 'categories'
    if parts.path.startswith('/actors/'):
        return 'models'
    return 'listing-or-video'


def _browser_fetch(url, session, timeout=20):
    # This path deliberately makes no call into FlareSolverr or the page cache.
    headers = _request_headers(BASE_URL, url)
    cookie = headers.pop('Cookie', '')
    headers.update({'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
                    'Accept-Encoding': 'identity'})
    request = Request(url, headers=headers)
    if cookie:
        request.add_unredirected_header('Cookie', cookie)
    try:
        with build_opener(_BrowserRedirect()).open(request, timeout=timeout) as response:
            html = _response_html(response)
    except HTTPError as exc:
        body = ''
        try:
            body = _response_html(exc)
        except Exception:
            pass
        finally:
            exc.close()
        if body and not _challenge(body) and _page_kind(body, url):
            utils.kodilog('IndoPorn {} BROWSER_PAGE_OK route={} status={} content=usable'.format(
                VERSION, _request_route(url), exc.code))
            return body
        utils.kodilog('IndoPorn {} BROWSER_PAGE_BLOCKED route={} status={}'.format(
            VERSION, _request_route(url), exc.code))
        raise _FetchError('This page returned HTTP {}. Other pages may still be accessible.'.format(exc.code),
                          status=exc.code, reason='page-blocked') from None
    except _FetchError:
        raise
    except Exception:
        raise _FetchError('The browser request could not connect. Check your connection and browser session.') from None
    if _challenge(html):
        raise _FetchError('Cloudflare is challenging this page. Other pages may still be accessible.',
                          status=200, reason='challenge')
    utils.kodilog('IndoPorn {} BROWSER_PAGE_OK route={}'.format(VERSION, _request_route(url)))
    return html


def _fetch(url, timeout=20):
    session = _browser_session()
    if _site_host(url) and (session.get('cookie') or session.get('user_agent')):
        if not session.get('cookie') or not session.get('user_agent'):
            raise _FetchError('Import both the Cookie and matching User-Agent in Browser Access.')
        return _browser_fetch(url, session, timeout=timeout)
    try:
        html = utils.getHtml(url, BASE_URL)
        if isinstance(html, bytes):
            html = html.decode('utf-8', 'replace')
        html = html or ''
    except Exception as exc:
        message = str(exc).lower()
        if 'timeout' in message or 'timed out' in message:
            raise _FetchError('The automatic Cloudflare check timed out. Open Browser Access to import a browser session.') from None
        raise _FetchError('The page request failed. Try Browser Access if Cloudflare is blocking the site.') from None
    if _challenge(html):
        raise _FetchError('Cloudflare returned a challenge instead of the page. Open Browser Access.')
    return html


def _report_fetch_error(exc):
    utils.kodilog('IndoPorn {} REQUEST_FAILED {}'.format(VERSION, str(exc)))
    utils.notify('IndoPorn', str(exc), duration=7000)


def _main(doc):
    return doc.first('main') or doc.first(attr=('id', 'primary')) or doc


def _srcset(value):
    candidates = []
    for entry in (value or '').split(','):
        fields = entry.strip().split()
        if not fields:
            continue
        try:
            width = int(fields[-1].rstrip('w')) if len(fields) > 1 else 9999
        except ValueError:
            width = 9999
        # WordPress's 300px JPEG is present even when its 320px crop is missing.
        candidates.append((abs(width - 300), fields[0]))
    return [url for _, url in sorted(candidates)]


def _images(card, base):
    raw = [card.attrs.get('data-main-thumb')]
    img = card.first('img', cls='video-main-thumb') or card.first('img')
    if img:
        raw.extend(_srcset(img.attrs.get('data-srcset') or img.attrs.get('srcset')))
        raw.extend(img.attrs.get(k) for k in ('data-src', 'data-original', 'data-lazy-src', 'src'))
    result = []
    for value in raw:
        url = _absolute(value, base)
        if not url:
            continue
        if re.search(r'\.(?:avif|webp)(?:\?|$)', url, re.I):
            # Prefer a site's real JPEG variant on platforms without AVIF support.
            jpeg = re.sub(r'\.(avif|webp)(?=\?|$)', '.jpg', url, flags=re.I)
            if jpeg not in result:
                result.append(jpeg)
        if url not in result:
            result.append(url)
    return result


def _cards(scope, base, directory=False):
    rows, seen = [], set()
    for card in scope.nodes('article', cls='thumb-block'):
        title = (card.first(cls='actor-title') or card.first(cls='cat-title')) if directory else card.first(cls='title')
        if title is None:
            continue
        link = card.first('a')
        url = _absolute(link.attrs.get('href'), base) if link else ''
        if not url or url in seen:
            continue
        seen.add(url)
        duration, quality = card.first(cls='duration'), card.first(cls='hd-video')
        rows.append({'name': title.text(), 'url': url, 'images': _images(card, base),
                     'duration': duration.text() if duration else '',
                     'quality': quality.text() if quality else ''})
    return rows


def _listing(doc, url):
    main = _main(doc)
    scope = main.first(cls='video-list-content') or main
    return _cards(scope, url)


def _next_page(doc, url):
    main = _main(doc)
    pagination = main.first(cls='pagination') or main.first('nav', cls='navigation')
    if pagination is None:
        return ''
    links = list(pagination.nodes('a'))
    next_link = next((a for a in links if a.text().lower() in ('next', 'next page', 'next »', '»')
                      or 'next' in (a.attrs.get('rel') or '').split()
                      or a.has_class('next')), None)
    if next_link is None:
        current = next((a for a in links if a.has_class('current')), None)
        try:
            wanted = int(current.text()) + 1 if current else 2
        except ValueError:
            wanted = 2
        next_link = next((a for a in links if a.text().isdigit() and int(a.text()) == wanted), None)
    if next_link is None:
        return ''
    next_url = _absolute(next_link.attrs.get('href'), url)
    if not next_url or next_url == url:
        return ''
    # Some theme pagination links drop filters and search/model query parameters.
    bits = urlsplit(next_url)
    query = dict(parse_qsl(urlsplit(url).query, keep_blank_values=True))
    query.update(parse_qsl(bits.query, keep_blank_values=True))
    return urlunsplit((bits.scheme, bits.netloc, bits.path, urlencode(query), ''))


def _image_type(data):
    if data[:3] == b'\xff\xd8\xff':
        return '.jpg'
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        return '.png'
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return '.webp'
    if data[:6] in (b'GIF87a', b'GIF89a'):
        return '.gif'
    if data[4:8] == b'ftyp' and (b'avif' in data[8:40] or b'avis' in data[8:40]):
        return '.avif'
    return ''


def _request_headers(referer=BASE_URL, target=None):
    session = _browser_session()
    if session.get('cookie') and session.get('user_agent'):
        headers = {'User-Agent': session['user_agent'], 'Referer': referer}
        if _site_host(target or referer):
            headers['Cookie'] = session['cookie']
        return headers
    ua = utils.USER_AGENT
    try:
        # Optional in newer Cumination; retain a previously established identity.
        identity = utils._cf_get_identity(urlsplit(referer).hostname)
        ua = identity.get('user_agent') or ua
    except (AttributeError, TypeError):
        pass
    return {'User-Agent': ua, 'Referer': referer}


def _remote_image(url):
    headers = _request_headers(target=url)
    headers['Accept'] = 'image/jpeg,image/png,image/webp;q=0.5,*/*;q=0.1'
    return url + '|' + urlencode(headers) if url else site.image


def _cached_image(candidates, deadline):
    for url in candidates:
        key = hashlib.sha256(url.encode('utf-8')).hexdigest()
        stem = _profile_path('thumbnails', key)
        for ext in _IMAGE_EXTENSIONS:
            path = stem + ext
            if os.path.isfile(path) and os.path.getsize(path) > 0:
                return path
    for url in candidates:
        remaining = deadline - time.monotonic()
        if remaining < 0.2:
            break
        headers = _request_headers(target=url)
        headers['Accept'] = 'image/jpeg,image/png,image/webp;q=0.5,*/*;q=0.1'
        try:
            request = Request(url, headers=headers)
            opener = build_opener(_BrowserRedirect()) if headers.get('Cookie') else utils.opener
            with opener.open(request, timeout=min(3, remaining)) as response:
                data = response.read(_MAX_IMAGE + 1)
            ext = _image_type(data)
            if not ext or len(data) > _MAX_IMAGE:
                continue
            if ext == '.avif':
                # Retry a JPEG spelling if content negotiation returned AVIF.
                jpeg = re.sub(r'\.(avif|webp)(?=\?|$)', '.jpg', url, flags=re.I)
                if jpeg != url and jpeg not in candidates:
                    return _cached_image([jpeg], deadline)
                continue
            path = _profile_path('thumbnails', hashlib.sha256(url.encode('utf-8')).hexdigest()) + ext
            temporary = None
            try:
                with tempfile.NamedTemporaryFile(dir=os.path.dirname(path), suffix='.tmp', delete=False) as stream:
                    temporary = stream.name
                    stream.write(data)
                os.replace(temporary, path)
            finally:
                if temporary and os.path.exists(temporary):
                    os.remove(temporary)
            return path
        except Exception:
            continue
    # Do not give Kodi a local filename until a complete image exists.
    return _remote_image(candidates[0]) if candidates else site.image


def _clean_thumbnails():
    try:
        directory = os.path.dirname(_profile_path('thumbnails', 'cache'))
        marker = os.path.join(directory, '.cleaned')
        now = time.time()
        if os.path.exists(marker) and now - os.path.getmtime(marker) < 86400:
            return
        for entry in os.scandir(directory):
            if entry.is_file() and now - entry.stat().st_mtime > 7 * 86400:
                os.remove(entry.path)
        with open(marker, 'w'):
            pass
    except OSError:
        pass


def _artwork(rows):
    if not rows:
        return
    _clean_thumbnails()
    unique = list(dict.fromkeys(tuple(row['images']) for row in rows))
    deadline = time.monotonic() + 8
    with ThreadPoolExecutor(max_workers=8) as pool:
        images = list(pool.map(lambda urls: _cached_image(urls, deadline), unique))
    result = dict(zip(unique, images))
    for row in rows:
        row['image'] = result[tuple(row['images'])]


def _add_videos(rows):
    _artwork(rows)
    for row in rows:
        menus = [
            (_white('Lookup Info'), 'RunPlugin({})'.format(_plugin_url('LookupInfo', row['url']))),
            (_white('Related Porn Videos'), 'RunPlugin({})'.format(_plugin_url('Related', row['url']))),
        ]
        site.add_download_link(_white(row['name']), row['url'], 'Playvid', row['image'],
                               row['name'], duration=row['duration'], quality=row['quality'],
                               contextm=menus)


def _add_next(doc, url, mode):
    next_url = _next_page(doc, url)
    if next_url:
        number = re.search(r'/page/(\d+)', next_url)
        label = 'Next Page... ({})'.format(number.group(1)) if number else 'Next Page...'
        site.add_dir(_white(label), next_url, mode, site.img_next)


def _show_listing(url):
    try:
        doc = _Document(_fetch(url)).root
    except _FetchError as exc:
        session = _browser_session()
        # The unfiltered homepage uses Best, matching filter=popular.
        if (session.get('cookie') and session.get('user_agent') and exc.reason in ('page-blocked', 'challenge')
                and urlsplit(url).path == '/' and dict(parse_qsl(urlsplit(url).query)) == {'filter': 'popular'}):
            try:
                doc = _Document(_fetch(BASE_URL)).root
                if not _listing(doc, BASE_URL):
                    raise exc
                utils.kodilog('IndoPorn {} BEST_HOMEPAGE_FALLBACK_OK'.format(VERSION))
            except _FetchError:
                _report_fetch_error(exc)
                return
        else:
            _report_fetch_error(exc)
            return
    rows = _listing(doc, url)
    _add_videos(rows)
    _add_next(doc, url, 'List')
    if not rows:
        utils.notify('IndoPorn', 'No videos found on this page.')


@site.register(default_mode=True)
def Main(url=None):
    chosen = dict(parse_qsl(urlsplit(url or '').query)).get('filter')
    if chosen in dict(FILTERS).values():
        _save_filter(chosen)
    else:
        chosen = _saved_filter()
    home = BASE_URL + '?' + urlencode({'filter': chosen})
    sections = (
        ('Categories', BASE_URL + 'categories/', 'Categories', site.img_cat),
        ('Models', BASE_URL + 'actors/', 'Models', getattr(site, 'img_models', site.img_cat)),
        ('Top', BASE_URL + 'category/selection/', 'List', site.img_cat),
        ('Popular', BASE_URL + '?filter=most-viewed', 'List', site.img_cat),
        ('Asian', BASE_URL + 'category/asian/', 'List', site.img_cat),
        ('Indo', BASE_URL + 'category/indonesian/?filter=most-viewed', 'List', site.img_cat),
        ('Search', BASE_URL, 'Search', site.img_search),
    )
    for title, link, mode, image in sections:
        site.add_dir(_white(title), link, mode, image)
    label = next(name for name, value in FILTERS if value == chosen)
    site.add_dir(_white('Filter: ' + label), home, 'Filters', getattr(site, 'img_filters', site.img_cat))
    site.add_dir(_white('Browser Access'), BASE_URL, 'BrowserAccess', site.img_cat)
    _show_listing(home)
    utils.eod(cache=False)


@site.register()
def Filters(url):
    for label, value in FILTERS:
        site.add_dir(_white(label), BASE_URL + '?' + urlencode({'filter': value}), 'Main', site.img_cat)
    utils.eod()


@site.register()
def List(url):
    _show_listing(url)
    utils.eod()


def _directory(url, mode):
    try:
        doc = _Document(_fetch(url)).root
    except _FetchError as exc:
        _report_fetch_error(exc)
        utils.eod()
        return
    rows = _cards(_main(doc), url, directory=True)
    _artwork(rows)
    for row in rows:
        site.add_dir(_white(row['name']), row['url'], 'List', row['image'])
    _add_next(doc, url, mode)
    if not rows:
        utils.notify('IndoPorn', 'No entries found on this page.')
    utils.eod()


@site.register()
def Categories(url):
    _directory(url, 'Categories')


@site.register()
def Models(url):
    _directory(url, 'Models')


@site.register()
def Search(url, keyword=None):
    if keyword is None:
        site.search_dir(BASE_URL, 'Search')
        return
    keyword = keyword.strip()
    if not keyword:
        utils.eod()
        return
    List(BASE_URL + '?' + urlencode({'s': keyword}))


def _metadata(doc, base):
    main = _main(doc)
    scope = main.first(cls='video-tags') or main.first(cls='tags-list')
    result, seen = [], set()
    if scope is None:
        return result
    for link in scope.nodes('a'):
        url = _absolute(link.attrs.get('href'), base)
        path = urlsplit(url).path
        group = ('Actor' if '/actor/' in path or 'actors' in dict(parse_qsl(urlsplit(url).query))
                 else 'Category' if '/category/' in path
                 else 'Tags' if '/tag/' in path else '')
        name = link.text()
        if group and name and url not in seen:
            result.append((group, name, url))
            seen.add(url)
    order = {'Actor': 0, 'Category': 1, 'Tags': 2}
    return sorted(result, key=lambda item: (order[item[0]], item[1].casefold()))


@site.register()
def LookupInfo(url):
    try:
        info = _metadata(_Document(_fetch(url)).root, url)
    except _FetchError as exc:
        _report_fetch_error(exc)
        return
    if not info:
        utils.notify('IndoPorn', 'No Actor, Category or Tags found for this video.')
        return
    labels = [_white('{} - {}'.format(group, name)) for group, name, _ in info]
    index = xbmcgui.Dialog().select('Lookup Info', labels)
    if index >= 0:
        _update('List', info[index][2])


def _related(doc, url):
    main = _main(doc)
    scope = (main.first(cls='video-related') or main.first(cls='related-videos')
             or main.first(cls='related-posts'))
    # Theme versions also place the related grid inside the primary video article.
    if scope is None:
        scope = main.first('article') or main
    return [row for row in _cards(scope, url) if row['url'].rstrip('/') != url.rstrip('/')]


@site.register()
def Related(url):
    _update('RelatedList', url)


@site.register()
def RelatedList(url):
    try:
        doc = _Document(_fetch(url)).root
    except _FetchError as exc:
        _report_fetch_error(exc)
        utils.eod()
        return
    rows = _related(doc, url)
    _add_videos(rows)
    if not rows:
        utils.notify('IndoPorn', 'No related videos found.')
    utils.eod()


def _media_url(value, base):
    url = _absolute(value, base)
    return url if re.search(r'\.(?:mp4|m3u8|webm|mpd)(?:[?#]|$)', url, re.I) else ''


def _sources(doc, base):
    result = []
    for source in doc.nodes('source'):
        url = _media_url(source.attrs.get('src'), base)
        if url and url not in result:
            result.append(url)
    for video in doc.nodes('video'):
        url = _media_url(video.attrs.get('src'), base)
        if url and url not in result:
            result.append(url)
    for meta in doc.nodes('meta'):
        if meta.attrs.get('itemprop') == 'contentUrl' or meta.attrs.get('property') in ('og:video', 'og:video:url'):
            url = _media_url(meta.attrs.get('content'), base)
            if url and url not in result:
                result.append(url)
    return result


def _embedded_tag(url):
    """Clean Tube Player carries its original <video> tag in the q parameter."""
    value = parse_qs(urlsplit(url).query).get('q', [''])[0]
    if not value or len(value) > 1024 * 1024:
        return ''
    try:
        decoded = base64.urlsafe_b64decode(value.replace(' ', '+') + '=' * (-len(value) % 4)).decode('utf-8')
        return parse_qs(decoded).get('tag', [''])[0]
    except (ValueError, UnicodeError):
        return ''


def _player_iframes(doc, base):
    main = _main(doc)
    scope = main.first(cls='video-player') or main.first(cls='responsive-player')
    if scope is None:
        return []
    result = []
    for frame in scope.nodes('iframe'):
        url = _absolute(frame.attrs.get('data-src') or frame.attrs.get('src'), base)
        if url and url not in result:
            result.append(url)
    return result


def _stream_headers(url, referer):
    headers = _request_headers(referer, url)
    origin = urlsplit(referer)
    headers['Origin'] = '{}://{}'.format(origin.scheme, origin.netloc)
    headers['Accept-Encoding'] = 'identity'
    try:
        req = Request(url)
        utils.cj.add_cookie_header(req)
        if req.get_header('Cookie') and not headers.get('Cookie'):
            headers['Cookie'] = req.get_header('Cookie')
    except AttributeError:
        pass
    return url + '|' + urlencode(headers)


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download=download)
    try:
        doc = _Document(_fetch(url)).root
        direct = _sources(doc, url)
        if direct:
            vp.play_from_direct_link(_stream_headers(direct[0], url))
            return
        frames = _player_iframes(doc, url)
        external = []
        for frame in frames[:3]:
            tag = _embedded_tag(frame)
            direct = _sources(_Document(tag).root, frame) if tag else []
            if direct:
                vp.play_from_direct_link(_stream_headers(direct[0], frame))
                return
            if urlsplit(frame).hostname != urlsplit(BASE_URL).hostname:
                external.append(frame)
                continue
            embedded = _Document(_fetch(frame)).root
            direct = _sources(embedded, frame)
            if direct:
                vp.play_from_direct_link(_stream_headers(direct[0], frame))
                return
            external.extend(_player_iframes(embedded, frame))
        if external:
            vp.play_from_link_list(list(dict.fromkeys(external)))
        else:
            utils.notify('IndoPorn', 'No playable video source found.')
    except _FetchError as exc:
        _report_fetch_error(exc)
    except Exception as exc:
        utils.kodilog('IndoPorn playback: {}'.format(type(exc).__name__))
        utils.notify('IndoPorn', 'Unable to open this video. Please check the Kodi log.')
    finally:
        vp.progress.close()


@site.register()
def BrowserAccess(url):
    session = _browser_session()
    cookie_status = 'saved' if session.get('cookie') else 'not set'
    ua_status = 'saved' if session.get('user_agent') else 'not set'
    for title, action in (
            ('Import Cookie + User-Agent TXT', 'session_file'),
            ('Import Cookie TXT / JSON', 'cookie_file'),
            ('Import User-Agent TXT / JSON', 'ua_file'),
            ('Paste Cookie header (' + cookie_status + ')', 'cookie_paste'),
            ('Paste User-Agent (' + ua_status + ')', 'ua_paste'),
            ('Test Access / Retry Automatic', 'test'),
            ('Clear Browser Session / Use Automatic', 'clear'),
            ('Help: Get Browser Cookie and User-Agent', 'help')):
        site.add_dir(_white(title), action, 'BrowserAction', site.img_cat, Folder=False)
    site.add_dir(_white('Open IndoPorn'), BASE_URL, 'Main', site.img_cat)
    utils.eod(cache=False)


def _read_import_file(path):
    native = path
    read_succeeded = False
    try:
        if path.startswith('special://'):
            translate = getattr(xbmcvfs, 'translatePath', getattr(utils, 'TRANSLATEPATH', None))
            native = translate(path) if translate else path
        if os.path.isfile(native):
            if os.path.getsize(native) > _MAX_IMPORT:
                raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
            with open(native, 'rb') as stream:
                data = stream.read(_MAX_IMPORT + 1)
            if len(data) > _MAX_IMPORT:
                raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
            text = _decode_import(data)
            read_succeeded = True
            if text.strip():
                utils.kodilog('IndoPorn {} FILE_READ_OK method=local characters={}'.format(VERSION, len(text)))
                return text
    except _ImportError:
        raise
    except OSError:
        pass
    # Reopen before each method; platform builds differ in readBytes behavior.
    for method in ('read', 'readBytes'):
        try:
            stream = xbmcvfs.File(path)
            try:
                if callable(getattr(stream, 'size', None)) and stream.size() > _MAX_IMPORT:
                    raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
                reader = getattr(stream, method, None)
                if not reader:
                    continue
                data = reader() if method == 'read' else reader(_MAX_IMPORT + 1)
            finally:
                stream.close()
            if len(data) > _MAX_IMPORT:
                raise _ImportError('FILE_SIZE', 'The export is larger than 16 MB. Export only the current site cookies.')
            text = _decode_import(data)
            read_succeeded = True
            if text.strip():
                utils.kodilog('IndoPorn {} FILE_READ_OK method=vfs-{} characters={}'.format(VERSION, method, len(text)))
                return text
        except _ImportError as exc:
            if exc.code == 'FILE_SIZE':
                raise
        except Exception:
            pass
    if read_succeeded:
        raise _ImportError('EMPTY_FILE', 'The selected file is empty or Kodi returned no text.')
    raise _ImportError('FILE_READ', 'Kodi could not read the file. Try a local Downloads folder or check the network share.')


def _import_text(label):
    path = xbmcgui.Dialog().browseSingle(1, label, 'files', '.txt|.json|.cookies')
    return _read_import_file(path) if path else ''


def _test_browser_access():
    session = _browser_session()
    probes = [('front page', BASE_URL + '?' + urlencode({'filter': _saved_filter()}))]
    manual = bool(session.get('cookie') and session.get('user_agent'))
    if manual:
        probes.append(('Categories', BASE_URL + 'categories/'))
    failures = []
    for title, link in probes:
        try:
            html = _fetch(link, timeout=8)
            if not _page_kind(html, link):
                failures.append((title, 'no listing'))
                continue
            if failures:
                utils.kodilog('IndoPorn {} ACCESS_TEST_PARTIAL_OK working={} blocked={}'.format(
                    VERSION, title, ','.join(name for name, _ in failures)))
                utils.notify('IndoPorn', 'Access works on {}. The front-page check did not pass; your session is kept.'.format(title), duration=8000)
            else:
                utils.notify('IndoPorn', 'Video listing loaded. Choose Open IndoPorn.')
            return
        except _FetchError as exc:
            if not manual:
                raise
            failures.append((title, 'HTTP {}'.format(exc.status) if exc.status else exc.reason))
    details = '; '.join('{}: {}'.format(title, reason) for title, reason in failures)
    utils.kodilog('IndoPorn {} ACCESS_TEST_PAGES_BLOCKED {}'.format(VERSION, details))
    xbmcgui.Dialog().ok('IndoPorn access check',
        'The tested pages did not return a listing. {}. Search, other listings, or playback may still work. '
        'Your imported session has been kept.'.format(details))


@site.register()
def BrowserAction(url):
    action = url
    session = _browser_session()
    utils.kodilog('IndoPorn {} BROWSER_ACTION {}'.format(VERSION, action))
    try:
        if action == 'help':
            xbmcgui.Dialog().textviewer('IndoPorn Browser Access',
                '1. Open https://indoporn.mobi/ in Firefox or Chrome and complete its Cloudflare check.\n\n'
                '2. Use your Firefox cookie-export extension to export the current site as Netscape TXT '
                'or JSON. Choose Import Cookie TXT / JSON here and select that file. Whole-browser exports '
                'are also accepted and filtered for IndoPorn. A Cookie request header can also be pasted.\n\n'
                '3. In Firefox, open about:support and copy User Agent under Application Basics. '
                'Paste that exact value here, or save it to a separate TXT file and choose Import User-Agent. '
                'For Chrome, copy User-Agent from Developer Tools > Network > Request Headers.\n\n'
                'For TV file import, choose Import Cookie + User-Agent TXT to import both values together. '
                'Use one plain-text file with these two lines from the SAME browser session:\n\n'
                'Cookie: complete cookie header\nUser-Agent: exact browser user agent\n\n'
                'Either line order is accepted. Combined JSON containing cookies and User-Agent is also '
                'supported. Both values are checked before saving; an incomplete file keeps your existing '
                'session. A placeholder template is included in the site ZIP.\n\n'
                '4. Choose Test Access, then Open IndoPorn. Imported sessions are used directly, without FlareSolverr.\n\n'
                'Keep the browser and Kodi on the same internet connection, with matching VPN/proxy use. '
                'Cloudflare can expire or reject reused sessions; refresh both values if access fails. '
                'Clear Browser Session returns to the normal automatic method.\n\n'
                'Import failures display a specific code. The Kodi log records that code and the import '
                'stage without recording your cookie values.')
            return
        if action == 'clear':
            path = _profile_path('browser_session.json')
            if os.path.exists(path):
                os.remove(path)
            utils.notify('IndoPorn', 'Browser session cleared. Automatic access is active.')
            xbmc.executebuiltin('Container.Refresh')
            return
        if action == 'test':
            _test_browser_access()
            return
        if action == 'session_file':
            text = _import_text('Import Cookie + User-Agent TXT')
            if not text:
                return
            session.update(_session_bundle(text))
            try:
                _save_browser_session(session)
            except OSError:
                raise _ImportError('FILE_SAVE', 'Kodi could not save the browser session in its profile folder.') from None
            utils.kodilog('IndoPorn {} SESSION_IMPORT_OK'.format(VERSION))
            utils.notify('IndoPorn', 'Cookies and User-Agent imported. Choose Test Access.', duration=8000)
            xbmc.executebuiltin('Container.Refresh')
            return
        if action not in ('cookie_paste', 'cookie_file', 'ua_paste', 'ua_file'):
            return
        is_cookie = action.startswith('cookie_')
        label = 'Cookie header' if is_cookie else 'User-Agent'
        text = (_import_text('Import ' + label) if action.endswith('_file')
                else xbmcgui.Dialog().input('Paste ' + label))
        if not text:
            return
        value = _cookie_header(text) if is_cookie else _user_agent(text)
        session['cookie' if is_cookie else 'user_agent'] = value
        try:
            _save_browser_session(session)
        except OSError:
            raise _ImportError('FILE_SAVE', 'Kodi could not save the browser session in its profile folder.') from None
        if is_cookie:
            count = len(value.split('; '))
            clearance = any(part.startswith('cf_clearance=') and part != 'cf_clearance=' for part in value.split('; '))
            utils.kodilog('IndoPorn {} COOKIE_IMPORT_OK count={} clearance={} user_agent={}'.format(
                VERSION, count, 'present' if clearance else 'absent', 'saved' if session.get('user_agent') else 'missing'))
            message = 'Imported {} cookies. Clearance: {}. {}'.format(count,
                      'present' if clearance else 'absent',
                      'Choose Test Access.' if session.get('user_agent') else 'Next: import the matching User-Agent.')
            utils.notify('IndoPorn', message, duration=8000)
        else:
            utils.kodilog('IndoPorn {} USER_AGENT_IMPORT_OK'.format(VERSION))
            utils.notify('IndoPorn', 'User-Agent saved. Choose Test Access.')
        xbmc.executebuiltin('Container.Refresh')
    except _FetchError as exc:
        _report_fetch_error(exc)
    except _ImportError as exc:
        utils.kodilog('IndoPorn {} IMPORT_FAILED action={} code={}'.format(VERSION, action, exc.code))
        xbmcgui.Dialog().ok('IndoPorn import failed ({})'.format(exc.code), str(exc))
    except Exception as exc:
        # Log the exception type, never its text or imported credential values.
        code = 'USER_AGENT_FORMAT' if action.startswith('ua_') and isinstance(exc, (ValueError, TypeError)) else 'IMPORT_ERROR'
        utils.kodilog('IndoPorn {} IMPORT_FAILED action={} code={} type={}'.format(VERSION, action, code, type(exc).__name__))
        xbmcgui.Dialog().ok('IndoPorn import failed ({})'.format(code),
                           'Use the exact one-line browser User-Agent.' if code == 'USER_AGENT_FORMAT'
                           else 'Import failed. The Kodi log now records the error type without cookie values.')
