'''
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from six.moves import urllib_parse
from resources.lib import utils
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

#site = AdultSite('twistedporn', '[COLOR hotpink]TwistedPorn[/COLOR]', 'https://www.twistedporn.com/', 'twistedporn.png', 'twistedporn')
site = CustomSite('A fan', 'twistedporn')


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url, 'Tag', '', '')
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + 'site/recherche/redirect/', 'Search', site.img_search)
    List(site.url + 'site/liste/index/all/')


@site.register()
def List(url):
    listhtml = utils.getHtml(url)
    match = re.compile(r'"https://www\.twistedporn\.com/(site/article[^"]+)"\s*?><img src="([^"]+)" alt="([^=]+)"\stitle=', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)
        videopage = site.url + videopage

        contextmenu = []
        contexturl = (utils.addon_sys
                      + "?mode={}.Lookupinfo".format(site.module_name)
                      + "&url=" + urllib_parse.quote_plus(videopage))

        contextmenu.append(('[COLOR deeppink]Lookup info[/COLOR]', 'RunPlugin(' + contexturl + ')'))

        site.add_download_link(name, videopage, 'Play', img, name, contextm=contextmenu)

    np = re.compile(r'#">\d+?</a></li><li><a href="([^"]+)">([^<]+)<', re.DOTALL | re.IGNORECASE).search(listhtml)
    if np:
        site.add_dir('Next Page... ({0})'.format(np.group(2)), np.group(1), 'List', site.img_next)
    utils.eod()


@site.register()
def Tag(url):
    taghtml = utils.getHtml(url, site.url)
    match = re.compile('/(site/liste/tags/[^"]+)">([^<]+)<').findall(taghtml)
    for tagpage, name in match:
        name = utils.cleantext(name)
        site.add_dir(name, site.url + tagpage, 'List', '')

    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        url += keyword.replace(' ', '+')


@site.register()
def Play(url, name, download=None):
    vp = utils.VideoPlayer(name, download=download, regex=r"""<iframe[.\n]*.*?src\s*=\s*?["']*?([^'" ]+)""")
    vp.play_from_site_link(url)


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Tag", r'/(site/liste/tags[^"]+)"\s*?class="btn btn-primary">([^<]+)<', ''),
    ]

    lookupinfo = utils.LookupInfo(site.url, url, '{}.List'.format(site.module_name), lookup_list)
    lookupinfo.getinfo()
