'''
    Cumination
    Copyright (C) 2019 Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from resources.lib import utils
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

#site = AdultSite('motherless', '[COLOR hotpink]Motherless[/COLOR]', 'https://motherless.com/', 'motherless.png', 'motherless')
site = CustomSite('Cumination', 'motherless')
BASE_URL = 'https://motherless.com/'

@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Being Watched Now [/COLOR]', BASE_URL + 'live/videos', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Galleries [/COLOR]', BASE_URL + 'galleries/updated', 'Galleries', site.img_cat)
    site.add_dir('[COLOR hotpink]Groups [/COLOR]', BASE_URL + 'groups', 'Groups', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', BASE_URL + 'term/videos/', 'Search', site.img_search)
    List(BASE_URL + 'videos/recent?page=1')
    utils.eod()


@site.register()
def List(url):
    try:
        if url.startswith(BASE_URL + 'live/videos'):
            listhtml = utils._getHtml(url, '')
        else:
            listhtml = utils.getHtml(url, '')
    except:
        return None
    match = re.compile(r'data-frames="12">.+?<a href="([^"]+)".+?<span class="size">([:\d]+)</span>.+?<img class="static" src="([^"]+)".+?alt="([^"]+)"/>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, duration, img, name in match:
        img = img.replace('https:', 'http:')
        name = utils.cleantext(name.replace('Shared by ', ''))
        videopage = videopage if videopage.startswith('http') else BASE_URL[:-1] + videopage
        site.add_download_link(name, videopage, 'Playvid', img, duration=duration)

    next_page = re.compile('<link rel="next" href="([^"]+)"/>').findall(listhtml)
    if next_page:
        site.add_dir('Next Page', next_page[0], 'List', site.img_next)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    videopage = utils.getHtml(url, '')
    videolink = re.compile(r'__fileurl = \'(.+?)\';', re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    vp.play_from_direct_link(videolink.replace('&amp;', '&') + '|verifypeer=false')


@site.register()
def Galleries(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile(r'gallery-container".+?href="([^"]+)".+?"static"\s*src="([^"]+)".+?title="([^"]+)".+?<span>([^<]+)</span>', re.DOTALL).findall(cathtml)
    for videopage, img, name, count in match:
        name = "{} [COLOR hotpink]{}[/COLOR]".format(utils.cleantext(name), count.strip())
        videopage = BASE_URL[:-1] + videopage.replace('/G', '/GV')
        site.add_dir(name, videopage, 'List', img)
    next_page = re.compile('<link rel="next" href="([^"]*)"/>').findall(cathtml)
    if next_page:
        site.add_dir('Next Page', next_page[0], 'Galleries', site.img_next)
    utils.eod()


@site.register()
def Groups(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile(r'class="group-bio-avatar".+?href="([^"]+)".+?src="([^"]+)".+?>([^<]+)</a>\s*</h1>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)
        videopage = BASE_URL[:-1] + videopage.replace('/g/', '/gv/')
        site.add_dir(name, videopage, 'List', img)
    next_page = re.compile(r'href="([^"]*)"\s*class="pop"\s*rel="next"').findall(cathtml)
    if next_page:
        site.add_dir('Next Page', BASE_URL[:-1] + next_page[0], 'Groups', site.img_next)
    utils.eod()


@site.register()
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        title = keyword.replace(' ', '%20')
        searchUrl = searchUrl + title + '?range=0&size=0&sort=relevance&page=1'
        List(searchUrl)
