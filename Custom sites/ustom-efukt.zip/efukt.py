"""
    Cumination
    Copyright (C) 2022 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re

from resources.lib import utils
from resources.lib.customsite import CustomSite

site = CustomSite('Cumination', 'efukt')
BASE_URL = 'https://efukt.com/'


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', BASE_URL + 'categories/', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Series[/COLOR]', BASE_URL + 'series/', 'Series', site.img_cat)
    site.add_download_link('[COLOR hotpink]Random Video[/COLOR]', BASE_URL + 'random.php', 'Playvid', site.img_cat)
    site.add_dir('[COLOR hotpink]Trending[/COLOR]', BASE_URL, 'Trending', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', BASE_URL + 'search/', 'Search', site.img_search)
    List(BASE_URL)
    utils.eod()


@site.register()
def List(url):
    listhtml = utils.getHtml(url, BASE_URL)
    match = re.compile(r'''class="tile".+?url\('([^']+).+?href="([^"]+).+?>([^<]+).+?flow(?:\s*hilight\s*)?">(.+?)</p''', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for img, videopage, name, plot in match:
        name = utils.cleantext(name)
        plot = utils.cleantext(plot)
        plot = re.sub(r'<.+?>', '', plot)
        site.add_download_link(name, videopage, 'Playvid', img, plot)

    np = re.compile(r'href="([^"]+(\d+)/)"\s*class="next_page', re.DOTALL | re.IGNORECASE).search(listhtml)
    if np:
        site.add_dir('Next Page... ({0})'.format(np.group(2)), BASE_URL[:-1] + np.group(1), 'List', site.img_next)

    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    if 'random.php' in url:
        html = utils._getHtml(url, BASE_URL)
        n = re.search(r'og:title" content="([^"]+)', html)
        if n:
            name = utils.cleantext(n.group(1))
    else:
        html = utils.getHtml(url, BASE_URL)
    vp = utils.VideoPlayer(name, download=download)
    videourl = re.search(r'<source\s*src="([^"]+)', html)
    if videourl:
        vp.play_from_direct_link(videourl.group(1).replace('&amp;', '&'))
    vp.progress.close()
    return


@site.register()
def Categories(url):
    cathtml = utils.getHtml(url, site.url)
    match = re.compile(r'''<a\s*href="([^"]+)"\s*data-link-hash="[^"]+"\s*title="([^"]+)">\s*<div\s*class="cat_img_preview"[^']+'([^']+)''', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name, img in match:
        site.add_dir(name, catpage, 'List', img)
    utils.eod()


@site.register()
def Series(url):
    cathtml = utils.getHtml(url, site.url)
    match = re.compile(r'''class="tile".+?url\('([^']+).+?href="([^"]+).+?>([^<]+)''', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for img, catpage, name in match:
        site.add_dir(name, catpage, 'List', img)
    utils.eod()


@site.register()
def Trending(url):
    site.add_dir('[COLOR hotpink]Trending Today[/COLOR]', BASE_URL + 'today/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Trending this Month[/COLOR]', BASE_URL + 'month/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Trending this Year[/COLOR]', BASE_URL + 'year/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]All Time Trenders[/COLOR]', BASE_URL + 'all-time/', 'List', site.img_cat)
    utils.eod()


@site.register()
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        title = keyword.replace(' ', '-')
        searchUrl = searchUrl + title + '/'
        List(searchUrl)
