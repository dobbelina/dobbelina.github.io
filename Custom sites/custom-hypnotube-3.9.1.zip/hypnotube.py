'''
    Cumination
    Copyright (C) 2022 mrowliver

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.customsite import CustomSite

site = CustomSite('agooner', 'hypnotube')

BASE_URL = 'https://hypnotube.com'
video_url = urllib_parse.urljoin(BASE_URL, 'videos/')


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Channels[/COLOR]', urllib_parse.urljoin(BASE_URL, 'channels/'), 'Channels', site.img_cat)
    site.add_dir('[COLOR hotpink]Playlists[/COLOR]', urllib_parse.urljoin(BASE_URL, 'playlists/'), 'Playlists', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', urllib_parse.urljoin(BASE_URL, 'search/videos/'), 'Search', site.img_search)
    List(video_url)
    utils.eod()


@site.register()
def List(url):
    try:
        listhtml = utils.getHtml(url, site.url)
    except Exception as ex:
        print(ex)
        return None
    
    videos = parseNowPlaying(listhtml)
    for video in videos:
        name = utils.cleantext(video.name)
        site.add_download_link(name, video.url, 'Playvid', video.image, video.details, duration=video.duration, quality=video.quality)

    nextp = parseNextPage(listhtml)
    if nextp:
        site.add_dir('[COLOR hotpink]Next Page...[/COLOR]', urllib_parse.urljoin(video_url, nextp), 'List', site.img_next)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    videopage = utils.getHtml(url, site.url)
    videolink = parseVideo(videopage)
    if videolink:
        vp.play_from_direct_link(videolink)
    else:
        utils.notify('Error', 'Can\'t play link')
        vp.progress.close()
        return

@site.register()
def Channels(url):
    html = utils.getHtml(url, site.url)
    channels = parseChannels(html)

    for channel in channels:
        name = utils.cleantext(channel.name)
        site.add_dir(name, channel.url, 'List', channel.image)
    utils.eod()

@site.register()
def Playlists(url):
    html = utils.getHtml(url, site.url)
    playlists = parseChannels(html)

    for channel in channels:
        name = utils.cleantext(channel.name)
        site.add_dir(name, channel.url, 'List', channel.image)
    utils.eod()

@site.register()
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        title = keyword.replace(' ', '-') + "/"
        searchUrl = urllib_parse.urljoin(searchUrl, title)
        List(searchUrl)

class Video:
    def __init__(self, url, name, details, image, duration, quality):
        self.url = url
        self.name = name
        self.details = details
        self.image = image
        self.duration = duration
        self.quality = quality

class Channel:
    def __init__(self, url, name, image):
        self.url = url
        self.name = name
        self.image = image
 
def parseNowPlaying(html):
    videoList = []
    regex = r"<div class=\"item-inner-col inner-col\">\s*<a href=\"([^\"]+)\"\s*title=\"([^\"]+)\">\s*<span class=\"image\">\s*<img data-mb=\"shuffle-thumbs\" data-opt-timeout=\"500\" data-opt-limit=\"10\" src=\"([^\"]+)\"\s*alt=\"[^\"]+\"\s>\s*<span class=\"time\">([^<]+)<\/span>\s*(<span class=\"quality\">\s*<span class=\"quality-icon q-hd\">HD<\/span>\s*<\/span>)?\s*<\/span>\s*<span class=\"item-info\">\s*<span class=\"title\">\s.*<\/span>\s*<span class=\"item-stats\">\s*<span class=\"s-elem s-e-rate\">\s*<span class=\"icon i-thumbs-up\"><\/span>\s*<span class=\"sub-desc\">(.*)<\/span>\s*<\/span>\s*<span class=\"s-elem s-e-views\">\s*<span class=\"icon i-eye\"><\/span>\s*<span class=\"sub-desc\">(.*)<\/span>"
    matches = re.findall(regex, html, re.MULTILINE)

    for url, name, image, duration, hd, likes, views in matches:
        quality = ''
        if hd != '':
            quality = 'HD'
        details = "Likes {0}, Views {1}".format(likes, views)
        video = Video(url, name, details, image, duration, quality)
        videoList.append(video)
    return videoList

def parseVideo(html):
    match = re.compile(r'<source\s*src="([^"]+)"', re.DOTALL | re.IGNORECASE).search(html)
    return match.group(1)

def parseNextPage(html):
    match = re.compile(r"<a rel=['\"]next['\"] title=['\"]Next['\"] href=['\"](.*)['\"] class=['\"]next['\"]>").search(html)
    return match.group(1)

def parseChannels(html):
    channelList = []
    regex = r"<div class=\"item-col item--channel col\">\s+<div class=\"item-inner-col inner-col\">\s+<a href=\"([^\"]*)\" title=\"(.*)\">\s*<span class=\"image\">\s*<img src=\"([^\"].*)\" alt"
    matches = re.findall(regex, html, re.MULTILINE)

    for url, name, image in matches:
        channel = Channel(url, name, image)
        channelList.append(channel)
    return channelList

def parsePlaylists(html):
    channelList = []
    regex = r"<div class=\"item-col item--channel col\">\s+<div class=\"item-inner-col inner-col\">\s+<a href=\"([^\"]*)\" title=\"(.*)\">\s*<span class=\"image\">\s*<img src=\"([^\"].*)\" alt"
    matches = re.findall(regex, html, re.MULTILINE)

    for url, name, image in matches:
        channel = Channel(url, name, image)
        channelList.append(channel)
    return channelList