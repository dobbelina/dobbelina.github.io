'''
    Cumination
    Copyright (C) 2019 Cumination
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from urllib.parse import quote_plus, urljoin

import xbmc
import xbmcplugin
from resources.lib import utils
#from resources.lib.adultsite import AdultSite
from resources.lib.customsite import CustomSite

site = CustomSite('Cumination', 'handjobhub')
 
#site = AdultSite('handjobhub', '[COLOR hotpink]HandjobHub[/COLOR]', 'https://handjobhub.com/most-recent/', 'handjobhub.png', 'handjobhub')

BASE_URL = 'https://handjobhub.com'

@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Search[/COLOR]', BASE_URL, 'Search', site.img_cat)
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', BASE_URL + '/channels/', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Most Viewed[/COLOR]', BASE_URL + '/most-viewed/', 'List', site.img_cat)
    List(BASE_URL + '/most-recent/')
    utils.eod()


@site.register()
def Search(url):
    keyboard = xbmc.Keyboard('', 'Search HandjobHub')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        utils.eod()
        return None

    query = keyboard.getText().strip()
    if not query:
        utils.eod()
        return None

    search_url = BASE_URL + '/searchgate.php?q=' + quote_plus(query)
    List(search_url)


@site.register()
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    # HandjobHub cards expose the poster in data-opts-original, with src as fallback.
    card_match = re.compile(
        r'<a\s+href=["\']((?:https?://[^"\']+)?/video/[^"\']+)["\']\s+title=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
        re.DOTALL | re.IGNORECASE,
    ).findall(listhtml)

    seen = set()
    for videopage, name, card_html in card_match:
        videopage = urljoin(BASE_URL, videopage)
        if videopage in seen:
            continue
        seen.add(videopage)

        img_match = re.search(r'data-opts-original=["\']([^"\']+)["\']', card_html, re.IGNORECASE)
        if not img_match:
            img_match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', card_html, re.IGNORECASE)

        img = site.img_cat
        if img_match:
            img = urljoin(BASE_URL, img_match.group(1).replace('&amp;', '&'))

        name = utils.cleantext(name)

        duration = ''
        duration_match = re.search(r'<span\s+class=["\']time["\'][^>]*>([^<]+)</span>', card_html, re.IGNORECASE)
        if duration_match:
            duration = utils.cleantext(duration_match.group(1)).strip()

        quality = ''
        quality_match = re.search(r'<span\s+class=["\'][^"\']*quality-icon[^"\']*["\'][^>]*>([^<]+)</span>', card_html, re.IGNORECASE)
        if quality_match:
            quality = utils.cleantext(quality_match.group(1)).strip().upper()
        if not quality:
            quality_class_match = re.search(r'quality-icon[^"\']*q-([a-z0-9]+)', card_html, re.IGNORECASE)
            if quality_class_match:
                quality_raw = quality_class_match.group(1).strip().upper()
                quality = quality_raw + 'P' if quality_raw.isdigit() else quality_raw
        if not quality:
            quality_text_match = re.search(r'\b(\d{3,4}p)\b', card_html, re.IGNORECASE)
            if quality_text_match:
                quality = quality_text_match.group(1).upper()

        item_title = name
        meta_parts = []
        if duration:
            meta_parts.append(duration)
        if quality:
            meta_parts.append(quality)
        if meta_parts:
            item_title = '{} [COLOR gold]({})[/COLOR]'.format(name, ' | '.join(meta_parts))

        site.add_download_link(item_title, videopage, 'Playvid', img, name)
    
    nextp = re.search(r'<link\s+rel=["\']next["\']\s+href=["\']([^"\']+)["\']', listhtml, re.IGNORECASE)
    if not nextp:
        nextp = re.search(r'<a[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']', listhtml, re.IGNORECASE)
    if nextp:
        site.add_dir('Next Page', urljoin(url, nextp.group(1)), 'List', site.img_next)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    videopage = utils.getHtml(url, '')

    videomatch = re.search(r'<source[^>]+src=["\']([^"\']+)["\']', videopage, re.DOTALL | re.IGNORECASE)
    if not videomatch:
        videomatch = re.search(r'"video_url"\s*:\s*"([^"]+)"', videopage, re.DOTALL | re.IGNORECASE)
    if not videomatch:
        return None

    videolink = videomatch.group(1).replace('\\/', '/').replace('&amp;', '&')
    vp.play_from_direct_link(videolink)


@site.register()
def Categories(url):
    cathtml = utils.getHtml(url, '')

    seen = set()
    card_match = re.compile(
        r'<div\s+class=["\'][^"\']*item--channel[^"\']*["\'][^>]*>(.*?)</div>\s*</div>',
        re.DOTALL | re.IGNORECASE,
    ).findall(cathtml)

    for card_html in card_match:
        item_match = re.search(
            r'<a\s+href=["\']((?:https?://[^"\']+)?/category/[^"\']+)["\']\s+title=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            card_html,
            re.DOTALL | re.IGNORECASE,
        )
        if not item_match:
            continue

        cat, name, item_html = item_match.groups()
        catpage = urljoin(BASE_URL, cat)
        if catpage in seen:
            continue
        seen.add(catpage)

        img = site.img_cat
        img_match = re.search(r'data-opts-original=["\']([^"\']+)["\']', item_html, re.IGNORECASE)
        if not img_match:
            img_match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', item_html, re.IGNORECASE)
        if img_match:
            img_path = img_match.group(1).strip().replace('&amp;', '&')
            if img_path:
                img = urljoin(BASE_URL, img_path)

        site.add_dir(utils.cleantext(name), catpage, 'List', img)

    # Fallback for alternate layouts without channel cards.
    if not seen:
        fallback_match = re.compile(
            r'<a\s+title=["\']([^"\']+)["\']\s+href=["\']((?:https?://[^"\']+)?/category/[^"\']+)["\']',
            re.DOTALL | re.IGNORECASE,
        ).findall(cathtml)
        for name, cat in fallback_match:
            catpage = urljoin(BASE_URL, cat)
            if catpage in seen:
                continue
            seen.add(catpage)
            site.add_dir(utils.cleantext(name), catpage, 'List', site.img_cat)
    utils.eod()
